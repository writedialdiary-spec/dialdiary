<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class ClaimRejectedMail extends Mailable
{
    use Queueable, SerializesModels;

    public $claim;

    public function __construct($claim)
    {
        $this->claim = $claim;
    }

    public function envelope()
    {
        return new Envelope(
            subject: 'Your claim has been rejected',
        );
    }

    public function content()
    {
        return new Content(
            view: 'emails.claim_reject',
        );
    }

    public function attachments()
    {
        return [];
    }
}

