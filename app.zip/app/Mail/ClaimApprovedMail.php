<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class ClaimApprovedMail extends Mailable
{
    use Queueable, SerializesModels;

    public $claim;

    public function __construct($claim)
    {
        $this->claim = $claim;
    }

    public function envelope()
    {
        return new Envelope(
            subject: 'Your claim has been approved',
        );
    }

    public function content()
    {
        return new Content(
            view: 'emails.claim_aproved',
        );
    }

    public function attachments()
    {
        return [];
    }
}

