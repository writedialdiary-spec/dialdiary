<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class BookingStatusChanged extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
     public $booking;
    public $messageContent;

    public function __construct($booking, $messageContent)
    {
        $this->booking = $booking;
        $this->messageContent = $messageContent;
    }

    
    public function build()
    {
        return $this->subject('Your Booking Status Has Been Updated')
                    ->view('admin.booking_status_changed');
    }
}
