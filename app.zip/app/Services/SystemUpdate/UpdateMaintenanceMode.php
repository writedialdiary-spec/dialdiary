<?php

namespace App\Services\SystemUpdate;

use Illuminate\Support\Facades\Artisan;

class UpdateMaintenanceMode
{
    public function down(): int
    {
        return Artisan::call('down');
    }

    public function up(): int
    {
        return Artisan::call('up');
    }
}
