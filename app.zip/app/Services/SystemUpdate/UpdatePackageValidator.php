<?php

namespace App\Services\SystemUpdate;

use Illuminate\Support\Facades\File;
use RuntimeException;
use ZipArchive;

class UpdatePackageValidator
{
    private const MAX_PACKAGE_BYTES = 512 * 1024 * 1024;
    private const MAX_UNCOMPRESSED_BYTES = 500 * 1024 * 1024;
    private const MAX_ENTRIES = 5000;

    private const ALLOWED_PREFIXES = [
        'app/',
        'bootstrap/',
        'config/',
        'database/migrations/',
        'public/assets/',
        'resources/views/',
        'resources/lang/',
        'routes/',
    ];

    private const FORBIDDEN_EXACT_PATHS = [
        '.env',
        '.env.example',
        'composer.json',
        'composer.lock',
        'version.json',
        'public/index.php',
        'public/updater/',
    ];

    private const FORBIDDEN_FILENAMES = [
        'inject.php',
        'front.php',
        'server.php',
    ];

    public function validate(string $packagePath): array
    {
        $errors = [];
        $warnings = [];

        if (!File::exists($packagePath) || !File::isFile($packagePath)) {
            return $this->failure([
                'Update package does not exist: ' . $packagePath,
            ]);
        }

        $size = File::size($packagePath);

        if ($size <= 0) {
            return $this->failure(['Update package is empty.']);
        }

        if ($size > self::MAX_PACKAGE_BYTES) {
            return $this->failure([
                'Update package exceeds the maximum allowed size of 512 MB.',
            ]);
        }

        if (!class_exists(ZipArchive::class)) {
            return $this->failure([
                'PHP ZipArchive extension is not available.',
            ]);
        }

        $zip = new ZipArchive();

        if ($zip->open($packagePath) !== true) {
            return $this->failure([
                'Unable to open the update package as a ZIP archive.',
            ]);
        }

        try {
            if ($zip->numFiles > self::MAX_ENTRIES) {
                $errors[] = 'Update package contains more than 5000 archive entries.';
            }

            $manifest = null;
            $manifestBytes = null;
            $manifestCount = 0;
            $archiveFiles = [];
            $archivePathSet = [];
            $totalUncompressed = 0;

            for ($i = 0; $i < $zip->numFiles; $i++) {
                $stat = $zip->statIndex($i);

                if (!is_array($stat) || !isset($stat['name'])) {
                    $errors[] = 'Unable to inspect ZIP archive entry #' . $i . '.';
                    continue;
                }

                $name = str_replace('\\', '/', $stat['name']);

                if ($name === '') {
                    $errors[] = 'ZIP archive contains an empty filename.';
                    continue;
                }

                if ($this->isUnsafePath($name)) {
                    $errors[] = 'Unsafe archive path detected: ' . $name;
                    continue;
                }

                $isDirectory = str_ends_with($name, '/');

                if ($isDirectory) {
                    continue;
                }

                $uncompressedSize = (int) ($stat['size'] ?? 0);
                $totalUncompressed += $uncompressedSize;

                if ($totalUncompressed > self::MAX_UNCOMPRESSED_BYTES) {
                    $errors[] = 'Combined uncompressed package size exceeds 500 MB.';
                    break;
                }

                if (strcasecmp($name, 'manifest.json') === 0) {
                    $manifestCount++;

                    if ($name !== 'manifest.json') {
                        $errors[] = 'Manifest must be named exactly manifest.json.';
                    }

                    $contents = $zip->getFromIndex($i);

                    if ($contents === false) {
                        $errors[] = 'Unable to read manifest.json.';
                    } elseif (strlen($contents) > 1024 * 1024) {
                        $errors[] = 'manifest.json exceeds 1 MB.';
                    } else {
                        $manifestBytes = $contents;
                        $decoded = json_decode($contents, true);

                        if (!is_array($decoded)) {
                            $errors[] = 'manifest.json contains invalid JSON.';
                        } else {
                            $manifest = $decoded;
                        }
                    }

                    continue;
                }

                if (isset($archivePathSet[$name])) {
                    $errors[] = 'Duplicate ZIP archive path: ' . $name;
                    continue;
                }

                $archivePathSet[$name] = true;
                $archiveFiles[] = $name;
            }

            if ($manifestCount !== 1 || $manifest === null || $manifestBytes === null) {
                $errors[] = 'Exactly one valid root manifest.json is required.';
            }

            if (!empty($errors)) {
                return $this->failure($errors, $warnings);
            }

            if (($manifest['format'] ?? null) !== 1) {
                $errors[] = 'Unsupported manifest format. Expected format 1.';
            }

            $newVersion = isset($manifest['version'])
                ? trim((string) $manifest['version'])
                : '';

            if ($newVersion === '') {
                $errors[] = 'Manifest version is required.';
            } elseif (!preg_match('/^\d+(?:\.\d+){0,3}$/', $newVersion)) {
                $errors[] = 'Manifest version has an invalid format.';
            }

            $releaseDate = isset($manifest['release_date'])
                ? trim((string) $manifest['release_date'])
                : '';

            if ($releaseDate === '') {
                $errors[] = 'Manifest release_date is required.';
            }

            $files = $manifest['files'] ?? null;

            if (!is_array($files) || empty($files)) {
                $errors[] = 'Manifest files must be a non-empty array.';
            }

            if (!empty($errors)) {
                return $this->failure($errors, $warnings);
            }

            $currentVersion = $this->currentVersion();

            if (version_compare($newVersion, $currentVersion, '<=')) {
                $errors[] = sprintf(
                    'Update version %s is not newer than the current version %s.',
                    $newVersion,
                    $currentVersion
                );
            }

            $manifestPaths = [];

            foreach ($files as $index => $entry) {
                if (!is_array($entry)) {
                    $errors[] = "Manifest file entry #{$index} must be an object.";
                    continue;
                }

                $path = isset($entry['path'])
                    ? str_replace('\\', '/', trim((string) $entry['path']))
                    : '';

                $sha256 = isset($entry['sha256'])
                    ? strtolower(trim((string) $entry['sha256']))
                    : '';

                $action = isset($entry['action'])
                    ? trim((string) $entry['action'])
                    : '';

                if ($path === '') {
                    $errors[] = "Manifest file entry #{$index} has no path.";
                    continue;
                }

                if ($this->isUnsafePath($path)) {
                    $errors[] = 'Unsafe manifest path: ' . $path;
                    continue;
                }

                if (isset($manifestPaths[$path])) {
                    $errors[] = 'Duplicate manifest path: ' . $path;
                    continue;
                }

                $manifestPaths[$path] = true;

                if (!$this->isAllowedPath($path)) {
                    $errors[] = 'Path is not in the safe update allowlist: ' . $path;
                }

                if ($this->isForbiddenPath($path)) {
                    $errors[] = 'Forbidden update path: ' . $path;
                }

                if (in_array(basename($path), self::FORBIDDEN_FILENAMES, true)) {
                    $errors[] = 'Forbidden updater filename: ' . $path;
                }

                if (str_starts_with($path, 'public/') && str_ends_with(strtolower($path), '.php')) {
                    $errors[] = 'PHP files are not allowed under public/: ' . $path;
                }

                if (!preg_match('/^[a-f0-9]{64}$/', $sha256)) {
                    $errors[] = 'Invalid SHA-256 checksum for: ' . $path;
                }

                if (!in_array($action, ['add', 'replace'], true)) {
                    $errors[] = 'Invalid action for ' . $path . '. Only add or replace are allowed.';
                }
            }

            $archiveLookup = array_fill_keys($archiveFiles, true);

            foreach ($manifestPaths as $path => $_) {
                if (!isset($archiveLookup[$path])) {
                    $errors[] = 'Manifest file is missing from the ZIP archive: ' . $path;
                }
            }

            foreach ($archiveFiles as $archiveFile) {
                if (!isset($manifestPaths[$archiveFile])) {
                    $errors[] = 'ZIP contains a file not listed in the manifest: ' . $archiveFile;
                }
            }

            if (!empty($errors)) {
                return $this->failure($errors, $warnings);
            }

            foreach ($files as $entry) {
                $path = str_replace('\\', '/', trim((string) $entry['path']));
                $expectedHash = strtolower(trim((string) $entry['sha256']));

                $index = $this->findZipIndex($zip, $path);

                if ($index === false) {
                    $errors[] = 'Unable to locate file in ZIP: ' . $path;
                    continue;
                }

                $contents = $zip->getFromIndex($index);

                if ($contents === false) {
                    $errors[] = 'Unable to read file from ZIP: ' . $path;
                    continue;
                }

                $actualHash = hash('sha256', $contents);

                if (!hash_equals($expectedHash, $actualHash)) {
                    $errors[] = 'SHA-256 checksum mismatch: ' . $path;
                }
            }

            if (!empty($errors)) {
                return $this->failure($errors, $warnings);
            }

            return [
                'valid' => true,
                'errors' => [],
                'warnings' => $warnings,
                'current_version' => $currentVersion,
                'new_version' => $newVersion,
                'release_date' => $releaseDate,
                'file_count' => count($files),
                'package_size' => $size,
                'uncompressed_size' => $totalUncompressed,
            ];
        } finally {
            $zip->close();
        }
    }

    private function currentVersion(): string
    {
        $versionFile = base_path('version.json');

        if (!File::exists($versionFile)) {
            return '0.0.0';
        }

        $data = json_decode(File::get($versionFile), true);

        if (!is_array($data) || !isset($data['version'])) {
            return '0.0.0';
        }

        return trim((string) $data['version']);
    }

    private function findZipIndex(ZipArchive $zip, string $path)
    {
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $stat = $zip->statIndex($i);

            if (is_array($stat)) {
                $name = str_replace('\\', '/', (string) ($stat['name'] ?? ''));

                if ($name === $path) {
                    return $i;
                }
            }
        }

        return false;
    }

    private function isUnsafePath(string $path): bool
    {
        if ($path === '' || str_starts_with($path, '/') || preg_match('/^[A-Za-z]:\//', $path)) {
            return true;
        }

        if (str_contains($path, "\0")) {
            return true;
        }

        $parts = explode('/', $path);

        foreach ($parts as $part) {
            if ($part === '..' || $part === '.') {
                return true;
            }
        }

        return false;
    }

    private function isAllowedPath(string $path): bool
    {
        foreach (self::ALLOWED_PREFIXES as $prefix) {
            if (str_starts_with($path, $prefix)) {
                return true;
            }
        }

        return false;
    }

    private function isForbiddenPath(string $path): bool
    {
        foreach (self::FORBIDDEN_EXACT_PATHS as $forbidden) {
            if ($path === $forbidden || str_starts_with($path, $forbidden)) {
                return true;
            }
        }

        return false;
    }

    private function failure(array $errors, array $warnings = []): array
    {
        return [
            'valid' => false,
            'errors' => array_values(array_unique($errors)),
            'warnings' => array_values(array_unique($warnings)),
        ];
    }
}
