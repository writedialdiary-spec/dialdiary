<?php

namespace App\Services\SystemUpdate;

use RuntimeException;

class UpdateRecoveryJournal
{
    private string $root;
    private string $appRoot;

    private array $allowedPrefixes = [
        'app/',
        'bootstrap/',
        'config/',
        'database/migrations/',
        'public/assets/',
        'resources/views/',
        'resources/lang/',
        'routes/',
        'version.json',
    ];

    public function __construct(?string $appRoot = null, ?string $recoveryRoot = null)
    {
        $resolvedAppRoot = realpath($appRoot ?? base_path());
        if ($resolvedAppRoot === false || !is_dir($resolvedAppRoot)) {
            throw new RuntimeException('Application recovery root does not exist.');
        }

        $this->appRoot = $resolvedAppRoot;
        $this->root = $recoveryRoot ?? '/home/dialdiary/system-update-signing/recovery';

        if (!is_dir(dirname($this->root)) || is_link(dirname($this->root))) {
            throw new RuntimeException('Private recovery parent directory is unsafe.');
        }

        if (!is_dir($this->root) &&
            !mkdir($this->root, 0700, true) &&
            !is_dir($this->root)) {
            throw new RuntimeException('Cannot create private recovery directory.');
        }

        if (is_link($this->root) || !is_writable($this->root)) {
            throw new RuntimeException('Recovery directory is unsafe or not writable.');
        }

        chmod($this->root, 0700);
    }

    public function begin(): string
    {
        $id = bin2hex(random_bytes(16));
        $directory = $this->root . DIRECTORY_SEPARATOR . $id;

        if (!mkdir($directory, 0700)) {
            throw new RuntimeException('Cannot create recovery journal.');
        }

        $this->writeMetadata($directory, [
            'id' => $id,
            'status' => 'preparing',
            'created_at' => date(DATE_ATOM),
            'files' => [],
        ]);

        return $id;
    }

    public function recordOriginal(string $id, string $relativePath): void
    {
        $directory = $this->journalDirectory($id);
        $metadata = $this->readMetadata($directory);
        $destination = $this->destination($relativePath);

        if (($metadata['status'] ?? null) !== 'preparing') {
            throw new RuntimeException('Recovery journal is not accepting entries.');
        }

        if (isset($metadata['files'][$relativePath])) {
            throw new RuntimeException('File is already recorded.');
        }

        $exists = file_exists($destination);

        if (is_link($destination)) {
            throw new RuntimeException('Symbolic-link destinations are forbidden.');
        }

        $entry = [
            'existed' => $exists,
            'permissions' => null,
            'backup' => null,
            'sha256' => null,
        ];

        if ($exists) {
            if (!is_file($destination) || !is_readable($destination)) {
                throw new RuntimeException('Original destination is not a readable regular file.');
            }

            $entry['permissions'] = fileperms($destination) & 0777;
            $backupName = hash('sha256', $relativePath) . '.bak';
            $backupPath = $directory . DIRECTORY_SEPARATOR . $backupName;

            if (!copy($destination, $backupPath)) {
                throw new RuntimeException('Could not preserve original file.');
            }

            chmod($backupPath, 0600);
            $checksum = hash_file('sha256', $backupPath);

            if ($checksum === false) {
                throw new RuntimeException('Could not verify original-file backup.');
            }

            $entry['backup'] = $backupName;
            $entry['sha256'] = $checksum;
        }

        $metadata['files'][$relativePath] = $entry;
        $this->writeMetadata($directory, $metadata);
    }

    public function markInstalling(string $id, array $expectedPaths = []): void
    {
        $directory = $this->journalDirectory($id);
        $metadata = $this->readMetadata($directory);

        if (($metadata['status'] ?? null) !== 'preparing') {
            throw new RuntimeException('Invalid recovery journal state.');
        }

        if ($expectedPaths === []) {
            throw new RuntimeException('Expected recovery file list is required.');
        }

        $normalized = [];
        foreach ($expectedPaths as $path) {
            if (!is_string($path) || $path === '') {
                throw new RuntimeException('Invalid expected recovery path.');
            }
            $this->destination($path);
            if (isset($normalized[$path])) {
                throw new RuntimeException('Duplicate expected recovery path: ' . $path);
            }
            $normalized[$path] = true;
        }

        $recorded = $metadata['files'] ?? [];
        $recordedPaths = array_fill_keys(array_keys($recorded), true);

        if (count($normalized) !== count($recordedPaths) ||
            array_diff_key($normalized, $recordedPaths) !== [] ||
            array_diff_key($recordedPaths, $normalized) !== []) {
            throw new RuntimeException('Recovery journal does not contain the complete expected file list.');
        }

        $validation = $this->validateJournal($id);
        if (!($validation['valid'] ?? false)) {
            throw new RuntimeException('Recovery journal validation failed before installation.');
        }

        $metadata['expected_paths'] = array_keys($normalized);
        $metadata['status'] = 'installing';
        $this->writeMetadata($directory, $metadata);
    }

    public function markComplete(string $id): void
    {
        $directory = $this->journalDirectory($id);
        $metadata = $this->readMetadata($directory);

        if (($metadata['status'] ?? null) !== 'installing') {
            throw new RuntimeException('Invalid recovery journal state.');
        }

        $metadata['status'] = 'complete';
        $metadata['completed_at'] = date(DATE_ATOM);
        $this->writeMetadata($directory, $metadata);
    }

    public function restore(string $id): array
    {
        $directory = $this->journalDirectory($id);
        $metadata = $this->readMetadata($directory);
        $status = $metadata['status'] ?? null;

        if (!in_array($status, ['installing', 'rolling_back', 'rollback_failed'], true)) {
            throw new RuntimeException('Journal state does not permit rollback.');
        }

        $metadata['status'] = 'rolling_back';
        $this->writeMetadata($directory, $metadata);

        $errors = [];
        $files = $metadata['files'] ?? [];

        foreach (array_reverse($files, true) as $relativePath => $entry) {
            try {
                $destination = $this->destination($relativePath);
                $parent = dirname($destination);

                $existed = (bool) ($entry['existed'] ?? false);

                if (!$existed) {
                    if (is_link($destination)) {
                        throw new RuntimeException('Destination became a symbolic link.');
                    }

                    if (file_exists($destination)) {
                        if (!is_file($destination) || !unlink($destination)) {
                            throw new RuntimeException('Could not remove newly installed file.');
                        }
                    }

                    continue;
                }

                if (!is_dir($parent) || is_link($parent)) {
                    throw new RuntimeException('Destination parent directory is missing or unsafe.');
                }

                if (is_link($destination)) {
                    throw new RuntimeException('Destination became a symbolic link.');
                }

                $backupName = $entry['backup'] ?? '';
                if (!preg_match('/^[a-f0-9]{64}\.bak$/', $backupName)) {
                    throw new RuntimeException('Invalid backup filename in journal.');
                }

                $backupPath = $directory . DIRECTORY_SEPARATOR . $backupName;
                if (!is_file($backupPath) || is_link($backupPath)) {
                    throw new RuntimeException('Original-file backup is missing.');
                }

                $actualHash = hash_file('sha256', $backupPath);
                if (!is_string($actualHash) ||
                    !hash_equals((string) ($entry['sha256'] ?? ''), $actualHash)) {
                    throw new RuntimeException('Original-file backup checksum mismatch.');
                }

                $temp = $destination . '.recovery-' . bin2hex(random_bytes(6));

                if (!copy($backupPath, $temp)) {
                    throw new RuntimeException('Could not prepare restored file.');
                }

                if (!chmod($temp, (int) $entry['permissions'])) {
                    @unlink($temp);
                    throw new RuntimeException('Could not restore original-file permissions.');
                }

                if (!rename($temp, $destination)) {
                    @unlink($temp);
                    throw new RuntimeException('Could not restore original file.');
                }
            } catch (\Throwable $exception) {
                $errors[] = $relativePath . ': ' . $exception->getMessage();
            }
        }

        $metadata['status'] = $errors ? 'rollback_failed' : 'rolled_back';
        $metadata['rollback_at'] = date(DATE_ATOM);
        $metadata['rollback_errors'] = $errors;
        $this->writeMetadata($directory, $metadata);

        return ['success' => !$errors, 'errors' => $errors];
    }

    public function metadata(string $id): array
    {
        return $this->readMetadata($this->journalDirectory($id));
    }

    public function validateJournal(string $id): array
    {
        $directory = $this->journalDirectory($id);
        $metadata = $this->readMetadata($directory);
        $errors = [];

        if (($metadata['id'] ?? null) !== $id) {
            $errors[] = 'Journal ID does not match its directory.';
        }

        $allowedStatuses = [
            'preparing', 'installing', 'complete',
            'rolling_back', 'rolled_back', 'rollback_failed',
        ];

        if (!in_array($metadata['status'] ?? null, $allowedStatuses, true)) {
            $errors[] = 'Unknown journal status.';
        }

        if (!is_array($metadata['files'] ?? null)) {
            $errors[] = 'Journal files field is invalid.';
            return ['valid' => false, 'errors' => $errors];
        }

                $status = $metadata['status'] ?? null;
        $requiresExpectedPaths = in_array(
            $status,
            ['installing', 'complete', 'rolling_back', 'rolled_back', 'rollback_failed'],
            true
        );

        $expected = $metadata['expected_paths'] ?? null;

        // Legacy rolled-back journals may predate expected_paths.
        // Continue validating each recorded path and backup below.
        $legacyRolledBack = $status === 'rolled_back'
            && !array_key_exists('expected_paths', $metadata);

        if ($requiresExpectedPaths && !$legacyRolledBack) {
            if (
                !is_array($expected)
                || $expected === []
                || count($expected) !== count(array_unique($expected))
                || array_diff(array_keys($metadata['files']), $expected)
                || array_diff($expected, array_keys($metadata['files']))
            ) {
                $errors[] = 'Journal expected file list does not match recorded files.';
            }
        }
        foreach ($metadata['files'] as $relativePath => $entry) {
            try {
                if (!is_string($relativePath) || !is_array($entry)) {
                    throw new RuntimeException('Invalid file entry structure.');
                }

                $this->destination($relativePath);

                if (!array_key_exists('existed', $entry) ||
                    !is_bool($entry['existed'])) {
                    throw new RuntimeException('Invalid original-file state.');
                }

                if (!$entry['existed']) {
                    if (($entry['backup'] ?? null) !== null ||
                        ($entry['sha256'] ?? null) !== null) {
                        throw new RuntimeException('New-file entry unexpectedly has a backup.');
                    }
                    continue;
                }

                $backupName = $entry['backup'] ?? null;
                $expectedHash = $entry['sha256'] ?? null;

                if (!is_string($backupName) ||
                    !preg_match('/^[a-f0-9]{64}\.bak$/', $backupName)) {
                    throw new RuntimeException('Invalid backup filename.');
                }

                if (!is_string($expectedHash) ||
                    !preg_match('/^[a-f0-9]{64}$/', $expectedHash)) {
                    throw new RuntimeException('Invalid backup checksum metadata.');
                }

                $backupPath = $directory . DIRECTORY_SEPARATOR . $backupName;

                if (!is_file($backupPath) || is_link($backupPath)) {
                    throw new RuntimeException('Original-file backup is missing or unsafe.');
                }

                $actualHash = hash_file('sha256', $backupPath);

                if (!is_string($actualHash) ||
                    !hash_equals($expectedHash, $actualHash)) {
                    throw new RuntimeException('Original-file backup checksum mismatch.');
                }

                if (!isset($entry['permissions']) ||
                    !is_int($entry['permissions']) ||
                    $entry['permissions'] < 0 ||
                    $entry['permissions'] > 0777) {
                    throw new RuntimeException('Invalid original-file permissions.');
                }
            } catch (\Throwable $exception) {
                $errors[] = (string) $relativePath . ': ' . $exception->getMessage();
            }
        }

        return [
            'valid' => $errors === [],
            'id' => $id,
            'status' => $metadata['status'] ?? null,
            'file_count' => count($metadata['files']),
            'errors' => $errors,
        ];
    }

    public function listJournals(): array
    {
        $journals = [];
        $items = scandir($this->root);

        if ($items === false) {
            throw new RuntimeException('Cannot list recovery journals.');
        }

        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }

            if (!preg_match('/^[a-f0-9]{32}$/', $item)) {
                continue;
            }

            $directory = $this->journalDirectory($item);
            $metadata = $this->readMetadata($directory);

            if (($metadata['id'] ?? null) !== $item) {
                throw new RuntimeException('Recovery journal ID does not match its directory.');
            }

            $journals[] = [
                'id' => $item,
                'status' => (string) $metadata['status'],
                'created_at' => $metadata['created_at'] ?? null,
                'completed_at' => $metadata['completed_at'] ?? null,
                'file_count' => count($metadata['files']),
            ];
        }

        return $journals;
    }

    private function destination(string $relativePath): string
    {
        if ($relativePath === '' ||
            str_contains($relativePath, "\0") ||
            str_contains($relativePath, '\\') ||
            str_starts_with($relativePath, '/') ||
            preg_match('/(^|\/)\.\.?($|\/)/', $relativePath)) {
            throw new RuntimeException('Unsafe relative path.');
        }

        $allowed = false;
        foreach ($this->allowedPrefixes as $prefix) {
            if ($relativePath === $prefix || str_starts_with($relativePath, $prefix)) {
                $allowed = true;
                break;
            }
        }

        if (!$allowed) {
            throw new RuntimeException('Path is outside the recovery allowlist.');
        }

        $destination = $this->appRoot . DIRECTORY_SEPARATOR . $relativePath;
        $parent = dirname($destination);
        $resolvedParent = realpath($parent);

        if ($resolvedParent !== false &&
            $resolvedParent !== $this->appRoot &&
            !str_starts_with($resolvedParent, $this->appRoot . DIRECTORY_SEPARATOR)) {
            throw new RuntimeException('Destination escapes the application root.');
        }

        $cursor = $this->appRoot;
        foreach (explode('/', $relativePath) as $part) {
            $cursor .= DIRECTORY_SEPARATOR . $part;
            if (is_link($cursor)) {
                throw new RuntimeException('Symbolic links are forbidden in recovery paths.');
            }
        }

        return $destination;
    }

    private function journalDirectory(string $id): string
    {
        if (!preg_match('/^[a-f0-9]{32}$/', $id)) {
            throw new RuntimeException('Invalid recovery journal ID.');
        }

        $directory = $this->root . DIRECTORY_SEPARATOR . $id;

        if (!is_dir($directory) || is_link($directory)) {
            throw new RuntimeException('Recovery journal does not exist.');
        }

        return $directory;
    }

    private function readMetadata(string $directory): array
    {
        $path = $directory . DIRECTORY_SEPARATOR . 'journal.json';

        if (!is_file($path) || is_link($path)) {
            throw new RuntimeException('Recovery journal metadata is missing.');
        }

        $contents = file_get_contents($path);
        $data = is_string($contents) ? json_decode($contents, true) : null;

        if (!is_array($data) || !isset($data['id'], $data['status'], $data['files'])) {
            throw new RuntimeException('Recovery journal metadata is invalid.');
        }

        return $data;
    }

    private function writeMetadata(string $directory, array $metadata): void
    {
        $path = $directory . DIRECTORY_SEPARATOR . 'journal.json';
        $temp = $path . '.' . bin2hex(random_bytes(6)) . '.tmp';
        $json = json_encode($metadata, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

        if ($json === false ||
            file_put_contents($temp, $json . PHP_EOL, LOCK_EX) === false) {
            throw new RuntimeException('Could not write recovery journal metadata.');
        }

        chmod($temp, 0600);

        if (!rename($temp, $path)) {
            @unlink($temp);
            throw new RuntimeException('Could not finalize recovery journal metadata.');
        }

        chmod($path, 0600);
    }
}
