<?php

namespace App\Services\SystemUpdate;

use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use RuntimeException;
use Throwable;
use ZipArchive;

class UpdateInstaller
{
    private string $privateRoot;
    private ?string $workRootOverride;
    private ?string $appRootOverride;
    private ?string $auditRootOverride;
    private UpdateMaintenanceMode $maintenance;
    private ?UpdateRecoveryJournal $recoveryJournalOverride;

    public function __construct(
        ?string $privateRoot = null,
        ?string $workRoot = null,
        ?string $appRoot = null,
        ?string $auditRoot = null,
        ?UpdateMaintenanceMode $maintenance = null,
        ?UpdateRecoveryJournal $recoveryJournal = null
    ) {
        $this->privateRoot = $privateRoot ?? '/home/dialdiary/system-update-signing';
        $this->workRootOverride = $workRoot;
        $this->appRootOverride = $appRoot;
        $this->auditRootOverride = $auditRoot;
        $this->maintenance = $maintenance ?? app(UpdateMaintenanceMode::class);
        $this->recoveryJournalOverride = $recoveryJournal;
    }

    public function install(string $packagePath, ?int $adminId = null): array
    {
        $packageId = bin2hex(random_bytes(12));
        $workRoot = ($this->workRootOverride ?? storage_path('app/system-updates/work')) . DIRECTORY_SEPARATOR . $packageId;
        $stageRoot = $workRoot . '/staged';
        $backupRoot = $workRoot . '/backup';
        $snapshotPath = $workRoot . '/package.zip';
        $journal = [];
        $maintenanceEnabled = false;
        $success = false;
        $recoveryJournal = null;
        $recoveryId = null;
        $recoveryStarted = false;

        if (!is_dir($this->privateRoot) || !is_writable($this->privateRoot)) {
            throw new RuntimeException('Private update storage is unavailable.');
        }

        try {
            if (!mkdir($stageRoot, 0700, true)) {
                throw new RuntimeException('Cannot create private staging directory.');
            }

            if (!mkdir($backupRoot, 0700, true)) {
                throw new RuntimeException('Cannot create private backup directory.');
            }

            if (!is_file($packagePath) || is_link($packagePath) ||
                !copy($packagePath, $snapshotPath) ||
                !chmod($snapshotPath, 0600)) {
                throw new RuntimeException('Cannot create a private update package snapshot.');
            }

            clearstatcache(true, $snapshotPath);

            $validator = app(UpdatePackageValidator::class);
            $validation = $validator->validate($snapshotPath);

            if (!($validation['valid'] ?? false)) {
                throw new RuntimeException(
                    'Installation refused: package validation failed.'
                );
            }
            
            
$recoveryJournal = $this->recoveryJournalOverride
    ?? app(UpdateRecoveryJournal::class);

$preflight = new UpdatePreflight(
    $recoveryJournal,
    $this->appRootOverride ?? base_path(),
    $this->privateRoot,
    $this->workRootOverride ?? storage_path('app/system-updates/work')
);

$preflightResult = $preflight->check();

if (!($preflightResult['ready'] ?? false)) {
    $reasons = $preflightResult['blockers'] ?? [];

    throw new RuntimeException(
        'Installation refused by preflight: ' .
        implode(' ', array_map('strval', $reasons))
    );
}

            
            
            $zip = new ZipArchive();

            if ($zip->open($snapshotPath) !== true) {
                throw new RuntimeException('Cannot reopen private update package snapshot.');
            }

            try {
                $manifestBytes = $zip->getFromName('manifest.json');
                $manifest = is_string($manifestBytes)
                    ? json_decode($manifestBytes, true)
                    : null;

                if (!is_array($manifest) || !is_array($manifest['files'] ?? null)) {
                    throw new RuntimeException('Package manifest is invalid.');
                }

                $files = $manifest['files'];

                foreach ($files as $entry) {
                    if (!is_array($entry) || !isset($entry['path'], $entry['action'])) {
                        throw new RuntimeException('Invalid manifest file entry.');
                    }

                    $relative = str_replace('\\', '/', trim((string) $entry['path']));

                    if (
                        $relative === '' ||
                        str_starts_with($relative, '/') ||
                        preg_match('/^[A-Za-z]:/', $relative) ||
                        preg_match('~(^|/)\.\.?(/|$)~', $relative) ||
                        str_contains($relative, "\0")
                    ) {
                        throw new RuntimeException('Unsafe file path in manifest.');
                    }

                    if (str_starts_with($relative, 'database/migrations/')) {
                        throw new RuntimeException(
                            'This installer does not yet support database migrations. No files were installed.'
                        );
                    }

                    $allowed = false;
                    foreach ([
                        'app/', 'bootstrap/', 'config/',
                        'public/assets/', 'resources/views/',
                        'resources/lang/', 'routes/',
                    ] as $prefix) {
                        if (str_starts_with($relative, $prefix)) {
                            $allowed = true;
                            break;
                        }
                    }

                    if (!$allowed || str_starts_with($relative, 'public/') && str_ends_with(strtolower($relative), '.php')) {
                        throw new RuntimeException('File is outside the installer allowlist: ' . $relative);
                    }

                    if (!in_array($entry['action'], ['add', 'replace'], true)) {
                        throw new RuntimeException('Unsupported file action: ' . $relative);
                    }

                    $content = $zip->getFromName($relative);

                    if (!is_string($content)) {
                        throw new RuntimeException('Cannot read package file: ' . $relative);
                    }

                    $expected = strtolower((string) ($entry['sha256'] ?? ''));
                    if (!preg_match('/^[a-f0-9]{64}$/', $expected) ||
                        !hash_equals($expected, hash('sha256', $content))) {
                        throw new RuntimeException('File checksum mismatch: ' . $relative);
                    }

                    $destination = $this->safeDestination($relative);
                    $exists = is_file($destination);

                    if ($entry['action'] === 'add' && $exists) {
                        throw new RuntimeException('Cannot add a file that already exists: ' . $relative);
                    }

                    if ($entry['action'] === 'replace' && !$exists) {
                        throw new RuntimeException('Cannot replace a missing file: ' . $relative);
                    }

                    $staged = $stageRoot . '/' . $relative;
                    if (!is_dir(dirname($staged)) &&
                        !mkdir(dirname($staged), 0700, true) &&
                        !is_dir(dirname($staged))) {
                        throw new RuntimeException('Cannot create staging path.');
                    }

                    if (file_put_contents($staged, $content, LOCK_EX) === false) {
                        throw new RuntimeException('Cannot stage file: ' . $relative);
                    }

                    chmod($staged, 0600);
                }
            } finally {
                $zip->close();
            }

            // Verify all destinations again before changing any live files.
            foreach ($files as $entry) {
                $relative = str_replace('\\', '/', trim((string) $entry['path']));
                $destination = $this->safeDestination($relative);
                $exists = is_file($destination);

                if ($entry['action'] === 'add' && $exists) {
                    throw new RuntimeException('Destination changed during staging: ' . $relative);
                }
                if ($entry['action'] === 'replace' && !$exists) {
                    throw new RuntimeException('Destination disappeared during staging: ' . $relative);
                }
            }

            $recoveryId = $recoveryJournal->begin();

            foreach ($files as $entry) {
                $relative = str_replace('\\', '/', trim((string) $entry['path']));
                $recoveryJournal->recordOriginal($recoveryId, $relative);
            }

            $recoveryJournal->recordOriginal($recoveryId, 'version.json');

            $expectedRecoveryPaths = [];
            foreach ($files as $entry) {
                $expectedRecoveryPaths[] = str_replace('\\', '/', trim((string) $entry['path']));
            }
            $expectedRecoveryPaths[] = 'version.json';

            $recoveryJournal->markInstalling($recoveryId, $expectedRecoveryPaths);
            $recoveryStarted = true;

            if ($this->maintenance->down() !== 0) {
                throw new RuntimeException('Could not enable maintenance mode.');
            }
            $maintenanceEnabled = true;

            foreach ($files as $entry) {
                $relative = str_replace('\\', '/', trim((string) $entry['path']));
                $destination = $this->safeDestination($relative);
                $staged = $stageRoot . '/' . $relative;
                $backup = $backupRoot . '/' . $relative;
                $existed = is_file($destination);

                if ($existed) {
                    if (!is_dir(dirname($backup)) &&
                        !mkdir(dirname($backup), 0700, true) &&
                        !is_dir(dirname($backup))) {
                        throw new RuntimeException('Cannot create backup path.');
                    }

                    if (!copy($destination, $backup)) {
                        throw new RuntimeException('Cannot back up file: ' . $relative);
                    }
                }

                $journal[] = [
                    'path' => $relative,
                    'existed' => $existed,
                    'backup' => $backup,
                    'destination' => $destination,
                    'permissions' => $existed ? (fileperms($destination) & 0777) : null,
                ];

                if (!is_dir(dirname($destination)) &&
                    !mkdir(dirname($destination), 0755, true) &&
                    !is_dir(dirname($destination))) {
                    throw new RuntimeException('Cannot create destination directory.');
                }

                if (!rename($staged, $destination)) {
                    throw new RuntimeException('Cannot install file: ' . $relative);
                }

                if (!chmod($destination, 0644)) {
                    throw new RuntimeException('Cannot set file permissions: ' . $relative);
                }
            }

            $versionFile = ($this->appRootOverride ?? base_path()) . DIRECTORY_SEPARATOR . 'version.json';
            $oldVersion = File::get($versionFile);
            $newVersion = [
                'version' => (string) $validation['new_version'],
                'release_date' => (string) $validation['release_date'],
            ];

            $versionBackup = $backupRoot . '/version.json';
            if (file_put_contents($versionBackup, $oldVersion, LOCK_EX) === false) {
                throw new RuntimeException('Cannot back up version.json.');
            }
            chmod($versionBackup, 0600);

            $journal[] = [
                'path' => 'version.json',
                'existed' => true,
                'backup' => $versionBackup,
                'destination' => $versionFile,
                'permissions' => fileperms($versionFile) & 0777,
            ];

            $versionTemp = ($this->appRootOverride ?? base_path()) . DIRECTORY_SEPARATOR . 'version.json.update-tmp';
            $encodedVersion = json_encode($newVersion, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

            if ($encodedVersion === false ||
                file_put_contents($versionTemp, $encodedVersion . PHP_EOL, LOCK_EX) === false ||
                !rename($versionTemp, $versionFile)) {
                @unlink($versionTemp);
                throw new RuntimeException('Cannot record installed version.');
            }

            $this->audit([
                'event' => 'system_update_installed',
                'admin_id' => $adminId,
                'package_id' => $packageId,
                'version' => $validation['new_version'],
                'files' => count($files),
                'result' => 'success',
            ]);

            $recoveryJournal->markComplete($recoveryId);
            $success = true;

            return [
                'success' => true,
                'version' => $validation['new_version'],
                'files' => count($files),
                'backup_directory' => $workRoot,
            ];
        } catch (Throwable $exception) {
            $rollbackErrors = [];

            if ($recoveryStarted && $recoveryJournal !== null && $recoveryId !== null) {
                try {
                    $recoveryResult = $recoveryJournal->restore($recoveryId);
                    $rollbackErrors = $recoveryResult['errors'] ?? [];
                    if (!($recoveryResult['success'] ?? false) && $rollbackErrors === []) {
                        $rollbackErrors[] = 'Recovery journal reported failure.';
                    }
                } catch (Throwable $rollbackException) {
                    $rollbackErrors[] = 'Recovery journal: ' . $rollbackException->getMessage();
                }
            } else {
                foreach (array_reverse($journal) as $item) {
                    try {
                        if ($item['existed']) {
                            if (!is_file($item['backup']) ||
                                !copy($item['backup'], $item['destination'])) {
                                $rollbackErrors[] = $item['path'];
                            } elseif (isset($item['permissions']) &&
                                !chmod($item['destination'], (int) $item['permissions'])) {
                                $rollbackErrors[] = $item['path'] . ' (permissions)';
                            }
                        } else {
                            if (is_file($item['destination']) &&
                                !unlink($item['destination'])) {
                                $rollbackErrors[] = $item['path'];
                            }
                        }
                    } catch (Throwable $rollbackException) {
                        $rollbackErrors[] = $item['path'];
                    }
                }
            }

            $this->audit([
                'event' => 'system_update_failed',
                'admin_id' => $adminId,
                'package_id' => $packageId,
                'result' => 'failed',
                'error' => $exception->getMessage(),
                'rollback_errors' => $rollbackErrors,
            ]);

            if ($rollbackErrors !== []) {
                Log::critical('System update rollback was incomplete.', [
                    'package_id' => $packageId,
                    'files' => $rollbackErrors,
                ]);

                // Leave maintenance mode enabled if rollback is incomplete.
                $maintenanceEnabled = false;

                throw new RuntimeException(
                    'Update failed and rollback was incomplete. The site remains in maintenance mode. Package ID: ' .
                    $packageId,
                    0,
                    $exception
                );
            }

            throw $exception;
        } finally {
            if ($maintenanceEnabled) {
                try {
                    if ($this->maintenance->up() !== 0) {
                        Log::critical('System update could not exit maintenance mode.', [
                            'package_id' => $packageId,
                            'work_directory' => $workRoot,
                        ]);
                        if ($success) {
                            throw new RuntimeException('Update files were installed, but maintenance mode could not be cleared. Package ID: ' . $packageId);
                        }
                    }
                } catch (Throwable $maintenanceException) {
                    Log::critical('System update failed while exiting maintenance mode.', [
                        'package_id' => $packageId,
                        'work_directory' => $workRoot,
                        'error' => $maintenanceException->getMessage(),
                    ]);
                    if ($success) {
                        throw new RuntimeException('Update files were installed, but maintenance mode could not be cleared. Package ID: ' . $packageId, 0, $maintenanceException);
                    }
                }
            }

            if (!$success) {
                // Preserve the backup/journal directory for manual recovery.
                Log::warning('System update attempt did not complete.', [
                    'package_id' => $packageId,
                    'work_directory' => $workRoot,
                ]);
            }
        }
    }

    private function safeDestination(string $relative): string
    {
        $root = realpath($this->appRootOverride ?? base_path());

        if ($root === false) {
            throw new RuntimeException('Application root cannot be resolved.');
        }

        $destination = $root . DIRECTORY_SEPARATOR .
            str_replace('/', DIRECTORY_SEPARATOR, $relative);

        $parent = dirname($destination);
        $existingParent = $parent;

        while (!is_dir($existingParent)) {
            $next = dirname($existingParent);
            if ($next === $existingParent) {
                throw new RuntimeException('Cannot resolve destination parent.');
            }
            $existingParent = $next;
        }

        $resolvedParent = realpath($existingParent);

        if ($resolvedParent === false ||
            ($resolvedParent !== $root && !str_starts_with($resolvedParent, $root . DIRECTORY_SEPARATOR))) {
            throw new RuntimeException('Destination resolves outside application root.');
        }

        if (is_link($destination)) {
            throw new RuntimeException('Symbolic-link destinations are forbidden.');
        }

        return $destination;
    }

    private function audit(array $record): void
    {
        $directory = $this->auditRootOverride ?? storage_path('logs/system-updates');

        if (!is_dir($directory) && !mkdir($directory, 0700, true) && !is_dir($directory)) {
            Log::critical('Could not create system update audit directory.', $record);
            return;
        }

        @chmod($directory, 0700);

        $path = $directory . '/audit.jsonl';
        $record['timestamp'] = now()->toIso8601String();

        file_put_contents(
            $path,
            json_encode($record, JSON_UNESCAPED_SLASHES) . PHP_EOL,
            FILE_APPEND | LOCK_EX
        );

        @chmod($path, 0600);
    }
}
