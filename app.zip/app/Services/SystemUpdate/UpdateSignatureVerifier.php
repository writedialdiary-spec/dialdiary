<?php

namespace App\Services\SystemUpdate;

use RuntimeException;

class UpdateSignatureVerifier
{
    private const PUBLIC_KEY_PATH =
        '/home/dialdiary/system-update-signing/team-public.pem';

    /**
     * Verify a detached RSA/SHA-256 signature over the exact manifest bytes.
     *
     * The release producer must sign the exact bytes stored as manifest.json.
     */
    public function verify(string $manifestBytes, string $signatureBase64): bool
    {
        if ($manifestBytes === '' || strlen($manifestBytes) > 1024 * 1024) {
            return false;
        }

        $signature = base64_decode($signatureBase64, true);

        if ($signature === false || $signature === '') {
            return false;
        }

        if (!is_file(self::PUBLIC_KEY_PATH) ||
            !is_readable(self::PUBLIC_KEY_PATH)) {
            throw new RuntimeException(
                'System update public verification key is unavailable.'
            );
        }

        $publicKey = openssl_pkey_get_public(
            'file://' . self::PUBLIC_KEY_PATH
        );

        if ($publicKey === false) {
            throw new RuntimeException(
                'System update public verification key could not be loaded.'
            );
        }

        $details = openssl_pkey_get_details($publicKey);

        if (
            !is_array($details) ||
            ($details['type'] ?? null) !== OPENSSL_KEYTYPE_RSA ||
            ($details['bits'] ?? 0) < 3072
        ) {
            return false;
        }

        return openssl_verify(
            $manifestBytes,
            $signature,
            $publicKey,
            OPENSSL_ALGO_SHA256
        ) === 1;
    }
}
