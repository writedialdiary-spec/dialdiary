<?php

namespace App\Services\SystemUpdate;

use RuntimeException;
use Throwable;

class UpdatePreflight
{
    private string $appRoot;
    private string $privateRoot;
    private string $workRoot;
    private UpdateRecoveryJournal $journal;
    private int $minimumFreeBytes;

    public function __construct(
        ?UpdateRecoveryJournal $journal = null,
        ?string $appRoot = null,
        ?string $privateRoot = null,
        ?string $workRoot = null,
        int $minimumFreeBytes = 1073741824
    ) {
        $this->appRoot = $appRoot ?? base_path();
        $this->privateRoot = $privateRoot ?? '/home/dialdiary/system-update-signing';
        $this->workRoot = $workRoot ?? storage_path('app/system-updates/work');
        $this->minimumFreeBytes = max(0, $minimumFreeBytes);

        if ($journal === null) {
            throw new RuntimeException(
                'An existing recovery journal instance must be supplied to keep preflight read-only.'
            );
        }

        $this->journal = $journal;
    }

    public function check(): array
    {
        $checks = [];
        $blockers = [];
        $warnings = [];

        $add = static function (
            string $name,
            bool $passed,
            string $message,
            bool $blocking = true
        ) use (&$checks, &$blockers, &$warnings): void {
            $checks[] = [
                'name' => $name,
                'passed' => $passed,
                'message' => $message,
            ];

            if (!$passed) {
                if ($blocking) {
                    $blockers[] = $message;
                } else {
                    $warnings[] = $message;
                }
            }
        };

        $app = realpath($this->appRoot);
        $add(
            'app_root',
            $app !== false && is_dir($app) && !is_link($this->appRoot),
            'Application root must exist and must not be a symlink.'
        );

        $privateSafe = is_dir($this->privateRoot)
            && !is_link($this->privateRoot)
            && is_writable($this->privateRoot);
        $add(
            'private_storage',
            $privateSafe,
            'Private update storage must exist, be writable, and not be a symlink.'
        );

        $workParent = dirname($this->workRoot);
        $workSafe = is_dir($workParent)
            && !is_link($this->workRoot)
            && !is_link($workParent)
            && is_writable($workParent);
        $add(
            'work_storage',
            $workSafe,
            'Update work storage parent must exist, be writable, and not be a symlink.'
        );

        $versionPath = $this->appRoot . DIRECTORY_SEPARATOR . 'version.json';
        $versionBytes = is_file($versionPath) && !is_link($versionPath)
            ? file_get_contents($versionPath)
            : false;
        $version = is_string($versionBytes)
            ? json_decode($versionBytes, true)
            : null;
        $versionValid = is_array($version)
            && isset($version['version'], $version['release_date'])
            && is_numeric($version['version'])
            && is_string($version['release_date'])
            && json_last_error() === JSON_ERROR_NONE;
        $add(
            'version_file',
            $versionValid,
            'version.json must be a regular file containing valid version and release_date fields.'
        );
        $journalBlockers = [];
        try {
            $journals = $this->journal->listJournals();

            foreach ($journals as $item) {
                $id = $item['id'] ?? '';
                $status = $item['status'] ?? '';

                if (!is_string($id) || !preg_match('/^[a-f0-9]{32}$/', $id)) {
                    $journalBlockers[] = 'Recovery report contains an invalid journal ID.';
                    continue;
                }

                $validation = $this->journal->validateJournal($id);
                if (!($validation['valid'] ?? false)) {
                    $journalBlockers[] = 'Recovery journal ' . $id . ' failed integrity validation.';
                    continue;
                }

                if (in_array($status, ['installing', 'rolling_back', 'rollback_failed'], true)) {
                    $journalBlockers[] = 'Recovery journal ' . $id . ' requires recovery (status: ' . $status . ').';
                } elseif (!in_array($status, ['preparing', 'complete', 'rolled_back'], true)) {
                    $journalBlockers[] = 'Recovery journal ' . $id . ' has an unknown status.';
                } elseif ($status === 'preparing') {
                    $warnings[] = 'Recovery journal ' . $id . ' is still preparing; review it before cleanup.';
                }
            }
            
foreach ($journalBlockers as $journalBlocker) {
    $blockers[] = $journalBlocker;
}

            $checks[] = [
                'name' => 'recovery_journals',
                
'passed' => count($journalBlockers) === 0,

                'message' => 'Recovery journals were inspected without changing them.',
            ];
        } catch (Throwable $exception) {
            $blockers[] = 'Recovery journals could not be safely inspected.';
            
            $checks[] = [
                'name' => 'recovery_journals',
                'passed' => false,
                'message' => 'Recovery journal inspection failed.',
            ];
        }

        $diskPath = is_dir($this->privateRoot) ? $this->privateRoot : $this->appRoot;
        $freeBytes = @disk_free_space($diskPath);
        $spaceOkay = is_float($freeBytes) || is_int($freeBytes);
        $spaceOkay = $spaceOkay && $freeBytes >= $this->minimumFreeBytes;
        $add(
            'disk_space',
            $spaceOkay,
            'Available disk space must be at least ' . $this->minimumFreeBytes . ' bytes.'
        );

        return [
            'ready' => $blockers === [],
            'checks' => $checks,
            'blockers' => array_values(array_unique($blockers)),
            'warnings' => array_values(array_unique($warnings)),
        ];
    }
}
