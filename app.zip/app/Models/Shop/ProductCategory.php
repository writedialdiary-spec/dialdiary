<?php

namespace App\Models\Shop;

use App\Models\Language;
use App\Models\Shop\ProductContent;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductCategory extends Model
{
  use HasFactory;

  /**
   * The attributes that are mass assignable.
   *
   * @var array
   */
  protected $fillable = ['language_id', 'name', 'parent_id', 'slug', 'status', 'serial_number'];

  public function language()
  {
    return $this->belongsTo(Language::class);
  }

  public function productContent()
  {
    return $this->hasMany(ProductContent::class);
  }
  public function products()
  {
    return $this->hasMany(ProductContent::class);
  }
  public function parent()
    {
        return $this->belongsTo(ProductCategory::class, 'parent_id');
    }
    
    public function children()
{
    return $this->hasMany(ProductCategory::class, 'parent_id', 'id')
        ->where('status', 1)
        ->orderBy('serial_number', 'asc');
}
    public function childrenRecursive()
{
    return $this->hasMany(ProductCategory::class, 'parent_id')->with('childrenRecursive');
}
    public function getCategoryPath()
    {
        $path = [];
        $category = $this;
    
        while ($category) {
            $path[] = $category;
            $category = $category->parent;
        }
    
        return array_reverse($path);
    }


}
