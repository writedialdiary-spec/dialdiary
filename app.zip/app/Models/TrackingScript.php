<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TrackingScript extends Model
{
    use HasFactory;
    protected $fillable = [
        'name',
        'script_head',
        'script_body',
        'is_enabled',
    ];
}
