<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Listing\Listing;
use App\Models\Vendor;
use App\Models\Listing\HotelRoom;

class RoomBooking extends Model
{
    use HasFactory;

    protected $table = 'room_bookings';

    protected $fillable = [
        'room_id',
        'listing_id',
        'listing_owner_id',
        'user_id',
        'check_in',
        'check_out',
        'guests',
        'special_requests',
        'status',
    ];

    
    public function room()
    {
        return $this->belongsTo(HotelRoom::class, 'room_id');
    }

   
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

   
    public function listingOwner()
    {
        return $this->belongsTo(Vendor::class, 'listing_owner_id');
    }
    public function listing()
    {
        return $this->belongsTo(Listing::class, 'listing_id');
    }
}
