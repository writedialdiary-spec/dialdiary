<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Listing\Listing;
use App\Models\Vendor;


class TableBooking extends Model
{
    use HasFactory;
    protected $fillable = [
        'user_id',
        'listing_id',
        'listing_owner_id',
        'owner_type',
        'type',
        'checkin_date',
        'exact_time',
        'adults',
        'kids',
        'status',
        'selected_menus',
    ];
        protected $casts = [
    'selected_menus' => 'array',
    ];
    public function listing()
    {
        return $this->belongsTo(Listing::class)->with('listing_content');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
    public function owner()
    {
        return $this->belongsTo(Vendor::class, 'listing_owner_id');
    }


}
