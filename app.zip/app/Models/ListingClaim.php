<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Listing\Listing;


class ListingClaim extends Model
{
    use HasFactory;
    protected $fillable = [
         'vendor_id', 
         'listing_id', 
         'message', 
         'status'
         ];
    public function user() {
        return $this->belongsTo(User::class);
    }
    public function vendor(){
        return $this->belongsTo(Vendor::class);
    }
    public function listing() {
    return $this->belongsTo(UnclaimedListing::class, 'listing_id', 'id');
}

}
