<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Listing\Listing;
use App\Models\Vendor;
use App\Models\Listing\ListingEvent;

class EventBooking extends Model
{
    use HasFactory;

    protected $table = 'event_bookings';

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'event_id',
        'listing_id',
        'listing_owner_id',
        'user_id',
        'tickets',
        'special_requests',
        'status',
    ];

    /**
     * Cast columns if needed.
     */
    protected $casts = [
        'tickets' => 'integer',
    ];

    /**
     * Relations
     */

    public function event()
    {
        return $this->belongsTo(ListingEvent::class, 'event_id');
    }

    public function listing()
    {
        return $this->belongsTo(Listing::class, 'listing_id');
    }

    public function owner()
    {
        return $this->belongsTo(Vendor::class, 'listing_owner_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
   

}