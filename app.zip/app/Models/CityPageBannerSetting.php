<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CityPageBannerSetting extends Model
{
    use HasFactory;
    protected $fillable = [
        'default_banner_image',
        'force_set',
    ];
}
