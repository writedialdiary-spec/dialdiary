<?php

namespace App\Models\Listing;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AutomotiveCar extends Model
{
    use HasFactory;
    Protected $table = 'listing_automotive_cars';
    protected $fillable = [
        'listing_id',
        'car_name',
        'car_photo',
        'car_price',
        'car_fuel_type',
        'car_manufacture_year',
        'car_engine_capacity',
        'car_mileage',
    ];
    public function listing()
    {
        return $this->belongsTo(Listing::class);
    }
}
