<?php

namespace App\Models\Listing;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ListingEvent extends Model
{
    use HasFactory;

    protected $table = 'listing_events';

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'listing_id',
        'event_name',
        'event_category',
        'event_start_datetime',
        'event_end_datetime',
        'event_venue_name',
        'event_venue_address',
        'event_ticket_price',
        'event_description',
        'event_photo',
        'event_status',
    ];

    /**
     * If you want to cast columns to specific types.
     */
    protected $casts = [
        'event_start_datetime' => 'datetime',
        'event_end_datetime' => 'datetime',
        'event_ticket_price' => 'float',
    ];

    /**
     * If you have a relation to Listing (optional)
     */
    public function listing()
    {
        return $this->belongsTo(Listing::class);
    }
}
