<?php

namespace App\Models\Listing;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ListingEntry extends Model
{
    use HasFactory;
    protected $fillable = [
        'state',
        'city',
        'category',
        'subcategory',
        'meta_title',
        'meta_description',
        'url',
    ];

}
