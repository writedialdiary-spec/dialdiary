<?php

namespace App\Models\Listing;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Listing\ListingContent;
use App\Models\Vendor;
use App\Models\BusinessHour;
use App\Models\Listing\HotelRoom;

class Listing extends Model
{
    use HasFactory;
    protected $fillable = [
        'feature_image',
        'vendor_id',
        'website',
        'mail',
        'phone',
        'average_rating',
        'latitude',
        'longitude',
        'video_url',
        'video_background_image',
        'status',
        'max_price',
        'min_price',
        'visibility'
    ];
   
    public function listing_content()
    {
        return $this->hasMany(ListingContent::class, 'listing_id', 'id');
    }
    public function businessHours()
    {
        return $this->hasMany(BusinessHour::class);
    }

    public function galleries()
    {
        return $this->hasMany(ListingImage::class, 'listing_id', 'id');
    }

    public function vendor()
    {
        return $this->belongsTo(Vendor::class);
    }
    public function listingProducts()
    {
        return $this->hasMany(ListingProduct::class, 'listing_id', 'id');
    }
    public function listingFaqs()
    {
        return $this->hasMany(ListingFaq::class);
    }
    public function specifications()
    {
        return $this->hasMany(ListingFeature::class, 'listing_id', 'id');
    }
    public function sociallinks()
    {
        return $this->hasMany(ListingSocialMedia::class, 'listing_id', 'id');
    }
    public function subCategories()
    {
        return $this->hasMany(ListingSubCategory::class, 'listing_category_id');
    }
    public function menus(){
        return $this->hasMany(RestaurantMenu::class);
    }
    public function rooms()
    {
        return $this->hasMany(HotelRoom::class);
    }
    public function cars(){
        return $this->hasMany(AutomotiveCar::class);
    }
    public function current_content()
    {
        return $this->hasOne(ListingContent::class, 'listing_id', 'id'); 
    }


}
