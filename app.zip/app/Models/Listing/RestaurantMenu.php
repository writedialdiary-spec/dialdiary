<?php

namespace App\Models\Listing;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RestaurantMenu extends Model
{
    use HasFactory;
    protected $fillable = [
        'listing_id',
        'menu_name',
        'menu_price',
        'menu_photo',
        'menu_type',
    ];
    protected $table = 'listing_restaurant_menus';
    public function listing()
    {
        return $this->belongsTo(Listing::class);
    }
}
