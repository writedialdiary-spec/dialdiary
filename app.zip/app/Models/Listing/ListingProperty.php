<?php

namespace App\Models\Listing;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Vendor;

class ListingProperty extends Model
{
    use HasFactory;

    protected $table = 'listing_properties';

    protected $fillable = [
        'listing_id',
        'listing_owner_id',
        'property_title',
        'property_description',
        'property_latitude',
        'property_longitude',
        'property_agent_name',
        'property_agent_number',
        'property_address',
        'property_city',
        'property_state',
        'property_price',
        'property_bed',
        'property_baths',
        'property_square',
        'property_type',
        'property_amenities',
        'property_photo',
    ];

    protected $casts = [
        'property_amenities' => 'array',
    ];

    /**
     * Relationships (if needed)
     */

    
    public function listing()
    {
        return $this->belongsTo(Listing::class, 'listing_id');
    }

    
    public function owner()
    {
        return $this->belongsTo(Vendor::class, 'listing_owner_id'); 
    }
}
