<?php

namespace App\Models\Listing;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\ListingCategory;

class ListingSubCategory extends Model
{
    use HasFactory;
    protected $fillable = ['name', 'listing_category_id', 'slug', 'icon', 'status'];

    public function category()
    {
        return $this->belongsTo(ListingCategory::class, 'listing_category_id');
    }
    
    public function listing_contents()
    {
        return $this->hasMany(ListingContent::class, 'sub_category_id'); 
        
    }

}
