<?php

namespace App\Models\Listing;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HotelRoom extends Model
{
    use HasFactory;
    protected $table = 'listing_hotel_rooms';

    protected $fillable = [
        'listing_id',
        'room_name',
        'room_price',
        'max_guests',
        'room_photo',
        'room_amenities',
        'room_description',
    ];
    public function listing()
    {
        return $this->belongsTo(Listing::class);
    }
}
