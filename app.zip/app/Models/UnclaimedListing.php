<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\ListingCategory;
use App\Models\Listing\ListingSubCategory;

class UnclaimedListing extends Model
{
    use HasFactory;
    
    protected $fillable = [
    'title',
    'slug',
    'address',
    'category_id',
	'sub_category_id',
	'country_id',
	'state_id',	
	'city_id',
	'description',
	'meta_keywords',
	'meta_description',
	'email', 
	'phone', 
	'website', 
	'zipcode', 
	'latitude', 
	'longitude',
    'is_claimed', 
    'listing_status', 
    'feature_image'
	];
	
	public function category(){
	    return $this->belongsTo(ListingCategory::class);
	}
	public function subcategory(){
	    return $this->belongsTo(ListingSubCategory::class);
	}
}
