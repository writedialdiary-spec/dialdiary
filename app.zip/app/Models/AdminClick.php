<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Admin;

class AdminClick extends Model
{
    use HasFactory;
    protected $fillable = [
        'user_id',
        'action',
        'ip_address',
        'user_agent',
    ];
    public function admin()
    {
        return $this->belongsTo(Admin::class, 'user_id');
    }
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

}
