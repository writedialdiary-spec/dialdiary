<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Report extends Model
{
    use HasFactory;
    protected $fillable = [
        'listing_id','user_id','business_name','city','state',
        'report_type','description','incorrect_fields',
        'status','is_owner','reporter_name','reporter_email',
        'ip_address','owner_response','owner_responded_at'
    ];

    protected $casts = [
        'incorrect_fields' => 'array',
        'owner_responded_at' => 'datetime'
    ];

    public function listing() {
        return $this->belongsTo(Listing::class);
    }

    public function attachments() {
        return $this->hasMany(ReportAttachment::class);
    }

    public function logs() {
        return $this->hasMany(ReportLog::class);
    }

}
