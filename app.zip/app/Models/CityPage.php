<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CityPage extends Model
{
    use HasFactory;
    protected $fillable = [
        'state',
        'city',
        'slug',
        'meta_title',
        'meta_description',
        'banner_image',
        'content',
    ];
}
