<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Listing\ListingSubCategory;
use App\Models\Location\City;

class SeoMetaData extends Model
{
    use HasFactory;
    protected $fillable = [
    'subcategory_id',
    'city_id',
    'meta_title',
    'meta_description',
    'slug',
    'custom_content',
];

    public function subcategory()
    {
        return $this->belongsTo(ListingSubCategory::class, 'subcategory_id'); 
    }
    
    public function city()
    {
        return $this->belongsTo(City::class, 'city_id'); 
    }


}
