<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Listing\ListingContent;
use App\Models\Listing\ListingSubCategory;

class ListingCategory extends Model
{
    use HasFactory;

    protected $fillable = [
        'id',
        'language_id',
        'name',
        'subcategory',
        'meta_title',
        'meta_description',
        'meta_keywords',
        'slug',
        'serial_number',
        'status',
        'icon'
    ];
    public function listing_contents()
    {
        return $this->hasMany(ListingContent::class, 'category_id');
    }
    public function subcategories()
    {
        return $this->hasMany(ListingSubCategory::class, 'listing_category_id', 'id');
    }
}
