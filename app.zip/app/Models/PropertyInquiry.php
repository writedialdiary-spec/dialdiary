<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Listing\Listing;
use App\Models\Vendor;
use App\Models\Listing\ListingProperty;

class PropertyInquiry extends Model
{
    use HasFactory;
    protected $table = 'property_inquires';
    protected $fillable = [
        'property_id',
        'listing_id',
        'listing_owner_id',
        'user_id',
        'message',
        'status',
        ];
        
    public function property()
    {
        return $this->belongsTo(ListingProperty::class, 'property_id');
    }

    public function listing()
    {
        return $this->belongsTo(Listing::class, 'listing_id');
    }

    public function owner()
    {
        return $this->belongsTo(Vendor::class, 'listing_owner_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
