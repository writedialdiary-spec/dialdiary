<?php

namespace App\Models\Journal;

use App\Models\Journal\BlogInformation;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;
use App\Models\Vendor;

class Blog extends Model
{
  use HasFactory;

  /**
   * The attributes that are mass assignable.
   *
   * @var array
   */
  protected $fillable = ['image', 'serial_number'];

  public function information()
  {
    return $this->hasMany(BlogInformation::class);
  }
  public function comments()
    {
        return $this->hasMany(BlogComment::class)->where('status', 1);
    }
  public function user()
    {
        return $this->belongsTo(User::class);
    }
    
    public function vendor()
    {
        return $this->belongsTo(Vendor::class);
    }

}
