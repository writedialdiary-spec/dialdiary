<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ReportLog extends Model
{
    use HasFactory;
    protected $fillable = ['report_id','admin_id','action','notes'];

    public function report() {
        return $this->belongsTo(Report::class);
    }
}
