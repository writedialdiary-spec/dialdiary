<?php

namespace App\Http\Helpers;

use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;

class SitemapWriter
{
    /**
     * Write a URL set sitemap file
     */
    public static function writeUrls(array $urls, string $filePath, string $bladeFile = null)
    {
        // ---- XML Sitemap ----
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL;
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL;

        foreach ($urls as $url) {
            $xml .= '  <url>' . PHP_EOL;
            $xml .= '    <loc>' . htmlspecialchars($url, ENT_XML1) . '</loc>' . PHP_EOL;
            $xml .= '    <changefreq>daily</changefreq>' . PHP_EOL;
            $xml .= '    <priority>0.8</priority>' . PHP_EOL;
            $xml .= '  </url>' . PHP_EOL;
        }

        $xml .= '</urlset>';

        Storage::disk('public')->put($filePath, $xml);

        // ---- Blade Sitemap (auto overwrite) ----
        if ($bladeFile) {
            $bladeContent = <<<BLADE
@extends('layouts.app')

@section('title', 'Sitemap')

@section('content')
<div class="container py-4">
    <h1 class="mb-4">Sitemap</h1>
    <ul>
BLADE;

            foreach ($urls as $url) {
                $bladeContent .= "\n        <li><a href=\"{{ url('$url') }}\">$url</a></li>";
            }

            $bladeContent .= <<<BLADE

    </ul>
</div>
@endsection
BLADE;

            // ✅ Ensure directory exists
            File::ensureDirectoryExists(resource_path('views/generated'));

            // ✅ Save blade file
            File::put(resource_path("views/generated/{$bladeFile}.blade.php"), $bladeContent);
        }
    }

    /**
     * Write a sitemap index file
     */
    public static function writeIndex(array $sitemaps, string $filePath, string $bladeFile = null)
    {
        // ---- XML Index ----
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL;
        $xml .= '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL;

        foreach ($sitemaps as $sitemap) {
            $xml .= '  <sitemap>' . PHP_EOL;
            $xml .= '    <loc>' . htmlspecialchars($sitemap, ENT_XML1) . '</loc>' . PHP_EOL;
            $xml .= '  </sitemap>' . PHP_EOL;
        }

        $xml .= '</sitemapindex>';

        Storage::disk('public')->put($filePath, $xml);

        // ---- Blade Index (auto overwrite) ----
        if ($bladeFile) {
            $bladeContent = <<<BLADE
@extends('layouts.app')

@section('title', 'Sitemap Index')

@section('content')
<div class="container py-4">
    <h1 class="mb-4">Sitemap Index</h1>
    <ul>
BLADE;

            foreach ($sitemaps as $sitemap) {
                $bladeContent .= "\n        <li><a href=\"$sitemap\">$sitemap</a></li>";
            }

            $bladeContent .= <<<BLADE

    </ul>
</div>
@endsection
BLADE;

            // ✅ Ensure directory exists
            File::ensureDirectoryExists(resource_path('views/generated'));

            // ✅ Save blade file
            File::put(resource_path("views/generated/{$bladeFile}.blade.php"), $bladeContent);
        }
    }
}
