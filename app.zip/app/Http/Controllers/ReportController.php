<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Report;
use App\Models\Listing\Listing;
use Illuminate\Support\Facades\Log;

class ReportController extends Controller
{
    public function create(Listing $listing)
    {
        return view('frontend.reports.create', compact('listing'));
    }

    // public function store(Request $request)
    // {
        
    //     $data = $request->validate([
    //         'listing_id'=>'nullable|exists:listings,id',
    //         'business_name'=>'required',
    //         'report_type'=>'required',
    //         'description'=>'required|min:20',
    //         'reporter_email'=>'required|email',
    //         'files.*'=>'nullable|file|mimes:jpg,png,pdf|max:2048'
    //     ]);

    //     $data['user_id'] = auth()->id();
    //     $data['ip_address'] = $request->ip();

    //     $report = Report::create($data);

    //     if ($request->hasFile('files')) {
    //         foreach ($request->file('files') as $file) {
    //             $report->attachments()->create([
    //                 'file_path'=>$file->store('reports','public'),
    //                 'file_type'=>$file->getClientMimeType()
    //             ]);
    //         }
    //     }

        

    //     return redirect()->route('report.success');
    // }


public function store(Request $request)
{
    Log::info('Report store request received', [
        'request_data' => $request->all(),
        'user_id' => auth()->id(),
    ]);

    try {
        $data = $request->validate([
            'listing_id' => 'required|exists:listings,id',
            'reason'     => 'required|string',
            'message'    => 'nullable|string',
        ]);

        Log::info('Validation passed', $data);

        $listing = Listing::findOrFail($data['listing_id']);

        Log::info('Listing found', [
            'listing_id' => $listing->id,
            'listing_content' => $listing->listing_content,
        ]);

        $report = Report::create([
            'listing_id'     => $listing->id,
            'business_name'  => optional($listing->listing_content->first())->title,
            'report_type'    => $data['reason'],
            'description'    => $data['message'],
            'reporter_email' => auth()->check() ? auth()->user()->email : null,
            'user_id'        => auth()->id(),
            'ip_address'     => $request->ip(),
        ]);

        Log::info('Report created successfully', [
            'report_id' => $report->id,
        ]);

        return back()->with('success', true);

    } catch (\Throwable $e) {

        Log::error('Report creation failed', [
            'error_message' => $e->getMessage(),
            'error_file' => $e->getFile(),
            'error_line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);

        return back()->with('error', 'Something went wrong while submitting report.');
    }
}


    public function myReports()
    {
        $reports = auth()->user()->reports()->latest()->paginate(10);
        return view('reports.my-reports', compact('reports'));
    }
    public function show(Report $report)
    {
        return view('admin.reports.show', compact('report'));
    }


}
