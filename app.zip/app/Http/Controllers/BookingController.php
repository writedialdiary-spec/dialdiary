<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TableBooking;
use App\Models\RoomBooking;
use App\Models\EventBooking;
use App\Models\PropertyInquiry;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use App\Mail\BookingStatusChanged;

class BookingController extends Controller
{
   public function hotel()
    {
        $bookings = RoomBooking::with(['room.listing.current_content', 'user', 'listingOwner'])->latest()->get();
    
        return view('admin.booking.hotel', compact('bookings'));
    }

   public function restaurant()
   {
        $bookings = TableBooking::with(['listing.current_content', 'user', 'owner'])->latest()->get();
    
        return view('admin.booking.restaurant', compact('bookings'));
   }

    public function beauty(){
        
    }
    public function event(){
        $bookings = EventBooking::with(['event.listing.current_content', 'user', 'owner'])->latest()->get();
    
        return view('admin.booking.event', compact('bookings'));
    }
    public function property(){
        $inquiries = PropertyInquiry::with(['property.listing.current_content', 'user', 'owner'])->latest()->get();
    
        return view('admin.booking.property', compact('inquiries'));
    }


    public function updateStatus(Request $request, $id)
    {
        $booking = TableBooking::findOrFail($id);
    
        $request->validate([
            'status' => 'required|in:confirmed,cancelled,rejected',
            'message' => 'nullable|string|max:1000',
        ]);
    
        $booking->status = $request->status;
        $booking->save();
    
        $emailSent = true;
    
        // Attempt to send email
        if ($booking->user && $request->filled('message')) {
            try {
                Log::info(['user email' => $booking->user->email]);
                Mail::to($booking->user->email)->send(new BookingStatusChanged($booking, $request->message));
            } catch (\Exception $e) {
                \Log::error('Email sending failed for booking ID '.$booking->id.': '.$e->getMessage());
                $emailSent = false;
            }
        }
    
        if ($emailSent) {
            return back()->with('success', 'Booking status updated and message sent successfully.');
        } else {
            return back()->with('warning', 'Booking status updated, but the message could not be sent via email.');
        }
    }
    public function updateroomStatus(Request $request, $id)
    {
        $booking = RoomBooking::findOrFail($id);
    
        $request->validate([
            'status' => 'required|in:confirmed,cancelled,rejected,pending',
            'message' => 'nullable|string|max:1000',
        ]);
    
        $booking->status = $request->status;
        $booking->save();
    
        $emailSent = true;
    
        // Attempt to send email to the user
        if ($booking->user && $request->filled('message')) {
            try {
                \Log::info(['user email' => $booking->user->email]);
                \Mail::to($booking->user->email)->send(new BookingStatusChanged($booking, $request->message));
            } catch (\Exception $e) {
                \Log::error('Email sending failed for room booking ID '.$booking->id.': '.$e->getMessage());
                $emailSent = false;
            }
        }
    
        if ($emailSent) {
            return back()->with('success', 'Room booking status updated and message sent successfully.');
        } else {
            return back()->with('warning', 'Room booking status updated, but the message could not be sent via email.');
        }
    }
    public function updateEventStatus(Request $request, $id)
    {
        $booking = EventBooking::findOrFail($id);
    
        $request->validate([
            'status' => 'required|in:confirmed,cancelled,rejected,pending',
            'message' => 'nullable|string|max:1000',
        ]);
    
        $booking->status = $request->status;
        $booking->save();
    
        $emailSent = true;
    
        // Attempt to send email to the user
        if ($booking->user && $request->filled('message')) {
            try {
                \Log::info(['user email' => $booking->user->email]);
                \Mail::to($booking->user->email)->send(new BookingStatusChanged($booking, $request->message));
            } catch (\Exception $e) {
                \Log::error('Email sending failed for room booking ID '.$booking->id.': '.$e->getMessage());
                $emailSent = false;
            }
        }
    
        if ($emailSent) {
            return back()->with('success', 'Event booking status updated and message sent successfully.');
        } else {
            return back()->with('warning', 'Event booking status updated, but the message could not be sent via email.');
        }
    }
    public function updatePropertyStatus(Request $request, $id)
    {
        $booking = PropertyInquiry::findOrFail($id);
    
        $request->validate([
            'status' => 'required|in:confirmed,cancelled,rejected,pending',
            'message' => 'nullable|string|max:1000',
        ]);
    
        $booking->status = $request->status;
        $booking->save();
    
        $emailSent = true;
    
        // Attempt to send email to the user
        if ($booking->user && $request->filled('message')) {
            try {
                \Log::info(['user email' => $booking->user->email]);
                \Mail::to($booking->user->email)->send(new BookingStatusChanged($booking, $request->message));
            } catch (\Exception $e) {
                \Log::error('Email sending failed for room booking ID '.$booking->id.': '.$e->getMessage());
                $emailSent = false;
            }
        }
    
        if ($emailSent) {
            return back()->with('success', 'Property Inquiry status updated and message sent successfully.');
        } else {
            return back()->with('warning', 'Property Inquiry status updated, but the message could not be sent via email.');
        }
    }



}