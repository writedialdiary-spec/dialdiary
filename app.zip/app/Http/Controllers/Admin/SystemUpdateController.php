<?php

namespace App\Http\Controllers\Admin;

use App\Services\SystemUpdate\UpdateInstaller;
use App\Http\Controllers\Controller;
use App\Services\SystemUpdate\UpdatePackageValidator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Throwable;

class SystemUpdateController extends Controller
{
    public function index()
    {
        return view('admin.system-update.index', $this->pageData());
    }

    
public function upload(
    Request $request,
    UpdatePackageValidator $validator,
    UpdateInstaller $installer
) {
    $request->validate([
        'package' => ['required', 'file', 'mimes:zip', 'max:524288'],
    ]);

    $directory = storage_path('app/system-updates/incoming');

    if (
        !is_dir($directory) &&
        !mkdir($directory, 0700, true) &&
        !is_dir($directory)
    ) {
        return back()->withErrors([
            'package' => 'Private upload storage could not be created.',
        ]);
    }

    @chmod($directory, 0700);

    if (!is_writable($directory) || is_link($directory)) {
        return back()->withErrors([
            'package' => 'Private upload storage is unavailable.',
        ]);
    }

    $filename = 'upload-' . Str::uuid() . '.zip';
    $packagePath = $directory . DIRECTORY_SEPARATOR . $filename;
    $originalName = $request->file('package')->getClientOriginalName();

    try {
        $request->file('package')->move($directory, $filename);
        @chmod($packagePath, 0600);

        $result = $validator->validate($packagePath);

        if (!($result['valid'] ?? false)) {
            return view('admin.system-update.index', $this->pageData([
                'validationResult' => $result,
                'uploadedPackageName' => $originalName,
            ]));
        }

        $installation = $installer->install(
            $packagePath,
            (int) auth('admin')->id()
        );

        return view('admin.system-update.index', $this->pageData([
            'validationResult' => $result,
            'installationResult' => $installation,
            'uploadedPackageName' => $originalName,
        ]));
    } catch (Throwable $exception) {
        Log::error('System update operation failed.', [
            'exception_class' => get_class($exception),
        ]);

        return back()->withErrors([
            'package' => 'The update could not be completed. Check the system update audit log.',
        ]);
    } finally {
        if (is_file($packagePath) && !is_link($packagePath)) {
            @unlink($packagePath);
        }
    }
}


    private function pageData(): array
{
    $versionPath = base_path('version.json');

    $versionData = [
        'version' => 'Unknown',
        'release_date' => null,
    ];

    if (is_file($versionPath) && is_readable($versionPath)) {
        try {
            $contents = file_get_contents($versionPath);

            if (is_string($contents) && $contents !== '') {
                $decoded = json_decode(
                    $contents,
                    true,
                    512,
                    JSON_THROW_ON_ERROR
                );

                if (is_array($decoded)) {
                    $version = $decoded['version'] ?? null;
                    $releaseDate = $decoded['release_date'] ?? null;

                    if (
                        is_string($version) &&
                        preg_match(
                            '/^\d+(?:\.\d+){0,3}$/',
                            $version
                        )
                    ) {
                        $versionData['version'] = $version;
                    }

                    if (
                        is_string($releaseDate) &&
                        $releaseDate !== '' &&
                        strtotime($releaseDate) !== false
                    ) {
                        $versionData['release_date'] = $releaseDate;
                    }
                }
            }
        } catch (\Throwable $exception) {
            \Illuminate\Support\Facades\Log::warning(
                'Unable to read system update version metadata.',
                ['exception_class' => get_class($exception)]
            );
        }
    }

    return [
        'versionData' => $versionData,
        'laravelVersion' => app()->version(),
        'phpVersion' => PHP_VERSION,
        'environment' => app()->environment(),
    ];
}
}
