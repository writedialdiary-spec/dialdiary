<?php

namespace App\Http\Controllers\Admin\Journal;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Journal\BlogComment;

class BlogCommentController extends Controller
{
    public function index()
    {
        $comments = BlogComment::with(['user', 'vendor'])->get();

      
        return view('admin.journal.blog.comments', compact('comments'));
    }

    public function approve($id)
    {
        $comment = BlogComment::findOrFail($id);
        $comment->status = 1;
        $comment->save();

        return back()->with('success', 'Comment approved successfully.');
    }

    public function destroy($id)
    {
        BlogComment::findOrFail($id)->delete();
        return back()->with('success', 'Comment deleted successfully.');
    }
}
