<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ListingClaim;
use App\Mail\ClaimApprovedMail;
use App\Models\Toggle;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Mail;
use App\Models\Language;
use App\Models\UnclaimedListing;
use Illuminate\Support\Str;
use App\Models\Listing\Listing;
use App\Models\Listing\ListingContent;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Mail\ClaimRejectedMail;



class ListingClaimAdminController extends Controller
{
    public function index()
    {
        $claims = ListingClaim::with('vendor', 'listing')->latest()->get();
        return view('admin.claims.index', compact('claims'));
    }   
    private function createListingFromClaim(ListingClaim $claim)
    {
   

    DB::transaction(function () use ($claim) {
        $vendor = $claim->vendor;

        if (!$vendor) {
            throw new \Exception('No vendor associated with this claim.');
        }

        $languages = Language::all();
        $unclaimed = UnclaimedListing::find($claim->listing_id);
        
        $listing = Listing::create([
            'vendor_id' => $vendor->id,
            'feature_image' => $unclaimed->feature_image,
            'video_background_image' => null,
            'video_url' => null,
            'status' => 1,
            'visibility' => 1
            
        ]);

        
        foreach ($languages as $language) {
            $listingContent = new ListingContent();
            $listingContent->language_id = 20;
            $listingContent->listing_id = $listing->id;
            $listingContent->title = $unclaimed->title ?? 'Default Title';
            $listingContent->slug = createSlug($unclaimed->title);
            $listingContent->category_id = $unclaimed->category_id;
            $listingContent->sub_category_id = $unclaimed->sub_category_id;
            $listingContent->country_id = $unclaimed->country_id;
            $listingContent->state_id = $unclaimed->state_id;
            $listingContent->city_id = $unclaimed->city_id;
            $listingContent->address = $unclaimed->address ?? 'N/A';
            $listingContent->aminities = json_encode([]);
            $listingContent->description = $unclaimed->description ?? '';
            $listingContent->meta_keyword = $unclaimed->meta_keywords;
            $listingContent->meta_description = $unclaimed->meta_description;
            $listingContent->save();
        }

        
        
    });
}

    public function approve($id)
    {
        $claim = ListingClaim::findOrFail($id);
        

        $claim->status = 'approved';
        $claim->save();
        
        $this->createListingFromClaim($claim);
        if ($claim->listing_id) {
            UnclaimedListing::where('id', $claim->listing_id)->update(['is_claimed' => 1]);
        }
        Mail::to($claim->vendor->email)->queue(new ClaimApprovedMail($claim));
        
        return back()->with('success', 'Claim approved. Listing ownership updated.');
    }

    public function reject($id)
    {
        $claim = ListingClaim::findOrFail($id);
        $claim->status = 'rejected';
        $claim->save();
        Mail::to($claim->vendor->email)->queue(new ClaimRejectedMail($claim));
        return back()->with('error', 'Claim rejected.');
    }
    public function create(){
        $languages = Language::get();
        $information['languages'] = $languages;
        return view('admin.listing_claims.create', $information);
    }




public function import(Request $request)
{
    Log::info('=== Import request started ===');
    $request->validate([
        'import_file' => 'required|mimes:csv,txt',
    ]);

    try {
        // Performance settings for large files
        ini_set('max_execution_time', 0);
        ini_set('memory_limit', '-1');

        $file = $request->file('import_file');
        $handle = fopen($file->getRealPath(), 'r');

        // Skip header row
        $header = fgetcsv($handle);

        $insertedCount = 0;
        $updatedCount  = 0;
        $skippedCount  = 0;
        $lineNumber    = 0;

        $chunkSize = 500;
        $batch     = [];

        while (($row = fgetcsv($handle, 1000, ',')) !== false) {
            $lineNumber++;

            $title = preg_replace('/[^\PC\s]/u', '', $row[0] ?? '');
            $phone = $row[6] ?? null;
            $email = $row[13] ?? null;
            
            $categoryName    = $row[8] ?? null;   
            $subCategoryName = $row[9] ?? null;
            
            $categoryId = $this->resolveCategoryId($categoryName);
            $subCategoryId = $this->resolveCategoryId($subCategoryName, $categoryId);

            if (!$title) {
                $skippedCount++;
                continue;
            }

            $slug = Str::slug($title);

            $data = [
                'title'            => $title,
                'address'          => $row[1] ?? null,
                'city_id'          => $row[2] ?? null,
                'state_id'         => $row[3] ?? null,
                'zipcode'          => $row[4] ?? null,
                'country_id'       => $row[5] ?? null,
                'phone'            => $phone,
                'website'          => $row[7] ?? null,
                'category_id'      => $categoryId,
                'sub_category_id'  => $subCategoryId,
                'description'      => $row[10] ?? null,
                'meta_keywords'    => $row[11] ?? null,
                'meta_description' => $row[12] ?? null,
                'email'            => $email,
                'latitude'         => $row[14] ?? null,
                'longitude'        => $row[15] ?? null,
                'is_claimed'       => $row[16] ?? 0,
                'listing_status'   => $row[17] ?? 'pending',
            ];

            $data['slug'] = $slug;

            $batch[] = $data;

            // Process batch when chunk size reached
            if (count($batch) >= $chunkSize) {
                [$inserted, $updated] = $this->processBatch($batch);
                $insertedCount += $inserted;
                $updatedCount  += $updated;
                $batch = []; // reset
            }
        }

        // Process any remaining rows
        if (!empty($batch)) {
            [$inserted, $updated] = $this->processBatch($batch);
            $insertedCount += $inserted;
            $updatedCount  += $updated;
        }

        fclose($handle);

        Log::info('Import summary', [
            'inserted' => $insertedCount,
            'updated'  => $updatedCount,
            'skipped'  => $skippedCount,
            'total'    => $lineNumber,
        ]);

        $message = "Listings imported successfully. 
                    Inserted: {$insertedCount}, 
                    Updated: {$updatedCount}, 
                    Skipped: {$skippedCount}.";

        return redirect()->back()->with('success', $message);

    } catch (\Exception $e) {
        Log::error('Import failed', ['error' => $e->getMessage()]);
        return back()->with('error', 'Import failed: ' . $e->getMessage());
    }
}

/**
 * Process a batch of rows (insert/update).
 *
 * @param array $batch
 * @return array [$insertedCount, $updatedCount]
 */
private function processBatch(array $batch): array
{
    $inserted = 0;
    $updated  = 0;

    foreach ($batch as $data) {
        $existing = UnclaimedListing::where('title', $data['title'])
            ->where('phone', $data['phone'])
            ->where('email', $data['email'])
            ->first();

        if ($existing) {
            $existing->update($data);
            $updated++;
        } else {
            // unique slug generation
            $originalSlug = $data['slug'];
            $count = 1;
            while (UnclaimedListing::where('slug', $data['slug'])->exists()) {
                $data['slug'] = $originalSlug . '-' . $count++;
            }

            UnclaimedListing::create($data);
            $inserted++;
        }
    }

    return [$inserted, $updated];
}

protected function resolveCategoryId($name, $parentId = null)
{
    if (empty($name)) {
        return null;
    }

   
    $query = \App\Models\ListingCategory::where('name', $name);

    if ($parentId) {
        $query->where('id', $parentId);
    }

    $category = $query->first();

    // If not found, create (optional)
    if (!$category) {
        $category = \App\Models\ListingCategory::create([
            'name'      => $name,
            'slug'      => \Str::slug($name),
            'parent_id' => $parentId,
        ]);
    }

    return $category->id;
}




public function export()
{
    $listings = UnclaimedListing::all();

    $columns = [
        'title',
        'address',
        'city_id',
        'state_id',
        'zipcode',
        'country_id',
        'phone',
        'website',
        'category_id',
        'sub_category_id',
        'description',
        'meta_keywords',
        'meta_description',
        'email',
        'slug',
        'latitude',
        'longitude',
        'is_claimed',
        'listing_status',
    ];

    $csvData = [];
    $csvData[] = $columns; // Header row

    foreach ($listings as $listing) {
        $row = [];
        foreach ($columns as $column) {
            $row[] = $listing->{$column};
        }
        $csvData[] = $row;
    }

    $filename = 'unclaimed_listings_export_' . date('Ymd_His') . '.csv';
    $handle = fopen('php://temp', 'r+');

    foreach ($csvData as $row) {
        fputcsv($handle, $row);
    }

    rewind($handle);
    $csvContents = stream_get_contents($handle);
    fclose($handle);

    return Response::make($csvContents, 200, [
        'Content-Type' => 'text/csv',
        'Content-Disposition' => "attachment; filename=$filename",
    ]);
}

   public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'feature_image' => 'nullable|image|mimes:jpeg,jpg,png,webp|max:2048',
            'slug' => 'nullable|string', // Will be overridden below
            'address' => 'nullable|string',
            'category_id' => 'nullable|integer',
            'sub_category_id' => 'nullable|integer',
            'country_id' => 'nullable|string',
            'state_id' => 'nullable|string',
            'city_id' => 'nullable|string',
            'email' => 'nullable|email|max:255',
            'phone' => 'nullable|string|max:20',
            'website' => 'nullable|url|max:255',
            'description' => 'nullable|string',
            'meta_keywords' => 'nullable|string',
            'meta_description' => 'nullable|string',
            'zipcode' => 'nullable|string|max:10',
            'latitide' => 'nullable|numeric',
            'longitude' => 'nullable|numeric',
            'status' => 'nullable|boolean',
            
        ]);
    
        $slug = Str::slug($validated['title']);
        $originalSlug = $slug;
        $count = 1;
    
        while (UnclaimedListing::where('slug', $slug)->exists()) {
            $slug = $originalSlug . '-' . $count++;
        }
    
        $validated['slug'] = $slug;
        
        if ($request->hasFile('feature_image') && $request->file('feature_image')->isValid()) {
            $image = $request->file('feature_image');
            $imageName = time() . '_' . uniqid() . '.' . $image->getClientOriginalExtension();
            $imagePath = public_path('assets/img/listing/');
    
            if (!file_exists($imagePath)) {
                mkdir($imagePath, 0777, true);
            }
    
            \Image::make($image)
                ->resize(600, 400, function ($constraint) {
                    $constraint->upsize();
                })
                ->save($imagePath . $imageName, 75);
    
            $validated['feature_image'] = 'assets/img/listing/unclaimed/' . $imageName;
        }
    
    
        UnclaimedListing::create($validated);
    
        return redirect()->back()->with('success', 'Unclaimed listing added successfully.');
    }
   public function unclaimed(){
       $unclaimed = UnclaimedListing::with('category')->latest()->paginate(20);
       $item = Toggle::where('title', 'unclaimed listings')
              ->first();
       return view('admin.listing_claims.unclaimed', compact('unclaimed', 'item'));
   }
 
    // public function store(Request $request)
    // {
    //     $validated = $request->validate([
    //         'title' => 'required|string|max:255',
    //         'address' => 'nullable|string',
    //         'category_id' => 'nullable|integer',
    //         'sub_category_id' => 'nullable|integer',
    //         'country_id' => 'nullable|integer',
    //         'state_id' => 'nullable|integer',
    //         'city_id' => 'nullable|integer',
    //         'description' => 'nullable|string',
    //         'meta_keywords' => 'nullable|string',
    //         'meta_description' => 'nullable|string',
    //     ]);
    
    //     // Dynamically generate a unique slug from the title
    //     $slug = Str::slug($validated['title']);
    //     $originalSlug = $slug;
    //     $count = 1;
    
    //     // Ensure uniqueness
    //     while (UnclaimedListing::where('slug', $slug)->exists()) {
    //         $slug = $originalSlug . '-' . $count++;
    //     }
    
    //     $validated['slug'] = $slug;
    
    //     UnclaimedListing::create($validated);
    
    //     return redirect()->back()->with('success', 'Unclaimed listing added successfully.');
    // }

    public function toggleVisibility(Request $request)
{
    $item = Toggle::find($request->id);

    if (!$item) {
        return redirect()->back()->with('error', 'Item not found');
    }

    // Toggle the show field
    $item->show = $item->show ? 0 : 1;
    $item->save();

    return redirect()->back()->with('success', 'Visibility updated successfully');
}


}
