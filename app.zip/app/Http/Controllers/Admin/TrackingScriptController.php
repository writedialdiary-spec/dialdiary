<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\TrackingScript;
use Illuminate\Http\Request;

class TrackingScriptController extends Controller
{
    public function index()
    {
        $scripts = TrackingScript::orderBy('id', 'desc')->get();
        return view('admin.tracking_scripts.index', compact('scripts'));
    }
    public function create()
    {
        return view('admin.tracking_scripts.create');
    }
    
    public function edit($id)
    {
        $script = TrackingScript::findOrFail($id);
        return view('admin.tracking_scripts.edit', compact('script'));
    }
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'script_head' => 'nullable',
            'script_body' => 'nullable',
            'is_enabled' => 'boolean',
        ]);
    
        TrackingScript::create([
            'name' => $request->name,
            'script_head' => $request->script_head,
            'script_body' => $request->script_body,
            'is_enabled' => $request->has('is_enabled')? 1 : 0,
        ]);
    
        return redirect()->route('admin.tracking_scripts.index')->with('success', 'Script added successfully.');
    }
    
    public function update(Request $request, $id)
    {
        $script = TrackingScript::findOrFail($id);
    
        $request->validate([
            'name' => 'required|string|max:255',
            'script_head' => 'nullable',
            'script_body' => 'nullable',
            'is_enabled' => 'boolean',
        ]);
    
        $script->update([
            'name' => $request->name,
            'script_head' => $request->script_head,
            'script_body' => $request->script_body,
            'is_enabled' => $request->has('is_enabled') ? 1 : 0,
        ]);
    
        return redirect()->route('admin.tracking_scripts.index')->with('success', 'Script updated successfully.');
    }
    public function delete($id){
         $script = TrackingScript::findOrFail($id);
        $script->delete();
    
        return redirect()->route('admin.tracking_scripts.index')->with('success', 'Script deleted successfully.');
    }

}
