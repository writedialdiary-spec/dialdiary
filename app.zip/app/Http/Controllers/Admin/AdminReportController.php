<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Report;

class AdminReportController extends Controller
{
     public function index()
    {
        $reports = Report::latest()->paginate(20);
        return view('admin.reports.index', compact('reports'));
    }

    public function show(Report $report)
    {
        return view('admin.reports.show', compact('report'));
    }

    public function updateStatus(Request $request, Report $report)
    {
        $request->validate([
            'status' => 'required|in:pending,under_review,resolved,rejected,approved',
        ]);
    
        $report->update([
            'status' => $request->status
        ]);
    
        
        
        return response()->json([
            'success' => true,
            'status' => $request->status,
            'label' => ucfirst(str_replace('_', ' ', $request->status))
        ]);
    }


//   public function updateStatus(Report $report)
// {
//     $report->update([
//         'status' => 'resolved'
//     ]);

//     return back()->with('success', 'Report marked as resolved');
// }


}
