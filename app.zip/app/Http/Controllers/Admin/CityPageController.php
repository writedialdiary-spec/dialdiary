<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CityPage; 
use App\Models\Location\City;
use App\Models\Location\State;
use Illuminate\Support\Str;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\Log;
use App\Models\Location\Country;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Session;
use App\Rules\ImageMimeTypeRule;
use Illuminate\Support\Facades\Response;
use App\Models\CityPageBannerSetting;

class CityPageController extends Controller
{
    public function index()
    {
        $cityPages = CityPage::latest()->take(20)->get();

        return view('admin.city-pages.index', compact('cityPages'));
    }
    public function getCityPageData(Request $request)
{
    $data = CityPage::select('id', 'state', 'city', 'slug', 'meta_title', 'meta_description','content','banner_image');

    return DataTables::of($data)
        ->addColumn('checkbox', function ($row) {
            return '<input type="checkbox" class="bulk-check" data-val="' . $row->id . '">';
        })
        ->editColumn('slug', function ($row) {
            $url = url('location/' . $row->slug);
            return '<a href="' . $url . '" target="_blank">' . $row->slug . '</a>';
        })
        ->addColumn('actions', function ($row) {
            return '<a class="btn btn-secondary btn-sm mr-1 mt-1" href="' . route('admin.city-pages.edit', $row->id) . '">
                        <span class="btn-label"><i class="fas fa-edit"></i></span>
                    </a>
                    <a class="btn btn-danger btn-sm mt-1 deleteBtn" href="' . route('admin.city-pages.destroy', $row->id) . '">
                        <span class="btn-label"><i class="fas fa-trash"></i></span>
                    </a>';
        })
        ->rawColumns(['checkbox', 'actions', 'slug']) // 👈 added slug here
        ->make(true);
}

    public function edit($id)
    {
        $cityPage = CityPage::findOrFail($id);
        return view('admin.city-pages.edit', compact('cityPage'));
    }

    public function syncCityPages(Request $request)
    {
        try {
            $cities = City::all();
    
            foreach ($cities as $city) {
                $stateName = '';
                if ($city->state_id) {
                    $state = State::find($city->state_id);
                    if ($state) {
                        $stateName = $state->name;
                    }
                }
    
                $citySlug = Str::slug($city->name);
                $stateSlug = Str::slug($stateName);
                $slug = "{$stateSlug}/{$citySlug}";
    
                if (CityPage::where('slug', $slug)->exists()) {
                    continue;
                }
    
                $metaTitle = "Find Top Services in {$city->name} – Dial Diary";
                $metaDescription = "Discover trusted services in {$city->name}. Browse verified listings, ratings, and reviews on Dial Diary.";
    
                CityPage::create([
                    'state' => $stateName,
                    'city' => $city->name,
                    'slug' => $slug,
                    'meta_title' => $metaTitle,
                    'meta_description' => $metaDescription,
                ]);
            }
    
            return redirect()->back()->with('success', 'City pages synced successfully!');
        } catch (\Exception $e) {
            
            return redirect()->back()->with('error', 'Failed to sync city pages. Please try again.');
        }
    }
    public function update(Request $request)
{
   
    
    
    if ($request->has('id')) {
        Log::info('CityPage ID received: ' . $request->id);
    } else {
        Log::warning('CityPage ID not found in request');
    }

    $totalCountry = Country::where('language_id', $request->language_id)->count();
    $countryRequired = $totalCountry > 0;

    $totalState = State::where('country_id', $request->country_id)->count();
    $stateRequired = $totalState > 0;

    $rules = [
        'country_id' => $countryRequired ? 'required' : '',
        'state_id' => $stateRequired ? 'required' : '',
        'meta_title' => 'nullable|string|max:255',
        'meta_description' => 'nullable|string|max:500',
        'slug' => 'required|string|max:255|unique:city_pages,slug,' . $request->id,
        'content' => 'nullable|string',
    ];

    if ($request->hasFile('image')) {
        $rules['image'] = [new ImageMimeTypeRule()];
    }

    $validator = Validator::make($request->all(), $rules);

    if ($validator->fails()) {
        Log::warning('Validation failed', $validator->errors()->toArray());
        return response()->json([
            'errors' => $validator->getMessageBag()
        ], 400);
    }

    $cityPage = CityPage::find($request->id);
    if (!$cityPage) {

        return response()->json(['error' => 'City Page not found'], 404);
    }
    $in = $request->all();

    if ($request->hasFile('image')) {
        try {
            if ($cityPage->banner_image && file_exists(public_path('assets/img/citypages/' . $cityPage->banner_image))) {
                unlink(public_path('assets/img/citypages/' . $cityPage->banner_image));
            }
    
            $img = $request->file('image');
            $filename = uniqid() . '.' . $img->getClientOriginalExtension();
            $directory = public_path('assets/img/citypages/');
    
            if (!is_dir($directory)) {
                if (!mkdir($directory, 0775, true) && !is_dir($directory)) {
                    Log::error('Failed to create directory for citypages images at: ' . $directory);
                    return response()->json(['error' => 'Failed to create directory for citypages images.'], 500);
                }
            }
    
            $img->move($directory, $filename);
            $in['banner_image'] = $filename; // keep this key as-is if the database column is still banner_image
    
        } catch (\Exception $e) {
            Log::error('Image upload error: ' . $e->getMessage());
            return response()->json(['error' => 'Error uploading image.'], 500);
        }
    }


    if ($totalState < 1) {
        $in['state_id'] = null;
    }

    $cityPage->update($in);

    Session::flash('success', 'City Page updated successfully!');

    

    return redirect()->route('admin.city-pages.index')->with('success', 'City page updated successfully!');

}

    public function destroy(Request $request, $id)
    {
        
        $cityPage = CityPage::findOrFail($id);
        
        if ($cityPage->image && file_exists(public_path('assets/img/city-pages/' . $cityPage->image))) {
            unlink(public_path('assets/img/city-pages/' . $cityPage->image));
        }
    
        $cityPage->delete();
    
        return redirect()->route('admin.city-pages.index')->with('success', 'City page deleted successfully!');
    }

    public function bulkDestroy(Request $request)
    {
        $ids = $request->ids;
        
        if (empty($ids)) {
            return redirect()->back()->with('error', 'No items selected for deletion.');
        }
    
        CityPage::whereIn('id', $ids)->delete();
        return response()->json(['status' => 'success', 'message' => 'Selected city pages deleted successfully!']);
    }
    public function banner()
    {
        $setting = CityPageBannerSetting::first(); 
        return view('admin.city-pages.citybanner', compact('setting'));
    }
    
    
   
public function updateBanner(Request $request)
{
    Log::info('Updating city page default banner');

    
    $rules = [
        'banner_image' => 'nullable|image', 
        'force_set'    => 'sometimes|boolean',
    ];

    $validator = Validator::make($request->all(), $rules);

    if ($validator->fails()) {
        $validator->getMessageBag()->add('error', 'true');
        return response()->json($validator->errors(), 422);
    }

    
    $setting = CityPageBannerSetting::first() ?? new CityPageBannerSetting();

    
    if ($request->hasFile('banner_image')) {
        try {
            // Delete old file if present
            if (!empty($setting->banner_image)) {
                $oldPath = public_path('assets/img/location/city/' . $setting->banner_image);
                if (is_file($oldPath)) {
                    @unlink($oldPath);
                }
            }

            $img = $request->file('banner_image');
            $filename = uniqid() . '.' . $img->getClientOriginalExtension();

            $directory = public_path('assets/img/location/city/');
            if (!is_dir($directory)) {
                @mkdir($directory, 0775, true);
            }

            // Move uploaded file
            $img->move($directory, $filename);

            // Save just the filename in DB
            $setting->banner_image = $filename;

        } catch (\Exception $e) {
            Log::error('CityPage default banner upload error: ' . $e->getMessage());
            return response()->json(['error' => 'Error uploading image.'], 500);
        }
    }

    // Checkbox handling: unchecked means false (0)
    $setting->force_set = $request->boolean('force_set', false) ? 1 : 0;

    $setting->save();

    return response()->json([
        'status'  => 'success',
        'message' => 'Banner settings updated successfully!',
        'data'    => [
            'banner_image' => $setting->banner_image,
            'force_set'    => (bool) $setting->force_set,
        ],
    ]);
}

    

    
    public function storeBanner(Request $request)
    {
        $request->validate([
            'default_banner' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            'force_set'      => 'nullable|boolean',
        ]);

        $path = null;
        if ($request->hasFile('default_banner')) {
            $path = $request->file('default_banner')->store('banners', 'public');
        }

        CityPageBannerSetting::create([
            'default_banner' => $path,
            'force_set'      => $request->boolean('force_set'),
        ]);

        return redirect()->route('admin.city-banner-settings.index')
                         ->with('success', 'City page banner setting saved successfully.');
    }
    public function editBanner()
    {
        $setting = CityPageBannerSetting::first();
        return view('admin.city-pages.citybanner', compact('setting'));
    }

    


}
