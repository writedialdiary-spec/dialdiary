<?php

namespace App\Http\Controllers\Admin\Listing\Location;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Language;
use App\Models\Listing\ListingContent;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Validator;
use App\Models\Location\Country;
use App\Models\Location\State;
use App\Models\Location\City;
use App\Rules\ImageMimeTypeRule;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;
use Yajra\DataTables\Facades\DataTables;



class CityController extends Controller
{
    public function index(Request $request)
    {
        $language = Language::query()->where('code', '=', $request->language)->firstOrFail();
        $information['countries'] = $language->countryInfo()->orderByDesc('id')->get();
        $information['states'] = $language->stateInfo()->orderByDesc('id')->get();
        $information['stateCount'] = $language->stateInfo()->orderByDesc('id')->count();
        $information['cities'] = $language->cityInfo()->orderByDesc('id')->get();
        $information['langs'] = Language::all();
        $information['language'] = $language;

        return view('admin.listing.location.city.index', $information);
    }
    

    public function getCitiesData(Request $request)
    {
        $language = Language::where('code', $request->language)->firstOrFail();
    
        $cities = City::with(['country:id,name', 'state:id,name'])
            ->where('language_id', $language->id)
            ->select(['id', 'name', 'language_id', 'country_id', 'state_id', 'county', 'feature_image']);
    
        // 👇 Apply search manually
        if ($search = $request->input('search.value')) {
            $cities->where(function ($query) use ($search) {
                $query->where('name', 'like', "%{$search}%")
                      ->orWhere('county', 'like', "%{$search}%")
                      ->orWhereHas('country', function ($q) use ($search) {
                          $q->where('name', 'like', "%{$search}%");
                      })
                      ->orWhereHas('state', function ($q) use ($search) {
                          $q->where('name', 'like', "%{$search}%");
                      });
            });
        }
    
        return DataTables::of($cities)
            ->addColumn('checkbox', fn($row) =>
                '<input type="checkbox" class="bulk-check" data-val="' . $row->id . '">'
            )
            ->addColumn('country', fn($row) =>
                optional($row->country)->name ?: '--'
            )
            ->addColumn('state', fn($row) =>
                optional($row->state)->name ?: '--'
            )
            ->addColumn('city', fn($row) =>
                strlen($row->name) > 20 ? mb_substr($row->name, 0, 20, 'UTF-8') . '...' : $row->name
            )
            ->addColumn('county', fn($row) => $row->county)
            ->addColumn('actions', function ($row) {
                $stateCount = \App\Models\Location\State::where([
                    ['language_id', $row->language_id],
                    ['country_id', $row->country_id],
                ])->count();
    
                $okValue = $stateCount !== 0 ? 'OK' : '';
    
                $edit = '<a class="btn btn-secondary btn-sm mr-1 mt-1 editBtn" href="#" data-toggle="modal"
                            data-target="#editModal"
                            data-id="' . $row->id . '"
                            data-country_id="' . $row->country_id . '"
                            data-state_id="' . $row->state_id . '"
                            data-county="' . $row->county .'"
                            data-ok="' . $okValue . '"
                            data-name="' . e($row->name) . '"
                            data-image="' . asset('assets/img/location/city/' . $row->feature_image) . '">
                            <span class="btn-label"><i class="fas fa-edit"></i></span>
                        </a>';
    
                $delete = '<form class="deleteForm d-inline-block"
                                action="' . route('admin.listing_specification.location.delete_city', ['id' => $row->id]) . '"
                                method="POST">' .
                            csrf_field() . '
                            <button type="submit" class="btn btn-danger btn-sm mt-1 deleteBtn">
                                <span class="btn-label"><i class="fas fa-trash"></i></span>
                            </button>
                        </form>';
    
                return $edit . ' ' . $delete;
            })
            ->rawColumns(['checkbox', 'actions'])
            ->make(true);
    }

    public function getCountry($language_id)
    {
        $countries = Country::where('language_id', $language_id)->get();
        $states = State::where('language_id', $language_id)->get();

        return response()->json([
            'status' => 'success',
            'countries' => $countries,
            'states' => $states
        ], 200);
    }

    public function getState($country)
    {
        $states = State::where('country_id', $country)->get();
        return response()->json(['status' => 'success', 'states' => $states], 200);
    }

    public function store(Request $request)
    {
        $totalCountry = Country::Where('language_id', $request->m_language_id)->count();
        if ($totalCountry > 0) {
            $country = true;
            $totalState = State::Where('country_id', $request->country_id)->count();
            if ($totalState > 0) {
                $state = true;
            } else {
                $state = false;
            }
        } else {
            $country = false;
            $totalState = State::Where('language_id', $request->m_language_id)->count();
            if ($totalState > 0) {
                $state = true;
            } else {
                $state = false;
            }
        }

        $rules = [
            'm_language_id' => 'required',
            'feature_image' => '',
            'name' => 'required',
            'country_id' => $country ? 'required' : '',
            'state_id' => $state ? 'required' : '',
        ];

        $messages = [
            'm_language_id.required' => 'The language field is required.',
            'country_id.required' => 'The country field is required.',
            'state_id.required' => 'The state field is required.',
            'name.required' => 'The name field is required.'
        ];

        $validator = Validator::make($request->all(), $rules, $messages);

        if ($validator->fails()) {
            return response()->json([
                'errors' => $validator->getMessageBag()
            ], 400);
        }
        if ($request->hasFile('feature_image')) {
            $featuredImgURL = $request->file('feature_image');
            $featuredImgExt = $featuredImgURL->getClientOriginalExtension();
            $featuredImgName = time() . '.' . $featuredImgExt;
            $featuredDir = public_path('assets/img/location/city/');
        
            if (!file_exists($featuredDir)) {
                @mkdir($featuredDir, 0777, true);
            }
        
            $featuredImgURL->move($featuredDir, $featuredImgName);
        } else {
            $featuredImgName = null; // or set a default image if needed
        }

        // $featuredImgURL = $request->feature_image;

        // $featuredImgExt = $featuredImgURL->getClientOriginalExtension();


        // $featuredImgName = time() . '.' . $featuredImgExt;
        // $featuredDir = public_path('assets/img/location/city/');

        // if (!file_exists($featuredDir)) {
        //     @mkdir($featuredDir, 0777, true);
        // }

        // copy($featuredImgURL, $featuredDir . $featuredImgName);

        $state = new City();

        $state->language_id = $request->m_language_id;
        $state->country_id = $request->country_id;
        $state->state_id = $request->state_id;
        $state->feature_image = $featuredImgName;
        $state->name = $request->name;
        $state->county = $request->county;

        $state->save();

        Session::flash('success', 'State stored successfully!');

        return response()->json(['status' => 'success'], 200);
    }

    public function update(Request $request)
    {
        $totalCountry = Country::Where('language_id', $request->language_id)->count();
        if ($totalCountry > 0) {
            $country = true;
        } else {
            $country = false;
        }
        $totalState = State::Where('country_id', $request->country_id)->count();
        if ($totalState > 0) {
            $state = true;
        } else {
            $state = false;
        }

        $rules = [
            'name' => 'required',
            'country_id' => $country ? 'required' : '',
            'state_id' => $state ? 'required' : '',
        ];
        if ($request->hasFile('image')) {
            $rules['image'] = [
                new ImageMimeTypeRule(),
            ];
        }

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            return Response::json([
                'errors' => $validator->getMessageBag()
            ], 400);
        }

        $city = City::find($request->id);

        $in = $request->all();

        if ($request->hasFile('image')) {
            @unlink(public_path('assets/img/location/city/') . $city->feature_image);
            $img = $request->file('image');
            $filename = uniqid() . '.jpg';
            $directory = public_path('assets/img/location/city/');
            @mkdir($directory, 0775, true);
            $img->move($directory, $filename);
            $in['feature_image'] = $filename;
        }
        $States = State::where('country_id', $request->country_id)->count();
        if ($States < 1) {
            $in['state_id'] = null;
        }

        $city->update($in);

        Session::flash('success', 'City updated successfully!');

        return Response::json(['status' => 'success'], 200);
    }

    public function getLocationData(Request $request)
    {
        $query = ListingLocation::query();
    
        if ($search = $request->input('search.value')) {
            $query->where(function($q) use ($search) {
                $q->where('country', 'like', "%{$search}%")
                  ->orWhere('state', 'like', "%{$search}%")
                  ->orWhere('city', 'like', "%{$search}%")
                  ->orWhere('county', 'like', "%{$search}%");
            });
        }
    
        $filtered = $query->count();
    
        $query->skip($request->input('start'))
              ->take($request->input('length'));
    
        $columns = ['checkbox', 'country', 'state', 'city', 'county', 'actions'];
        $orderColumn = $columns[$request->input('order.0.column')];
        $orderDir = $request->input('order.0.dir');
        if (in_array($orderColumn, ['country', 'state', 'city', 'county'])) {
            $query->orderBy($orderColumn, $orderDir);
        }
    
        $data = $query->get()->map(function ($item) {
            return [
                'checkbox' => '<input type="checkbox" />',
                'country' => $item->country,
                'state' => $item->state,
                'city' => $item->city,
                'county' => $item->county,
                'actions' => '<button>Edit</button>'
            ];
        });
    
        return response()->json([
            'draw' => intval($request->input('draw')),
            'recordsTotal' => ListingLocation::count(),
            'recordsFiltered' => $filtered,
            'data' => $data
        ]);
    }

    public function destroy($id)
    {
        $City = City::query()->find($id);

        $listing_content = ListingContent::Where('city_id', $id)->get();
        if (count($listing_content) > 0) {
            return redirect()->back()->with('warning', 'First delete all the listing of this City!');
        } else {
            $City->delete();
            return redirect()->back()->with('success', 'State deleted successfully!');
        }
        return redirect()->back()->with('success', 'State deleted successfully!');
    }

    public function bulkDestroy(Request $request)
    {
        $ids = $request['ids'];

        $errorOccurred = false;
        foreach ($ids as $id) {
            $City = City::query()->find($id);
            $listing_content = ListingContent::Where('city_id', $id)->get();

            if (count($listing_content) > 0) {
                $errorOccurred = true;
                break;
            } else {
                $City->delete();
            }
        }
        if ($errorOccurred == true) {
            Session::flash('warning', 'First delete all the listing of these City!');
        } else {
            Session::flash('success', 'Selected Informations deleted successfully!');
        }
        return Response::json(['status' => 'success'], 200);
    }
    public function getLastId(Request $request)
    {
        $lastId = City::orderByDesc('id')->value('id');
        
        return response()->json(['last_id' => $lastId]);
    }
    
    public function import(Request $request){
   

    $request->validate([
        'csv_file' => 'required|mimes:csv,txt'
    ]);

    $file = fopen($request->file('csv_file'), 'r');

    $header = fgetcsv($file);
    $header = array_map(function($h) {
        return strtolower(trim($h));
    }, $header);
    $headerMap = array_flip($header);

    while (($row = fgetcsv($file)) !== false) {
        $countryName = $headerMap['country'] ?? null ? trim($row[$headerMap['country']]) : null;
        $stateName = $headerMap['state'] ?? null ? trim($row[$headerMap['state']]) : null;
        $cityName = $headerMap['city'] ?? null ? trim($row[$headerMap['city']]) : null;
        $county = $headerMap['county'] ?? null ? trim($row[$headerMap['county']]) : null;
        $imageFilename = $headerMap['feature image'] ?? null ? trim($row[$headerMap['feature image']]) : null;
        $finalImageName = $imageFilename ? basename(parse_url($imageFilename, PHP_URL_PATH)) : null;

       

        if (!$stateName || !$cityName) continue;

        $country = Country::firstOrCreate(
            ['name' => $countryName],
            ['language_id' => 20]
        );

        $state = State::firstOrCreate(
            ['name' => $stateName],
            [
                'language_id' => 20,
                'country_id' => $country->id,
                'slug' => Str::slug($stateName),
            ]
        );

        City::updateOrCreate(
            ['name' => $cityName, 'state_id' => $state->id],
            [
                'language_id' => 20,
                'country_id' => $country->id,
                'county' => $county,
                'slug' => Str::slug($stateName . '-' . $cityName),
                'feature_image' => $finalImageName,
            ]
        );
    }

    fclose($file);

    return back()->with('success', 'CSV data imported successfully!');
}



    public function exportCsv()
    {
        $cities = City::with(['state', 'country'])->get();
    
        $csvData = [];
        $csvData[] = ['ID', 'Country','State','City','County','Slug',  ];
    
        foreach ($cities as $city) {
            $csvData[] = [
                $city->id,
                optional($city->country)->name,
                optional($city->state)->name,
                $city->name,
                $city->county,
                $city->slug,
                
            ];
        }
    
        // Convert to CSV string
        $filename = 'cities_export_' . date('Ymd_His') . '.csv';
        $handle = fopen('php://temp', 'r+');
    
        foreach ($csvData as $row) {
            fputcsv($handle, $row);
        }
    
        rewind($handle);
        $csvContents = stream_get_contents($handle);
        fclose($handle);
    
        return Response::make($csvContents, 200, [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=$filename",
        ]);
    }


}
