<?php

namespace App\Http\Controllers\Admin\Listing;

use App\Http\Controllers\Controller;
use App\Models\Language;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Validator;
use App\Models\Aminite;
use App\Models\Listing\ListingContent;
use Illuminate\Support\Facades\Session;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Log;

class AminiteController extends Controller
{
    public function index(Request $request)
    {
        $language = Language::query()->where('code', '=', $request->language)->firstOrFail();
        $information['aminites'] = $language->aminiteInfo()->orderByDesc('id')->get();
        $information['langs'] = Language::all();

        return view('admin.amenitie.index', $information);
    }

    public function store(Request $request)
    {
        $rules = [
            'language_id' => 'required',
            'icon' => 'required',
            'title' => [
                'required',
                Rule::unique('aminites')->where(function ($query) use ($request) {
                    return $query->where('language_id', $request->input('language_id'));
                }),
                'max:255',
            ],
            'catgeory' => 'requireed'
        ];

        $message = [
            'language_id.required' => 'The language field is required.',
            'category.required' => 'The category field is required.'
        ];

        $validator = Validator::make($request->all(), $rules, $message);

        if ($validator->fails()) {
            return Response::json([
                'errors' => $validator->getMessageBag()
            ], 400);
        }
        Aminite::query()->create($request->except('language'));

        Session::flash('success', 'Aminite stored successfully!');

        return Response::json(['status' => 'success'], 200);
    }

    public function update(Request $request)
    {
        $rules = [
            'title' => [
                'required',
                Rule::unique('aminites')->where(function ($query) use ($request) {
                    return $query->where('language_id', $request->input('language_id'));
                })->ignore($request->id, 'id'),
                'max:255',
            ],
            'category' => 'required|string|max:255',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            return Response::json([
                'errors' => $validator->getMessageBag()
            ], 400);
        }

        $aminiteInfo = Aminite::query()->find($request->id);

        $aminiteInfo->update($request->except('language'));

        Session::flash('success', 'Aminite updated successfully!');

        return Response::json(['status' => 'success'], 200);
    }

    public function destroy($id)
    {

        $listing = ListingContent::select('aminities')->get();
        $data = json_decode($listing, true);
        $found = false;

        foreach ($data as $item) {

            $aminities = json_decode($item['aminities']);

            if (in_array($id, $aminities)) {
                $found = true;
                break;
            }
        }
        if ($found) {
            return redirect()->back()->with('warning', 'First delete all the listing of this Amenitie!');
        } else {
            $aminiteInfo = Aminite::query()->find($id);
            $aminiteInfo->delete();
            return redirect()->back()->with('success', 'Aminite deleted successfully!');
        }
    }

    public function bulkDestroy(Request $request)
{
    $ids = $request['ids'];

    // Get all listing amenities
    $listingContents = ListingContent::select('aminities')->get();
    $usedAminityIds = [];

    // Collect all used amenity IDs
    foreach ($listingContents as $listing) {
        $aminities = json_decode($listing->aminities ?? '[]', true);
        if (is_array($aminities)) {
            $usedAminityIds = array_merge($usedAminityIds, $aminities);
        }
    }

    $usedAminityIds = array_unique($usedAminityIds);

    $notDeleted = [];

    foreach ($ids as $id) {
        if (in_array($id, $usedAminityIds)) {
            // Add to not deleted list
            $notDeleted[] = $id;
        } else {
            // Safe to delete
            $aminite = Aminite::find($id);
            if ($aminite) {
                $aminite->delete();
            }
        }
    }

    if (count($notDeleted) > 0) {
        Session::flash('warning', 'Some selected amenities could not be deleted because they are used in listings.');
    } else {
        Session::flash('success', 'Selected amenities deleted successfully!');
    }

    return Response::json(['status' => 'success'], 200);
}

    public function import(Request $request){
        $request->validate([
            'csv_file' => 'required|mimes:csv,txt'
        ]);
    
        $file = fopen($request->file('csv_file'), 'r');

        $header = fgetcsv($file);
        $header = array_map(function($h) {
            return strtolower(trim($h));
        }, $header);
        $headerMap = array_flip($header);
        
         while (($row = fgetcsv($file)) !== false) {

            $category = isset($headerMap['category']) ? ($row[$headerMap['category']] ?? null) : null;
            $amenity = isset($headerMap['amenity']) ? ($row[$headerMap['amenity']] ?? null) : null;
            $icon = isset($headerMap['icon']) ? ($row[$headerMap['icon']] ?? null) : null;
           
            
            Aminite::updateOrCreate(
                [
                    'category' => $category,
                    'title' => $amenity
                ],
                [
                    'language_id' => 20,
                    'icon' => $icon,
                    
                ]
            );
         }
         fclose($file);

    
        return back()->with('success', 'CSV data imported successfully!');
    }
    

    public function exportCsv()
    {
        $amenities = Aminite::all(); // Assuming your model is 'Aminite'
        
        $fileName = "amenities.csv";
    
        $headers = [
            "Content-type" => "text/csv",
            "Content-Disposition" => "attachment; filename=$fileName",
        ];
    
        $callback = function () use ($amenities) {
            $file = fopen('php://output', 'w');
    
            // CSV Header
            fputcsv($file, ['ID', 'Category', 'Amenity', 'Icon']);
    
            // CSV Data
            foreach ($amenities as $amenity) {
                fputcsv($file, [
                    $amenity->id,
                    $amenity->category,
                    $amenity->title,
                    $amenity->icon,
                ]);
            }
    
            fclose($file);
        };
    
        return response()->stream($callback, 200, $headers);
    }

}
