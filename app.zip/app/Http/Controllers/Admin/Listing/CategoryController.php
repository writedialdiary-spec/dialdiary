<?php

namespace App\Http\Controllers\Admin\Listing;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Language;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use App\Models\ListingCategory;
use App\Models\Listing\ListingSubCategory;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;



class CategoryController extends Controller
{
    public function index(Request $request)
    {
        
        // first, get the language info from db
    //     $language = Language::where('code', $request->language)->firstOrFail();
    //     $information['language'] = $language;


    //     // then, get the equipment categories of that language from db
    //   $categories = ListingSubCategory::with('category')
    //                     ->orderByDesc('id')
    //                     ->get();

     

    //     $information['langs'] = Language::all();

    //     // return view('admin.listing.category.index', $information);
    //     return view('admin.listing.category.index', [
    //     'language' => $language,
    //     'categories' => $categories,
    //     'langs' => Language::all()
    // ]);
    $language = Language::where('code', $request->language)->firstOrFail();
    $subcategories = ListingSubCategory::with('category')
        ->whereHas('category', function ($query) use ($language) {
            $query->where('language_id', $language->id);
        })
        ->orderByDesc('id')
        ->get();
    
    return view('admin.listing.category.index', [
        'language' => $language,
        'categories' => $subcategories, // this will now contain subcategories
        'langs' => Language::all()
    ]);

    }

    // public function store(Request $request)
    // {
    //     $rules = [
    //         'icon' => 'required',
    //         'language_id' => 'required',
    //         'name' => [
    //             'required',
    //             Rule::unique('listing_categories')->where(function ($query) use ($request) {
    //                 return $query->where('language_id', $request->input('language_id'));
    //             }),
    //             'max:255',
    //         ],
    //         'status' => 'required|numeric',
    //         // 'serial_number' => 'required|numeric',
            
    //     ];

    //     $message = [
    //         'language_id.required' => 'The language field is required.'
    //     ];

    //     $validator = Validator::make($request->all(), $rules, $message);

    //     if ($validator->fails()) {
    //         return Response::json([
    //             'errors' => $validator->getMessageBag()
    //         ], 400);
    //     }

    //     $in = $request->all();
    //     $in['slug'] = createSlug($request->name);
    //     $in['serial_number'] = ListingCategory::max('serial_number') + 1 ?? 1;

    //     if ($request->filled('parent_id')) {
    //     // Save as subcategory
    //     ListingSubCategory::create([
    //         'listing_category_id' => $request->parent_id,
    //         'name' => $request->subname
    //     ]);
    // } else {
    //     // Save as main category
    //     ListingCategory::create($in);
    // }



    //     Session::flash('success', 'New Listing category added successfully!');

    //     return Response::json(['status' => 'success'], 200);
    // }
    
    public function create()
    {
        
            $information = [];
            $language = Language::get();
            $information['languages'] = $language;
            $langs = Language::all();
            $information['langs'] = Language::all();
            
            
            $categories = ListingCategory::select('name')
                            ->whereNotNull('name')
                            ->groupBy('name')
                            ->get();
            return view('admin.listing.category.create', [
                'language' => $language,
                'langs' => $langs,
                'information' => $information,
                'categories' => $categories,]);
        
    }
    public function store(Request $request)
{
    $rules = [
        'icon' => 'required',
        'language_id' => 'required',
        'subname' => [
            'required',
            Rule::unique('listing_categories', 'name')->where(function ($query) use ($request) {
                return $query->where('language_id', $request->input('language_id'));
            }),
            'max:255',
        ],
        'status' => 'required|numeric',
    ];

    $message = [
        'language_id.required' => 'The language field is required.',
        'subname.required' => 'The category name is required.',
    ];

    $validator = Validator::make($request->all(), $rules, $message);

    if ($validator->fails()) {
        return Response::json([
            'errors' => $validator->getMessageBag()
        ], 400);
    }

    $serialNumber = ListingCategory::max('serial_number') + 1 ?? 1;

    // If parent category name is given, create/update parent and subcategory
    if ($request->filled('name')) {
        // Find or create parent category
        $category = ListingCategory::updateOrCreate(
            ['name' => $request->name],
            [
                'language_id' => $request->language_id,
                'icon' => $request->icon,
                'status' => $request->status,
                'serial_number' => $serialNumber,
                'subcategory' => $request->subname,
            ]
        );

        // Also store subcategory in `listing_sub_categories` table
        ListingSubCategory::updateOrCreate(
            [
                'listing_category_id' => $category->id,
                'name' => $request->subname,
            ],
            [
                'language_id' => $request->language_id,
                'status' => $request->status,
                'serial_number' => rand(1, 100), // optional logic
            ]
        );
    } else {
        // No parent selected, save as main category
        ListingCategory::create([
            'name' => $request->subname,
            'language_id' => $request->language_id,
            'icon' => $request->icon,
            'status' => $request->status,
            'serial_number' => $serialNumber,
            'slug' => createSlug($request->name),
        ]);
    }

    Session::flash('success', 'New Listing category added successfully!');
    return Response::json(['status' => 'success'], 200);
}

//     public function store(Request $request)
// {
    
//     $rules = [
//         'icon' => 'required',
//         'language_id' => 'required',
//         'subname' => [
//             'required',
//             Rule::unique('listing_categories', 'name')->where(function ($query) use ($request) {
//                 return $query->where('language_id', $request->input('language_id'));
//             }),
//             'max:255',
//         ],
//         'status' => 'required|numeric',
        
//     ];
    
//     $message = [
//         'language_id.required' => 'The language field is required.',
//         'subname.required' => 'The category name is required.'
//     ];

//     $validator = Validator::make($request->all(), $rules, $message);

//     if ($validator->fails()) {
//         return Response::json([
//             'errors' => $validator->getMessageBag()
//         ], 400);
//     }

//     $in = $request->all();
    
   
//     $in['serial_number'] = ListingCategory::max('serial_number') + 1 ?? 1;

//     if ($request->filled('name')) {
//         $in['subcategory'] = $request->subname;
        
//         ListingCategory::create($in);
//     } else {
//         // No parent selected, treat as main category
//         $in['name'] = $request->subname;
     
//         ListingCategory::create($in);
//     }

//     Session::flash('success', 'New Listing category added successfully!');

//     return Response::json(['status' => 'success'], 200);
// }


//   public function update(Request $request)
// {
//     try {
        
//         $rules = [
//             'icon' => 'required',
//             'name' => [
//                 'required',
//                 Rule::unique('listing_categories')->where(function ($query) use ($request) {
//                     return $query->where('language_id', $request->input('language_id'));
//                 })->ignore($request->id, 'id'),
//                 'max:255',
//             ],
//             'status' => 'required|numeric',
//             'metatitle' => 'nullable|string|max:255',
//             'metadescription' => 'nullable|string',
//             'metakeywords' => 'nullable|string',
           
//         ];

//         $validator = Validator::make($request->all(), $rules);

//         if ($validator->fails()) {
//             return Response::json([
//                 'errors' => $validator->getMessageBag()
//             ], 400);
//         }

//         // Fetch the category using the ID
//         Log::info('Request Data:', $request->all());
//         $category = ListingCategory::find($request->id);
//          Log::info('category :', $category);
       

//         if ($category) {
            
//             $category->update([
//                 'name' => $request->name,
//                 'slug' => createSlug($request->name),
//                 'icon' => $request->icon,
//                 'language_id' => $request->language_id,
//                 'status' => $request->status,
//                 'serial_number' => $request->serial_number,
//                 'subcategory' => $request->subname ?? null, 
//                 'meta_title' => $request->metatitle,
//                 'meta_description' => $request->metadescription,
//                 'meta_keywords' => $request->metakeywords
//             ]);

            
//         }

        
//         Session::flash('success', 'Listing category updated successfully!');
//         return Response::json(['status' => 'success'], 200);

//     } catch (\Exception $e) {
//         // Log the error with the message and stack trace
//         Log::error('Error updating category: ' . $e->getMessage());
//         Log::error('Stack trace: ' . $e->getTraceAsString());
//         return Response::json(['status' => 'error', 'message' => 'There was an error updating the category.'], 500);
//     }
// }

// public function update(Request $request)
// {
//     try {
//         Log::info('Inside try block');
//         $rules = [
//             'id' => 'required|exists:listing_categories,id',
//             'icon' => 'required', // or 'nullable' if icon can be empty on update
//             'name' => 'required|max:255',
//             'language_id' => 'required|numeric',
//             'status' => 'required|numeric',
            
//         ];

//         $validator = Validator::make($request->all(), $rules);

//         if ($validator->fails()) {
//             Log::info('Validation failed', $validator->errors()->toArray());
//             return Response::json([
//                 'errors' => $validator->getMessageBag()
//             ], 400);
//         }
        
//         $category = ListingCategory::find($request->id);

//         if (!$category) {
//             return Response::json(['status' => 'error', 'message' => 'Category not found.'], 404);
//         }

//         $category->update([
//             'name' => $request->name,
//             'icon' => $request->icon,
//             'language_id' => $request->language_id,
//             'status' => $request->status,
//             'subcategory' => $request->subname ?? null,
            
//         ]);

//         Session::flash('success', 'Listing category updated successfully!');
//         return Response::json(['status' => 'success'], 200);

//     } catch (\Exception $e) {
//         Log::error('Error updating category: ' . $e->getMessage());
//         Log::error('Stack trace: ' . $e->getTraceAsString());
//         return Response::json(['status' => 'error', 'message' => 'There was an error updating the category.'], 500);
//     }
// }
// public function update(Request $request)
// {
//     try {
//         $rules = [
//             'id' => 'required|exists:listing_sub_categories,id',
//             'name' => 'required|max:255',
//             'icon' => 'required',
//             'language_id' => 'required|numeric',
//             'status' => 'required|numeric',
//         ];

//         $validator = Validator::make($request->all(), $rules);

//         if ($validator->fails()) {
//             Log::info('Validation failed', $validator->errors()->toArray());
//             return Response::json([
//                 'errors' => $validator->getMessageBag()
//             ], 400);
//         }

//         $subcategory = ListingSubCategory::find($request->id);

//         if (!$subcategory) {
//             return Response::json(['status' => 'error', 'message' => 'Subcategory not found.'], 404);
//         }

//         $subcategory->update([
//             'name' => $request->name,
//             'icon' => $request->icon,
//             'language_id' => $request->language_id,
//             'status' => $request->status,
//             'serial_number' => $request->serial_number ?? 0,
//         ]);

//         Session::flash('success', 'Listing subcategory updated successfully!');
//         return Response::json(['status' => 'success'], 200);

//     } catch (\Exception $e) {
//         Log::error('Subcategory Update Error: ' . $e->getMessage());
//         return Response::json([
//             'status' => 'error',
//             'message' => 'There was an error updating the subcategory.'
//         ], 500);
//     }
// }
public function update(Request $request)
{
    
    $isSub = $request->input('is_subcategory');


    if ($isSub) {
        // Update subcategory
        $subcategory = ListingSubCategory::findOrFail($request->id);
        $subcategory->update([
            'name' => $request->name,
            'icon' => $request->icon,
            'language_id' => $request->language_id,
            'status' => $request->status,
            'serial_number' => $request->serial_number ?? 0,
        ]);
         Session::flash('success', 'Listing subcategory updated successfully!');
         return Response::json(['status' => 'success'], 200);
    } else {
        // Update parent category
        $category = ListingCategory::findOrFail($request->cat_id);
        $category->name = $request->name;
        $category->icon = $request->icon;
        $category->status = $request->status;
        $category->serial_number = $request->serial_number ?? 0;
        $category->language_id = $request->language_id;
        $category->save();
         Session::flash('success', 'Listing category updated successfully!');
         return Response::json(['status' => 'success'], 200);
    }

    return response()->json(['success' => true, 'message' => 'Category updated successfully.']);
}

// public function update(Request $request)
// {
//     try {
        
//         $rules = [
//             'id' => 'required|exists:listing_categories,id',
//             'icon' => 'required',
//             'name' => 'required|max:255',
//             'language_id' => 'required|numeric',
//             'status' => 'required|numeric',
//         ];

//         $validator = Validator::make($request->all(), $rules);

//         if ($validator->fails()) {
//             Log::info('Validation failed', $validator->errors()->toArray());
//             return Response::json([
//                 'errors' => $validator->getMessageBag()
//             ], 400);
//         }

//         $category = ListingCategory::find($request->id);

//         if (!$category) {
//             return Response::json(['status' => 'error', 'message' => 'Category not found.'], 404);
//         }

//         // Update main category
//         $category->update([
//             'name' => $request->name,
//             'icon' => $request->icon,
//             'language_id' => $request->language_id,
//             'status' => $request->status,
//             'subcategory' => $request->subname ?? null,
//         ]);

//         // If subname is present, update or insert into subcategory table
//         if ($request->filled('subname')) {
//             ListingSubCategory::updateOrCreate(
//                 [
//                     'listing_category_id' => $category->id,
//                     'name' => $request->subname,
//                 ],
//                 [
//                     'language_id' => $request->language_id,
//                     'status' => $request->status,
//                     'serial_number' => rand(1, 100), // Or use the same serial from category or a different logic
//                 ]
//             );
//         }

//         Session::flash('success', 'Listing category updated successfully!');
//         return Response::json(['status' => 'success'], 200);

//     } catch (\Exception $e) {
        
//         return Response::json(['status' => 'error', 'message' => 'There was an error updating the category.'], 500);
//     }
// }

    // public function destroy($id)
    // {
    //     Log::info('destroy ID:', ['id' => $id]);
    //     $category = ListingSubCategory::find($id)->listing_category_id;
        
    //     $listingContents = $category->listing_contents()->get();

    //     if (count($listingContents) > 0) {
    //         return redirect()->back()->with('warning', 'First delete all the listing of this category!');
    //     } else {
    //         $category->delete();
    //         ListingSubCategory::where('listing_category_id', $id)->delete();
    //         return redirect()->back()->with('success', 'Category deleted successfully!');
    //     }
    // }
public function destroy($id)
{
 

    $subCategory = ListingSubCategory::find($id);

    if (!$subCategory) {
        return redirect()->back()->with('error', 'Subcategory not found.');
    }

    $category = ListingCategory::find($subCategory->listing_category_id);

    if (!$category) {
        return redirect()->back()->with('error', 'Parent category not found.');
    }

    // Check if listings exist for this subcategory (optional, depends on your logic)
    $listingContents = $subCategory->listing_contents()->get(); // assuming subcategory has this relation

    if ($listingContents->count() > 0) {
        return redirect()->back()->with('warning', 'First delete all the listings of this subcategory!');
    }

    // Delete the subcategory only
    $subCategory->delete();

    return redirect()->back()->with('success', 'Subcategory deleted successfully!');
}

    // public function bulkDestroy(Request $request)
    // {

    //     $ids = $request->ids;

    //     $errorOccurred = false;

    //     foreach ($ids as $id) {
    //         $category = ListingCategory::find($id);
    //         $listingContents = $category->listing_contents()->get();

    //         if (count($listingContents) > 0) {
    //             $errorOccurred = true;
    //             break;
    //         } else {
    //             $category->delete();
    //         }
    //     }

    //     if ($errorOccurred == true) {
    //         Session::flash('warning', 'First delete all the listing of these categories!');
    //     } else {
    //         Session::flash('success', 'Listing categories deleted successfully!');
    //     }

    //     return Response::json(['status' => 'success'], 200);
    // }
   public function bulkDestroy(Request $request)
{
    $ids = $request->ids;

    $notDeleted = [];

    foreach ($ids as $id) {
        $subCategory = ListingSubCategory::find($id);

        if (!$subCategory) {
            continue; // Skip if subcategory not found
        }

        $category = ListingCategory::find($subCategory->listing_category_id);

        // Check if category has listings
        if ($category && $category->listing_contents()->count() > 0) {
            $notDeleted[] = $subCategory->name; // Add to not deleted list
            continue; // Skip deleting this subcategory
        }

        // Safe to delete
        $subCategory->delete();
    }

    if (count($notDeleted) > 0) {
        Session::flash('warning', 'Some subcategories could not be deleted because their parent categories have listings.');
    } else {
        Session::flash('success', 'Selected subcategories deleted successfully!');
    }

    return Response::json(['status' => 'success'], 200);
}


    public function getSubcategories($categoryId)
    {
        $subcategories = \App\Models\Listing\ListingSubCategory::where('listing_category_id', $categoryId)->get();

        return response()->json($subcategories);
    }


    // public function import(Request $request)
    // {
    //     $request->validate([
    //         'csv_file' => 'required|mimes:csv,txt'
    //     ]);
    
    //     $file = fopen($request->file('csv_file'), 'r');

    //     $header = fgetcsv($file);
    //     $header = array_map(function($h) {
    //         return strtolower(trim($h));
    //     }, $header);
    //     $headerMap = array_flip($header);
        
    //     while (($row = fgetcsv($file)) !== false) {

    //         $category = isset($headerMap['category']) ? ($row[$headerMap['category']] ?? null) : null;
    //         $subcategory = isset($headerMap['subcategory']) ? ($row[$headerMap['subcategory']] ?? null) : null;
    //         $icon = isset($headerMap['icon']) ? ($row[$headerMap['icon']] ?? null) : null;
    //         $meta_keywords = isset($headerMap['meta keywords']) ? ($row[$headerMap['meta keywords']] ?? null) : null;
    //         $meta_title = isset($headerMap['meta title']) ? ($row[$headerMap['meta title']] ?? null) : null;
    //         $meta_description = isset($headerMap['meta description']) ? ($row[$headerMap['meta description']] ?? null) : null;
    //         Log::info("icon", ['icon' => $icon]);

    //         $slug = Str::slug($category) . '/' . Str::slug($subcategory);
    //         $attributes = [
    //                 'name' => $category,
    //                 'subcategory' => $subcategory,
    //             ];
                
    //             $values = [
    //                 'language_id' => 20,
    //                 'meta_keywords' => $meta_keywords,
    //                 'meta_title' => $meta_title,
    //                 'meta_description' => $meta_description,
    //                 'icon' => $icon,
    //                 'slug' => $slug,
    //                 'status' => 1,
    //                 'serial_number' => rand(1, 1000),
    //             ];
                
                
                
    //             ListingCategory::updateOrCreate($attributes, $values);
                
               
    

    //     }

        
    //     fclose($file);

    
    //     return back()->with('success', 'CSV data imported successfully!');
    // }
// public function import(Request $request)
// {
//     $request->validate([
//         'csv_file' => 'required|mimes:csv,txt'
//     ]);

//     $file = fopen($request->file('csv_file'), 'r');

//     $header = fgetcsv($file);
//     $header = array_map(function ($h) {
//         return strtolower(trim($h));
//     }, $header);
//     $headerMap = array_flip($header);

//     while (($row = fgetcsv($file)) !== false) {

//         $categoryName = $headerMap['category'] ?? null ? ($row[$headerMap['category']] ?? null) : null;
//         $subcategoryName = $headerMap['subcategory'] ?? null ? ($row[$headerMap['subcategory']] ?? null) : null;
//         $icon = $headerMap['icon'] ?? null ? ($row[$headerMap['icon']] ?? null) : null;
        

//         $slug = Str::slug($categoryName) . '/' . Str::slug($subcategoryName);

//         // Step 1: Create or update parent category
//         $category = ListingCategory::updateOrCreate(
//             ['name' => $categoryName],
//             [
//                 'language_id' => 20,
//                 'icon' => $icon,
//                 'slug' => $slug,
//                 'status' => 1,
//                 'serial_number' => rand(1, 1000),
//             ]
//         );

//         // Step 2: Create subcategory linked to parent category
//         if ($category && $subcategoryName) {
//             ListingSubCategory::updateOrCreate(
//                 ['name' => $subcategoryName, 'listing_category_id' => $category->id],
//                 [
//                     'language_id' => 20,
//                     'slug' => Str::slug($subcategoryName),
//                     'status' => 1,
//                     'serial_number' => rand(1, 100),
//                 ]
//             );
//         }
//     }

//     fclose($file);

//     return back()->with('success', 'CSV data imported successfully!');
// }
public function import(Request $request)
{
    $request->validate([
        'csv_file' => 'required|mimes:csv,txt'
    ]);

    $file = fopen($request->file('csv_file'), 'r');

    $header = fgetcsv($file);
    $header = array_map(function ($h) {
        return strtolower(trim($h));
    }, $header);
    $headerMap = array_flip($header);

    while (($row = fgetcsv($file)) !== false) {
        if (empty(array_filter($row, fn($value) => trim($value) !== ''))) {
            continue;
        }

        $categoryName = $headerMap['category'] ?? null ? ($row[$headerMap['category']] ?? null) : null;
        $subcategoryName = $headerMap['subcategory'] ?? null ? ($row[$headerMap['subcategory']] ?? null) : null;
        $icon = $headerMap['icon'] ?? null ? ($row[$headerMap['icon']] ?? null) : null;
        $subicon = $headerMap['subicon'] ?? null ? ($row[$headerMap['subicon']] ?? null) : null;
        $slug = Str::slug($categoryName);
        
        if (!$categoryName) {
            continue;
        }


        $category = ListingCategory::updateOrCreate(
            ['name' => $categoryName],
            [
                'subcategory'=> $subcategoryName,
                'language_id' => 20,
                'icon' => $icon,
                'slug' => $slug,
                'status' => 1,
                'serial_number' => rand(1, 1000),
            ]
        );

        if ($category && $subcategoryName) {
            ListingSubCategory::updateOrCreate(
                ['name' => $subcategoryName, 'listing_category_id' => $category->id],
                [
                    'language_id' => 20,
                    'icon' => $subicon,
                    'status' => 1,
                    'serial_number' => rand(1, 1000),
                ]
            );
        }
    }

    fclose($file);

    return back()->with('success', 'CSV data imported successfully!');
}


    // public function exportCsv(){
            
    //     $categories = ListingCategory::all();
    
    //     $filename = "listing_categories.csv";
    //     $headers = [
    //         "Content-Type" => "text/csv",
    //         "Content-Disposition" => "attachment; filename=$filename",
    //     ];
    
    //     $callback = function () use ($categories) {
    //         $file = fopen('php://output', 'w');
    
            
    //         fputcsv($file, [
    //             'ID', 'Language ID', 'category', 'subcategory', 'Icon', 'Status'
    //         ]);
    
           
    //         foreach ($categories as $category) {
    //             fputcsv($file, [
    //                 $category->id,
    //                 $category->language_id,
    //                 $category->name,
    //                 $category->subcategory,
    //                 $category->icon,
    //                 $category->status,
                   
    //             ]);
    //         }
    
    //         fclose($file);
    //     };
    
    //     return Response::stream($callback, 200, $headers);
    // }

public function exportCsv()
{
    $categories = ListingCategory::with('subcategories')->get(); // Eager load

    $filename = "listing_categories.csv";
    $headers = [
        "Content-Type" => "text/csv",
        "Content-Disposition" => "attachment; filename=$filename",
    ];

    $callback = function () use ($categories) {
        $file = fopen('php://output', 'w');

        // Header
        fputcsv($file, ['ID', 'Language ID', 'Category', 'Icon', 'Subcategory', 'Subicon' , 'Status']);

        foreach ($categories as $category) {
            if ($category->subcategories->isEmpty()) {
                fputcsv($file, [
                    $category->id,
                    $category->language_id,
                    $category->name,
                    $category->icon,
                    '', // Subcategory
                    '', // Subicon
                    $category->status,
                ]);
            } else {
                foreach ($category->subcategories as $sub) {
                    fputcsv($file, [
                        $category->id,
                        $category->language_id,
                        $category->name,
                        $sub->name,
                        $category->icon,
                        $category->status,
                    ]);
                }
            }
        }

        fclose($file);
    };

    return Response::stream($callback, 200, $headers);
}


}
