<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\SitemapRequest;
use App\Models\Sitemap;
use Datatables;
use Illuminate\Http\Request;
use Validator;
use Spatie\Sitemap\SitemapGenerator;
use Illuminate\Support\Facades\Artisan;


class SitemapController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    public function datatables()
    {
         $datas = Sitemap::orderBy('id','desc');
         return Datatables::of($datas)
                            ->addColumn('action', function(Sitemap $data) {
                                $delete = '<a href="javascript:;" data-href="' . route('admin.sitemap.delete',$data->id) . '" data-toggle="modal" data-target="#deleteModal" class="btn btn-danger btn-sm btn-rounded"><i class="fas fa-trash-alt"></i></a>';
                                $download = '<a href="'.asset('assets/sitemaps/'.$data->filename).'" class="btn btn-dark btn-sm btn-rounded" download><i class="fa fa-download"></i> Download</a>';
                                return '<div class="actions-btn">'.$delete.$download.'</div>';
                            })
                            ->rawColumns(['action'])
                            ->toJson();
    }

    public function index()
    {
        $sitemaps = Sitemap::orderBy('id', 'desc')->get();
    return view('admin.sitemap.index', compact('sitemaps'));
    }

    public function create()
    {
        return view('admin.sitemap.create');
    }

    public function store(SitemapRequest $request)
    {
        $data = new Sitemap();
        $input = $request->all();

        if(!file_exists('public/assets/sitemaps')){
            mkdir('public/assets/sitemaps');
        }
        $filename = 'sitemap'.uniqid().'.xml';
        SitemapGenerator::create($request->sitemap_url)->writeToFile('public/assets/sitemaps/'.$filename);
        \DB::reconnect();
        $input['filename']    = $filename;
        $input['sitemap_url'] = $request->sitemap_url;
        $data->fill($input)->save();

        return redirect()->route('admin.sitemap.index')->with('success', 'Data Added Successfully.');
    }

    public function delete($id){
        $data = Sitemap::find($id);
        @unlink('public/assets/sitemaps/'.$data->filename);
        $data->delete();
        return redirect()->route('admin.sitemap.index')->with('success', 'Data Deleted Successfully.');
    }
    public function generate(Request $request)
    {
        try {
            Artisan::call('sitemap:generate');
            return back()->with('success', 'Sitemap generated successfully!');
        } catch (\Exception $e) {
            return back()->with('error', 'Failed to generate sitemap: ' . $e->getMessage());
        }
    }

}