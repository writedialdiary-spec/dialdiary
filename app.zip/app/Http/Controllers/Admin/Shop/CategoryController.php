<?php

namespace App\Http\Controllers\Admin\Shop;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Language;
use App\Models\Shop\ProductCategory;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;


class CategoryController extends Controller
{
    public function index(Request $request)
    {
        // first, get the language info from db
        $language = Language::where('code', $request->language)->firstOrFail();
        $information['language'] = $language;

        // then, get the product categories of that language from db
        
        $information['categories'] = ProductCategory::where('language_id', 20)
        ->with('parent') 
        ->orderBy('serial_number')
        ->get();

       $information['parentcategories'] = ProductCategory::where('language_id', $language->id)
                                            ->whereNull('parent_id')
                                            ->orderBy('serial_number')
                                            ->get();
        //column wise categories                                 
        $cat = ProductCategory::where('language_id', $language->id)->get();
        $categoryMap = $cat->groupBy('parent_id');
        $rows = [];

    $buildPaths = function ($parentId = null, $path = []) use (&$buildPaths, $categoryMap, &$rows) {
        if (!isset($categoryMap[$parentId])) {
            $rows[] = $path;
            return;
        }

        foreach ($categoryMap[$parentId] as $category) {
            $buildPaths($category->id, [...$path, $category]);
        }
    };

    $buildPaths();

    // Find max depth
    $maxLevel = collect($rows)->map(fn($row) => count($row))->max();

    $information['categoryPaths'] = $rows;
    $information['maxLevel'] = $maxLevel;
    

        $information['langs'] = Language::all();

        return view('admin.shop.category.index', $information);
    }
    public function getSubcategories($parentId)
    {
        $subcategories = ProductCategory::where('parent_id', $parentId)
            ->orderBy('serial_number')
            ->get();
    
        if ($subcategories->isEmpty()) {
            return response()->noContent(); 
        }
    
        $level = request()->input('level', 1) + 1;
    
        return view('admin.shop.category.category-options', compact('subcategories', 'level'));
    }



    // public function store(Request $request)
    // {
    //     $rules = [
    //         'language_id' => 'required',
    //         'name' => 'required|unique:product_categories|max:255',
    //         'status' => 'required|numeric',
    //         'serial_number' => 'required|numeric'
    //     ];

    //     $message = [
    //         'language_id.required' => 'The language field is required.'
    //     ];

    //     $validator = Validator::make($request->all(), $rules, $message);

    //     if ($validator->fails()) {
    //         return Response::json([
    //             'errors' => $validator->getMessageBag()
    //         ], 400);
    //     }

    //     ProductCategory::create($request->except('slug') + [
    //         'slug' => createSlug($request->name)
    //     ]);

    //     Session::flash('success', 'New product category added successfully!');

    //     return Response::json(['status' => 'success'], 200);
    // }
    public function store(Request $request)
    {
        $rules = [
            'language_id' => 'required',
            'name' => 'required|unique:product_categories|max:255',
            'status' => 'required|numeric',
            'serial_number' => 'required|numeric',
            'parent_id' => 'nullable|exists:product_categories,id'
        ];
    
        $message = [
            'language_id.required' => 'The language field is required.',
        ];
    
        $validator = Validator::make($request->all(), $rules, $message);
    
        if ($validator->fails()) {
            return Response::json([
                'errors' => $validator->getMessageBag()
            ], 400);
        }
    
        ProductCategory::create([
            'language_id'   => $request->language_id,
            'name'          => $request->name,
            'slug'          => createSlug($request->name),
            'status'        => $request->status,
            'serial_number' => $request->serial_number,
            'parent_id'     => $request->parent_id ?? null
        ]);
    
        Session::flash('success', 'New product category added successfully!');
    
        return Response::json(['status' => 'success'], 200);
    }


    public function update(Request $request)
    {
       
        $rules = [
            'name' => [
                'required',
                'max:255',
                Rule::unique('product_categories', 'name')->ignore($request->id, 'id')
            ],
            'status' => 'required|numeric',
            'serial_number' => 'required|numeric'
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            return Response::json([
                'errors' => $validator->getMessageBag()
            ], 400);
        }

        $category = ProductCategory::find($request->id);

        $category->update($request->except('slug') + [
            'slug' => createSlug($request->name)
        ]);

        Session::flash('success', 'Product category updated successfully!');

        return Response::json(['status' => 'success'], 200);
    }

    public function destroy($id)
    {
        $category = ProductCategory::find($id);
        $productContents = $category->productContent()->get();

        if (count($productContents) > 0) {
            return redirect()->back()->with('warning', 'First delete all the products of this category!');
        } else {
            $category->delete();

            return redirect()->back()->with('success', 'Category deleted successfully!');
        }
    }

    public function bulkDestroy(Request $request)
    {
        $ids = $request->ids;

        $errorOccurred = false;

        foreach ($ids as $id) {
            $category = ProductCategory::find($id);
            $productContents = $category->productContent()->get();

            if (count($productContents) > 0) {
                $errorOccurred = true;
                break;
            } else {
                $category->delete();
            }
        }

        if ($errorOccurred == true) {
            Session::flash('warning', 'First delete all the product of these categories!');
        } else {
            Session::flash('success', 'Product categories deleted successfully!');
        }

        return Response::json(['status' => 'success'], 200);
    }

// public function import(Request $request)
// {
//     $request->validate([
//         'csv_file' => 'required|mimes:csv,txt',
//     ]);

//     $file = fopen($request->file('csv_file'), 'r');
//     $header = fgetcsv($file);
//     $header = array_map(fn($h) => strtolower(trim($h)), $header);
//     $headerMap = array_flip($header);

//     while (($row = fgetcsv($file)) !== false) {
//         $name = trim($row[$headerMap['name']]);
//         $slug = trim($row[$headerMap['slug']]);
//         $status = $row[$headerMap['status']] ?? 1;
//         $serial = $row[$headerMap['serial_number']] ?? null;
//         $parentName = $row[$headerMap['parent_category']] ?? null;

//         $parentId = null;
//         if ($parentName) {
//             $parentCategory = ProductCategory::firstOrCreate(
//                 ['name' => $parentName],
//                 ['slug' => Str::slug($parentName), 'status' => 1, 'language_id' => 20]
//             );
//             $parentId = $parentCategory->id;
//         }

//         ProductCategory::updateOrCreate(
//             ['name' => $name],
//             [
//                 'slug' => $slug ?: Str::slug($name),
//                 'status' => $status,
//                 'serial_number' => $serial,
//                 'parent_id' => $parentId,
//                 'language_id' => 20,
//             ]
//         );
//     }

//     fclose($file);

//     return back()->with('success', 'Product categories imported successfully.');
// }
public function import(Request $request)
{
    $request->validate([
        'csv_file' => 'required|mimes:csv,txt'
    ]);

    $file = fopen($request->file('csv_file'), 'r');
    $header = fgetcsv($file); // skip the first row

    while (($row = fgetcsv($file)) !== false) {
        $parentId = null;

        foreach ($row as $name) {
            $name = trim($name);
            if (!$name) continue;

            $category = ProductCategory::firstOrCreate(
                ['name' => $name, 'parent_id' => $parentId],
                [
                    'language_id' => 20,
                    'slug' => Str::slug($name),
                    'status' => 1,
                    'serial_number' => 0,
                ]
            );

            $parentId = $category->id;
        }
    }

    fclose($file);

    return back()->with('success', 'Categories imported successfully!');
}

// public function exportCsv()
// {
//     $categories = ProductCategory::with('parent')->get();

//     $csvData = [];
//     $csvData[] = ['ID', 'Name', 'Slug', 'Status', 'Serial Number', 'Parent Category'];

//     foreach ($categories as $cat) {
//         $csvData[] = [
//             $cat->id,
//             $cat->name,
//             $cat->slug,
//             $cat->status,
//             $cat->serial_number,
//             optional($cat->parent)->name,
//         ];
//     }

//     $filename = 'product_categories_' . date('Ymd_His') . '.csv';
//     $handle = fopen('php://temp', 'r+');

//     foreach ($csvData as $row) {
//         fputcsv($handle, $row);
//     }

//     rewind($handle);
//     $csvContent = stream_get_contents($handle);
//     fclose($handle);

//     return response($csvContent, 200, [
//         'Content-Type' => 'text/csv',
//         'Content-Disposition' => "attachment; filename=$filename",
//     ]);
// }
public function exportCsv()
{
    $categories = ProductCategory::all();
    $categoryMap = $categories->groupBy('parent_id');

    $rows = [];

    // Recursive function to build full paths
    $buildPaths = function ($parentId = null, $path = []) use (&$buildPaths, $categoryMap, &$rows) {
        if (!isset($categoryMap[$parentId])) {
            $rows[] = $path;
            return;
        }

        foreach ($categoryMap[$parentId] as $category) {
            $buildPaths($category->id, [...$path, $category->name]);
        }
    };

    $buildPaths();

    // Determine the deepest level
    $maxLevel = collect($rows)->map(fn($row) => count($row))->max();
    $headers = collect(range(1, $maxLevel))->map(fn($i) => "Level $i")->toArray();
    $filename = 'categories_export.csv';

    // CSV stream response
    $callback = function () use ($rows, $headers, $maxLevel) {
        $file = fopen('php://output', 'w');
        fputcsv($file, $headers);

        foreach ($rows as $row) {
            fputcsv($file, array_pad($row, $maxLevel, ''));
        }

        fclose($file);
    };

    return response()->stream($callback, 200, [
        "Content-Type" => "text/csv",
        "Content-Disposition" => "attachment; filename={$filename}"
    ]);
}


}
