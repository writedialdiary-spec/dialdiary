<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Shop\Product;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;


class ProductFeedController extends Controller
{
    

public function generate()
{
    $xml = Cache::remember('product_feed_xml', now()->addHours(6), function () {
        $products = DB::table('products')
            ->join('product_contents', 'products.id', '=', 'product_contents.product_id')
            ->where('products.status', 'show')
            ->where('product_contents.language_id', 20)
            ->select(
                'products.id',
                'products.status',
                'products.gtin',
                'products.sku',
                'products.brand',
                'products.featured_image',
                'products.current_price',
                'product_contents.title',
                'product_contents.slug',
                'product_contents.product_category_id'
            )->get();

        $xml = new \SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><rss version="2.0" xmlns:g="http://base.google.com/ns/1.0"></rss>');
        $channel = $xml->addChild('channel');
        $channel->addChild('title', 'Dial Diary Product Feed');
        $channel->addChild('link', url('/'));
        $channel->addChild('description', 'Product feed for Google Merchant Center');

        foreach ($products as $product) {
            $item = $channel->addChild('item');
            $item->addChild('g:id', $product->id, 'g');
            $item->addChild('g:title', htmlspecialchars($product->title), 'g');
            $item->addChild('g:link', url('/products/' . $product->slug), 'g');
            $item->addChild('g:image_link', asset($product->featured_image), 'g');
            $item->addChild('g:availability', 'in stock', 'g');
            $item->addChild('g:price', number_format($product->current_price, 2) . ' INR', 'g');
            $item->addChild('g:brand', $product->brand ?? 'Generic', 'g');

            // Category path
            $categoryPath = $this->getCategoryPath($product->product_category_id);
            $item->addChild('g:google_product_category', htmlspecialchars($categoryPath), 'g');

            if ($product->gtin) {
                $item->addChild('g:gtin', $product->gtin, 'g');
            }
            if ($product->sku) {
                $item->addChild('g:mpn', $product->sku, 'g');
            }
        }

        return $xml->asXML();
    });

    return response($xml, 200)->header('Content-Type', 'application/xml');
}

private function getCategoryPath($categoryId)
{
    $categories = DB::table('product_categories')->select('id', 'name', 'parent_id')->get()->keyBy('id');

    $path = [];
    while (isset($categories[$categoryId])) {
        $category = $categories[$categoryId];
        array_unshift($path, $category->name); // prepend category name
        $categoryId = $category->parent_id;
    }

    return implode(' > ', $path);
}


}
