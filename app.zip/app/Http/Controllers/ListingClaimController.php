<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ListingClaim;
use App\Mail\ClaimSubmittedMail;
use Illuminate\Support\Facades\Mail;
use App\Models\UnclaimedListing;
use Illuminate\Support\Facades\Log;



class ListingClaimController extends Controller
{
     public function store(Request $request)
    {
        
        $vendor = auth('vendor')->user();
        
        if (!$vendor) {
            Log::error('No authenticated vendor found.');
            return back()->with('error', 'You must be logged in to submit a claim.');
        }
    
        Log::info('Vendor authenticated.', ['vendor_id' => $vendor->id]);
        
        $request->validate([
            'listing_id' => 'required|exists:unclaimed_listings,id',
            'message' => 'nullable|string',
        ]);
    
        Log::info('Checking for existing claim', [
    'listing_id' => $request->listing_id,
    'vendor_id' => $vendor->id,
]);

$claimExists = ListingClaim::where('listing_id', $request->listing_id)
    ->where('vendor_id', $vendor->id)
    ->exists();

Log::info('Claim exists result', ['exists' => $claimExists]);

    if ($claimExists) {
        Log::warning('Duplicate claim attempt.', [
            'listing_id' => $request->listing_id,
            'vendor_id' => $vendor->id
        ]);
        return back()->with('error', 'You have already submitted a claim for this listing.');
    }

    try {
        Log::info('Before claim create', ['listing_id' => $request->listing_id]);

        $claim = ListingClaim::create([
            'listing_id' => $request->listing_id,
            'vendor_id' => $vendor->id,
            'message' => $request->message,
            'status' => 'pending',
        ]);
        
        Log::info('After claim create', ['claim_id' => $claim->id ?? null]);

        Log::info('Claim created successfully.', [
            'claim_id' => $claim->id,
            'listing_id' => $claim->listing_id,
            'vendor_id' => $claim->vendor_id
        ]);

        

        Mail::to($vendor->email)->queue(new ClaimSubmittedMail($claim));
    
        return back()->with('success', 'Claim submitted successfully. Our team will review it soon.');
    } catch (\Exception $e) {
        Log::error('Error while creating claim.', [
            'error' => $e->getMessage(),
            'listing_id' => $request->listing_id,
            'vendor_id' => $vendor->id
        ]);
        return back()->with('error', 'Something went wrong while submitting your claim.');
    }
    }

   public function show($slug)
    {
        $unclaimed = UnclaimedListing::where('slug', $slug)->where('is_claimed', 0)->first();
        
        if (!$unclaimed) {
       
        abort(404, 'Listing not found or already claimed.');
        }
    
        return view('frontend.listing.unclaimed', compact('unclaimed'));
    }
    public function search(Request $request)
    {
        $request->validate([
            'business_name' => 'required|string|min:2',
        ]);
    
        $keyword = $request->business_name;
    
        $listings = UnclaimedListing::where('title', 'LIKE', '%' . $keyword . '%')
            ->where('is_claimed', 0) 
            ->orderBy('title', 'asc')
            ->get();
    
        return view('frontend.listing.unclaimed-listing', compact('listings', 'keyword'));
    }
    public function autocomplete(Request $request)
    {
        $keyword = $request->keyword;
    
        return UnclaimedListing::where('title', 'LIKE', "%{$keyword}%")
            ->limit(8)
            ->get([
                'title',
                'city_id as city',
                'state_id as state',
                'country_id as country'
            ]);
    }
    public function unclaimedListings()
    {
        $listings = UnclaimedListing::where('is_claimed', 0)
            ->orderBy('title', 'asc')
            ->paginate(12); 
    
        return view('frontend.listing.unclaimed-listing-grid', compact('listings'));
    }
}
