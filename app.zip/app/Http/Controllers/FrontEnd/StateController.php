<?php

namespace App\Http\Controllers\FrontEnd;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Location\City;
use App\Models\Location\State;

class StateController extends Controller
{
    public function show($stateSlug)
    {
        $state = State::where('name', $stateSlug)->firstOrFail();
        $cities = City::where('state_id', $state->id)->get();

        return view('frontend.state-page', compact('state', 'cities'));
    }
}

