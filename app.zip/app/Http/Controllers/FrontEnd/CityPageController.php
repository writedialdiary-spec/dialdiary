<?php

namespace App\Http\Controllers\FrontEnd;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CityPage; 
use App\Models\ListingCategory;
use App\Models\Listing\ListingReview;
use App\Models\Listing\ListingContent;
use App\Models\Location\City;
use App\Models\Location\State;
use Illuminate\Support\Facades\Log;
use App\Models\Listing\ListingFaq;

class CityPageController extends Controller
{
    public function show($stateSlug, $citySlug)
    {
        $slug = $stateSlug .'/'. $citySlug;
        $cityPage = CityPage::where('slug', $slug)->firstOrFail();
        $city = City::where('name', $cityPage->city)->first();
        $state = State::where('name', $cityPage->state)->first();
        
        $businessIds = ListingContent::where('city_id', $cityPage->city)->pluck('listing_id');
        $businessCount = $businessIds->count();
        
        $featuredBusinesses = ListingContent::with('listing')
                                ->where('city_id', $cityPage->city)
                                ->whereIn('listing_id', function($query) {
                                    $query->select('listing_id')
                                          ->from('feature_orders');
                                })
                                ->get();
        
        
        $categories = ListingCategory::all();
        $reviewCount = ListingReview::whereIn('listing_id', $businessIds)->count();
        
        $reviews = ListingReview::whereIn('listing_id', $businessIds)->latest()->limit(4)->get();
        
        $radius = 100; // radius in km
$nearbyCities = collect();

if ($city && $state) {
    $lat = $city->latitude;
    $lng = $city->longitude;

    $nearbyCities = City::select('*')
        ->selectRaw("(
            6371 * acos(
                cos(radians(?)) * cos(radians(latitude)) * 
                cos(radians(longitude) - radians(?)) + 
                sin(radians(?)) * sin(radians(latitude))
            )
        ) AS distance", [$lat, $lng, $lat])
        ->where('state_id', $state->id)
        ->where('id', '!=', $city->id)
        ->having('distance', '<=', $radius)
        ->orderBy('distance', 'asc')
        ->limit(5)
        ->get();
}

        $faqs = ListingFaq::whereIn('listing_id', $businessIds)->get();
        return view('frontend.city-page', compact('cityPage', 'state', 'categories', 'reviewCount', 'businessCount','featuredBusinesses','reviews','nearbyCities','faqs'));
    }
    // public function show($stateSlug, $citySlug)
    // {
        
    //     $cityPage = CityPage::where('slug', $citySlug)
    //         ->where('state', $stateSlug) 
    //         ->firstOrFail();
    
        
    //     $city = City::where('slug', $citySlug)->first();
    //     $state = State::where('slug', $stateSlug)->first();
    
        
    //     $businessIds = ListingContent::where('city_id',  $cityPage->city)->pluck('listing_id');
    //     $businessCount = $businessIds->count();
    
        
    //     $featuredBusinesses = ListingContent::with('listing')
    //         ->where('city_id',  $cityPage->city)
    //         ->limit(4)
    //         ->get();
    
        
    //     $categories = ListingCategory::all();
    
        
    //     $reviewCount = ListingReview::whereIn('listing_id', $businessIds)->count();
    //     $reviews = ListingReview::whereIn('listing_id', $businessIds)
    //         ->latest()
    //         ->limit(4)
    //         ->get();
    
        
    //     $nearbyCities = collect();
    //     if ($city && $state) {
    //         $nearbyCities = City::where('state_id',  $cityPage->state)
    //             ->where('id', '!=', $city->id)
    //             ->limit(5)
    //             ->get();
    //     }
    
        
    //     $faqs = ListingFaq::whereIn('listing_id', $businessIds)->get();
    
    //     return view('frontend.city-page', compact(
    //         'cityPage',
    //         'state',
    //         'categories',
    //         'reviewCount',
    //         'businessCount',
    //         'featuredBusinesses',
    //         'reviews',
    //         'nearbyCities',
    //         'faqs'
    //     ));
    // }
    
    public function state($stateSlug){
        
    }

}
