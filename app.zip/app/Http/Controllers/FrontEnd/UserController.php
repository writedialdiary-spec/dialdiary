<?php

namespace App\Http\Controllers\FrontEnd;

use App\Http\Controllers\Controller;
use App\Http\Controllers\FrontEnd\MiscellaneousController;
use App\Http\Helpers\BasicMailer;
use App\Models\BasicSettings\Basic;
use App\Models\BasicSettings\MailTemplate;
use App\Models\Car\Wishlist;
use App\Models\Shop\ProductOrder;
use App\Models\SupportTicket;
use App\Models\User;
use App\Rules\ImageMimeTypeRule;
use App\Rules\MatchEmailRule;
use App\Rules\MatchOldPasswordRule;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Laravel\Socialite\Facades\Socialite;
use Illuminate\Support\Facades\URL;
use App\Models\TableBooking;
use App\Models\RoomBooking;
use App\Models\EventBooking;
use App\Models\PropertyInquiry;
use Illuminate\Support\Facades\Log;
use App\Models\Listing\RestaurantMenu;
use App\Models\Listing\HotelRoom;
use App\Models\Listing\ListingEvent;
use App\Models\Report;

class UserController extends Controller
{
    public function bookings()
    {
        $user = auth()->user();
    
        $tableBookings = $user->bookings()->with('listing')->latest()->get();
        $roomBookings = RoomBooking::where('user_id', $user->id)->with(['room.listing.current_content'])->latest()->get();
        $eventBookings = EventBooking::where('user_id', $user->id)->with(['event.listing.current_content'])->latest()->get();
    
        $propertyInquiries = PropertyInquiry::where('user_id', $user->id)->with(['property.listing.current_content'])->latest()->get();
        return view('frontend.user.booking', compact('tableBookings', 'roomBookings','eventBookings','propertyInquiries'));
    }

    public function editBooking($id)
    {
        $booking = TableBooking::findOrFail($id);
    
        return view('frontend.user.edit-booking', compact('booking'));
    }
    public function updatedBooking(Request $request, $id)
    {
        
        $request->validate([
            'checkin_date' => 'required|date',
            'exact_time' => 'required',
            'adults' => 'required|integer|min:1',
            'kids' => 'nullable|integer|min:0',
            'menu_items' => 'nullable|array',
        ]);
    
        $booking = TableBooking::findOrFail($id);
    
        $menuItems = [];
    
        if ($request->has('menu_items')) {
            foreach ($request->menu_items as $item) {
                if (!empty($item['id']) && !empty($item['quantity'])) {
                    $menu = RestaurantMenu::find($item['id']);
                    if ($menu) {
                        $menuItems[] = [
                            'id' => $menu->id,
                            'name' => $menu->menu_name,
                            'quantity' => $item['quantity'],
                            'type' => $menu->menu_type
                        ];
                    }
                }
            }
        }
    
        $booking->update([
            'checkin_date' => $request->checkin_date,
            'exact_time' => $request->exact_time,
            'adults' => $request->adults,
            'kids' => $request->kids,
            'selected_menus' => json_encode($menuItems),
        ]);
    
        return redirect()->route('user.bookings')->with('success', 'Booking updated successfully.');
    }
    public function uptodateBooking(Request $request, $id)
    {
        $request->validate([
            'exact_time' => 'required',
            'selected_menus' => 'nullable|array',
        ]);
    
        $booking = TableBooking::findOrFail($id);
        $booking->exact_time = $request->exact_time;
        $booking->selected_menus = json_encode($request->selected_menus ?? []);
        $booking->save();
    
        return redirect()->back()->with('success', 'Booking updated successfully.');
    }


  public function __construct()
  {
    $bs = DB::table('basic_settings')
      ->select('facebook_app_id', 'facebook_app_secret', 'google_client_id', 'google_client_secret')
      ->first();

    Config::set('services.facebook.client_id', $bs->facebook_app_id);
    Config::set('services.facebook.client_secret', $bs->facebook_app_secret);
    Config::set('services.facebook.redirect', url('user/login/facebook/callback'));

    Config::set('services.google.client_id', $bs->google_client_id);
    Config::set('services.google.client_secret', $bs->google_client_secret);
    Config::set('services.google.redirect', url('login/google/callback'));
  }

  public function login(Request $request)
  {
    
    $misc = new MiscellaneousController();

    $language = $misc->getLanguage();

    $information['seoInfo'] = $language->seoInfo()->select('meta_keyword_login', 'meta_description_login')->first();

    $information['pageHeading'] = $misc->getPageHeading($language);

    $information['bgImg'] = $misc->getBreadcrumb();

    // get the status of digital product (exist or not in the cart)
    if (!empty($request->input('digital_item'))) {
      $information['digitalProductStatus'] = $request->input('digital_item');
    }

    $information['bs'] = Basic::query()->select('google_recaptcha_status', 'facebook_login_status', 'google_login_status')->first();
    if ($request->redirectPath == 'listingDetails') {
      Session::put('redirectTo', URL::previous());
    }

    if ($request->redirectPath == 'wishlist') {
      Session::put('redirectTo', URL::previous());
    }
    return view('frontend.user.login', $information);
  }


public function BookTable(Request $request)
{
    if (!Auth::guard('web')->check()) {
        return redirect()->route('user.login', ['redirectPath' => url()->current()]);
    }

    $user_id = Auth::guard('web')->id();

    $request->validate([
        'listing_id'       => 'required|exists:listings,id',
        'checkin'          => 'required|date',
        'exact_time'       => 'required',
        'adults'           => 'required|integer|min:1',
        'kids'             => 'required|integer|min:0',
        'selected_menus'   => 'nullable|string' 
    ]);

    
    try {
        $checkinDate = Carbon::createFromFormat('m/d/Y', $request->checkin)->format('Y-m-d');
    } catch (\Exception $e) {
        return redirect()->back()->withErrors(['checkin' => 'The checkin date format is invalid.']);
    }

    TableBooking::create([
        'user_id'           => $user_id,
        'listing_id'        => $request->listing_id,
        'listing_owner_id'  => $request->listing_owner_id,
        'owner_type'        => $request->owner_type,
        'type'              => $request->type,
        'checkin_date'      => $checkinDate,
        'exact_time'        => $request->exact_time,
        'adults'            => $request->adults,
        'kids'              => $request->kids,
        'selected_menus'    => $request->selected_menus, 
        'status'            => 'pending'
    ]);

    return redirect()->back()->with('success', 'Table booked successfully!');
}


public function updateBooking(Request $request, $id)
{
    $request->validate([
        'time' => 'required|string',
        'exact_time' => 'required'
    ]);

    $booking = TableBooking::where('id', $id)
                ->where('user_id', Auth::id())
                ->firstOrFail();

    $booking->update([
        'time_slot' => $request->time,
        'exact_time' => $request->exact_time,
        'status' => 'pending',
    ]);

    return back()->with('success', 'Booking updated successfully.');
}

public function cancelBooking($id)
{
    $booking = TableBooking::where('id', $id)
                ->where('user_id', Auth::id())
                ->firstOrFail();

    $booking->update([
        'status' => 'cancelled'
    ]);

    return back()->with('success', 'Booking cancelled successfully.');
}

  public function redirectToFacebook()
  {
    return Socialite::driver('facebook')->redirect();
  }

  public function handleFacebookCallback(Request $request)
  {
    if ($request->has('error_code')) {
      Session::flash('error', $request->error_message);
      return redirect()->route('user.login');
    }
    return $this->authenticationViaProvider('facebook');
  }

  public function redirectToGoogle()
  {
    return Socialite::driver('google')->redirect();
  }

  public function handleGoogleCallback()
  {
    return $this->authenticationViaProvider('google');
  }

  public function authenticationViaProvider($driver)
  {
    // get the url from session which will be redirect after login
    if (Session::has('redirectTo')) {
      $redirectURL = Session::get('redirectTo');
    } else {
      $redirectURL = route('user.dashboard');
    }

    $responseData = Socialite::driver($driver)->user();
    $userInfo = $responseData->user;

    $isUser = User::query()->where('email', '=', $userInfo['email'])->first();

    if (!empty($isUser)) {
      // log in
      if ($isUser->status == 1) {
        Auth::guard('web')->login($isUser);

        return redirect($redirectURL);
      } else {
        Session::flash('error', 'Sorry, your account has been deactivated.');

        return redirect()->route('user.login');
      }
    } else {
      // get user avatar and save it
      $avatar = $responseData->getAvatar();
      $fileContents = file_get_contents($avatar);

      $avatarName = $responseData->getId() . '.jpg';
      $path = public_path('assets/img/users/');

      file_put_contents($path . $avatarName, $fileContents);

      // sign up
      $user = new User();

      if ($driver == 'facebook') {
        $user->name = $userInfo['name'];
      } else {
        $user->name = $userInfo['given_name'];
      }

      $user->image = $avatarName;
      $user->username = $userInfo['id'];
      $user->email = $userInfo['email'];
      $user->email_verified_at = date('Y-m-d H:i:s');
      $user->status = 1;
      $user->provider = ($driver == 'facebook') ? 'facebook' : 'google';
      $user->provider_id = $userInfo['id'];
      $user->save();

      Auth::guard('web')->login($user);

      return redirect($redirectURL);
    }
  }

  public function loginSubmit(Request $request)
  {
    // get the url from session which will be redirect after login
    if ($request->session()->has('redirectTo')) {
      $redirectURL = $request->session()->get('redirectTo');
    } else {
      $redirectURL = null;
    }


    $rules = [
      'username' => 'required',
      'password' => 'required'
    ];

    $info = Basic::select('google_recaptcha_status')->first();
    if ($info->google_recaptcha_status == 1) {
      $rules['g-recaptcha-response'] = 'required|captcha';
    }

    $messages = [];

    if ($info->google_recaptcha_status == 1) {
      $messages['g-recaptcha-response.required'] = 'Please verify that you are not a robot.';
      $messages['g-recaptcha-response.captcha'] = 'Captcha error! try again later or contact site admin.';
    }

    $validator = Validator::make($request->all(), $rules, $messages);

    if ($validator->fails()) {
      return redirect()->route('user.login')->withErrors($validator->errors())->withInput();
    }

    // get the email and password which has provided by the user
    $credentials = $request->only('username', 'password');

    // login attempt
    if (Auth::guard('web')->attempt($credentials)) {
      $authUser = Auth::guard('web')->user();
      // second, check whether the user's account is active or not
      if ($authUser->email_verified_at == null) {
        Session::flash('error', 'Please verify your email address');

        // logout auth user as condition not satisfied
        Auth::guard('web')->logout();

        return redirect()->back();
      }
      if ($authUser->status == 0) {
        Session::flash('error', 'Sorry, your account has been deactivated');

        // logout auth user as condition not satisfied
        Auth::guard('web')->logout();

        return redirect()->back();
      }

      // otherwise, redirect auth user to next url
      if (is_null($redirectURL)) {
        return redirect()->route('user.dashboard');
      } else {
        // before, redirect to next url forget the session value
        $request->session()->forget('redirectTo');

        return redirect($redirectURL);
      }
    } else {
      Session::flash('error', 'Incorrect username or password');

      return redirect()->back();
    }
  }

  public function forgetPassword()
  {
    $misc = new MiscellaneousController();

    $language = $misc->getLanguage();

    $information['seoInfo'] = $language->seoInfo()->select('meta_keyword_forget_password', 'meta_description_forget_password')->first();

    $information['pageHeading'] = $misc->getPageHeading($language);

    $information['bgImg'] = $misc->getBreadcrumb();
    $information['bs'] = Basic::query()->select('google_recaptcha_status', 'facebook_login_status', 'google_login_status')->first();

    return view('frontend.user.forget-password', $information);
  }

  public function forgetPasswordMail(Request $request)
  {
    $rules = [
      'email' => [
        'required',
        'email:rfc,dns',
        new MatchEmailRule('user')
      ]
    ];

    $info = Basic::select('google_recaptcha_status')->first();


    $messages = [];



    $validator = Validator::make($request->all(), $rules, $messages);

    if ($validator->fails()) {
      return redirect()->back()->withErrors($validator->errors())->withInput();
    }

    $user = User::query()->where('email', '=', $request->email)->first();

    // store user email in session to use it later
    $request->session()->put('userEmail', $user->email);

    // get the mail template information from db
    $mailTemplate = MailTemplate::query()->where('mail_type', '=', 'reset_password')->first();
    $mailData['subject'] = $mailTemplate->mail_subject;
    $mailBody = $mailTemplate->mail_body;

    // get the website title info from db
    $info = Basic::select('website_title')->first();

    $name = $user->username;

    $link = '<a href=' . url("user/reset-password") . '>Click Here</a>';

    $mailBody = str_replace('{customer_name}', $name, $mailBody);
    $mailBody = str_replace('{password_reset_link}', $link, $mailBody);
    $mailBody = str_replace('{website_title}', $info->website_title, $mailBody);

    $mailData['body'] = $mailBody;

    $mailData['recipient'] = $user->email;

    $mailData['sessionMessage'] = 'A mail has been sent to your email address';

    BasicMailer::sendMail($mailData);

    return redirect()->back();
  }

  public function resetPassword()
  {
    $misc = new MiscellaneousController();

    $bgImg = $misc->getBreadcrumb();

    return view('frontend.user.reset-password', compact('bgImg'));
  }

  public function resetPasswordSubmit(Request $request)
  {
    if ($request->session()->has('userEmail')) {
      // get the user email from session
      $emailAddress = $request->session()->get('userEmail');

      $rules = [
        'new_password' => 'required|confirmed',
        'new_password_confirmation' => 'required'
      ];

      $messages = [
        'new_password.confirmed' => 'Password confirmation failed.',
        'new_password_confirmation.required' => 'The confirm new password field is required.'
      ];

      $validator = Validator::make($request->all(), $rules, $messages);

      if ($validator->fails()) {
        return redirect()->back()->withErrors($validator->errors());
      }

      $user = User::query()->where('email', '=', $emailAddress)->first();

      $user->update([
        'password' => Hash::make($request->new_password)
      ]);

      Session::flash('success', 'Password updated successfully.');
    } else {
      Session::flash('error', 'Something went wrong!');
    }

    return redirect()->route('user.login');
  }

  public function signup()
  {
    $misc = new MiscellaneousController();

    $language = $misc->getLanguage();

    $information['seoInfo'] = $language->seoInfo()->select('meta_keyword_signup', 'meta_description_signup')->first();

    $information['pageHeading'] = $misc->getPageHeading($language);

    $information['bgImg'] = $misc->getBreadcrumb();

    $information['recaptchaInfo'] = Basic::select('google_recaptcha_status')->first();
//  dd($information);
    return view('frontend.user.signup', $information);
  }

  public function signupSubmit(Request $request)
  {
    //   dd($request);
    $info = Basic::select('google_recaptcha_status', 'website_title')->first();

    // validation start
    $rules = [
      'username' => 'required|unique:users|max:255',
      'email' => 'required|email:rfc,dns|unique:users|max:255',
      'password' => 'required|confirmed',
      'password_confirmation' => 'required',
      'g-recaptcha-response' => 'required|captcha',
    ];

    if ($info->google_recaptcha_status == 1) {
      $rules['g-recaptcha-response'] = 'required|captcha';
    }

    $messages = [
      'password_confirmation.required' => 'The confirm password field is required.'
    ];

    if ($info->google_recaptcha_status == 1) {
      $messages['g-recaptcha-response.required'] = 'Please verify that you are not a robot.';
      $messages['g-recaptcha-response.captcha'] = 'Captcha error! try again later or contact site admin.';
    }

    $validator = Validator::make($request->all(), $rules, $messages);

    if ($validator->fails()) {
      return redirect()->back()->withErrors($validator->errors())->withInput();
    }
    // validation end

    $user = new User();
    $user->username = $request->username;
    $user->email = $request->email;
    $user->status = 1;
    $user->password = Hash::make($request->password);
    $user->save();

    // get the mail template information from db
    $mailTemplate = MailTemplate::query()->where('mail_type', '=', 'verify_email')->first();
    $mailData['subject'] = $mailTemplate->mail_subject;
    $mailBody = $mailTemplate->mail_body;

    $link = '<a href=' . url("user/signup-verify/" . $user->id) . '>Click Here</a>';

    $mailBody = str_replace('{username}', $user->username, $mailBody);
    $mailBody = str_replace('{verification_link}', $link, $mailBody);
    $mailBody = str_replace('{website_title}', $info->website_title, $mailBody);

    $mailData['body'] = $mailBody;

    $mailData['recipient'] = $user->email;

    $mailData['sessionMessage'] = 'A verification mail has been sent to your email address';

    BasicMailer::sendMail($mailData);

    $information['authUser'] = $user;
    return back();
  }

  public function signupVerify($id)
  {
    $user = User::where('id', $id)->firstOrFail();
    $user->email_verified_at = Carbon::now();
    $user->save();
    Auth::login($user);
    return redirect()->route('user.dashboard');
  }

  public function redirectToDashboard()
  {
    $misc = new MiscellaneousController();

    $language = $misc->getLanguage();

    $information['language'] = $language;

    $information['bgImg'] = $misc->getBreadcrumb();
    $information['pageHeading'] = $misc->getPageHeading($language);

    $user = Auth::guard('web')->user();

    $information['authUser'] = $user;
    $information['wishlists'] = Wishlist::where('user_id', $user->id)
      ->join('listings', 'listings.id', '=', 'wishlists.listing_id')
      ->when('listings.vendor_id' != "0", function ($query) {
        return $query->leftJoin('memberships', 'listings.vendor_id', '=', 'memberships.vendor_id')
          ->where(function ($query) {
            $query->where([
              ['memberships.status', '=', 1],
              ['memberships.start_date', '<=', now()->format('Y-m-d')],
              ['memberships.expire_date', '>=', now()->format('Y-m-d')],
            ])->orWhere('listings.vendor_id', '=', 0);
          });
      })
      ->when('listings.vendor_id' != "0", function ($query) {
        return $query->leftJoin('vendors', 'listings.vendor_id', '=', 'vendors.id')
          ->where(function ($query) {
            $query->where([
              ['vendors.status', '=', 1],
            ])->orWhere('listings.vendor_id', '=', 0);
          });
      })
      ->get();
    $information['orders'] = ProductOrder::where('user_id', Auth::guard('web')->user()->id)->orderBy('id', 'desc')->get();
    $information['supportTickets'] = SupportTicket::where([['user_id', Auth::guard('web')->user()->id], ['user_type', 'user']])->orderBy('id', 'desc')->get();
    return view('frontend.user.dashboard', $information);
  }

  public function editProfile()
  {
    $misc = new MiscellaneousController();

    $information['bgImg'] = $misc->getBreadcrumb();
    $language = $misc->getLanguage();
    $information['pageHeading'] = $misc->getPageHeading($language);

    $information['authUser'] = Auth::guard('web')->user();


    return view('frontend.user.edit-profile', $information);
  }

  public function updateProfile(Request $request)
  {
    if ($request->image) {
      $image = true;
    } else {
      $image = false;
    }

    $request->validate([
      'image' => $image ? [
        'required',
        'dimensions:width=80,height=80',
        new ImageMimeTypeRule()
      ] : '',
      'name' => 'required',
      'username' => [
        'required',
        'alpha_dash',
        Rule::unique('users', 'username')->ignore(Auth::guard('web')->user()->id),
      ],
      'email' => [
        'required',
        'email',
        Rule::unique('users', 'email')->ignore(Auth::guard('web')->user()->id)
      ],
    ]);

    $authUser = Auth::guard('web')->user();
    $in = $request->all();
    $file = $request->file('image');
    if ($file) {
      $extension = $file->getClientOriginalExtension();
      $directory = public_path('assets/img/users/');
      $fileName = uniqid() . '.' . $extension;
      @mkdir($directory, 0775, true);
      $file->move($directory, $fileName);
      $in['image'] = $fileName;
      @unlink(public_path('assets/img/users/') . $authUser->image);
    }

    $authUser->update($in);
    Session::flash('success', 'Your profile has been updated successfully.');
    return redirect()->back();
  }

  public function changePassword()
  {
    $misc = new MiscellaneousController();

    $bgImg = $misc->getBreadcrumb();
    $language = $misc->getLanguage();
    $pageHeading = $misc->getPageHeading($language);

    return view('frontend.user.change-password', compact('bgImg', 'pageHeading'));
  }

  public function updatePassword(Request $request)
  {
    $rules = [
      'current_password' => [
        'required',
        new MatchOldPasswordRule('user')
      ],
      'new_password' => 'required|confirmed',
      'new_password_confirmation' => 'required'
    ];

    $messages = [
      'new_password.confirmed' => 'Password confirmation failed.',
      'new_password_confirmation.required' => 'The confirm new password field is required.'
    ];

    $validator = Validator::make($request->all(), $rules, $messages);

    if ($validator->fails()) {
      return redirect()->back()->withErrors($validator->errors());
    }

    $user = Auth::guard('web')->user();

    $user->update([
      'password' => Hash::make($request->new_password)
    ]);

    Session::flash('success', 'Password updated successfully.');

    return redirect()->back();
  }

  //wishlist
  public function wishlist()
  {
    $misc = new MiscellaneousController();
    $bgImg = $misc->getBreadcrumb();
    $language = $misc->getLanguage();
    $information['language'] = $language;
    $information['pageHeading'] = $misc->getPageHeading($language);

    $information['language'] = $language;
    $user_id = Auth::guard('web')->user()->id;
    $wishlists = Wishlist::where('user_id', $user_id)
      ->join('listings', 'listings.id', '=', 'wishlists.listing_id')
      ->when('listings.vendor_id' != "0", function ($query) {
        return $query->leftJoin('memberships', 'listings.vendor_id', '=', 'memberships.vendor_id')
          ->where(function ($query) {
            $query->where([
              ['memberships.status', '=', 1],
              ['memberships.start_date', '<=', now()->format('Y-m-d')],
              ['memberships.expire_date', '>=', now()->format('Y-m-d')],
            ])->orWhere('listings.vendor_id', '=', 0);
          });
      })
      ->when('listings.vendor_id' != "0", function ($query) {
        return $query->leftJoin('vendors', 'listings.vendor_id', '=', 'vendors.id')
          ->where(function ($query) {
            $query->where([
              ['vendors.status', '=', 1],
            ])->orWhere('listings.vendor_id', '=', 0);
          });
      })
      ->get();
    $information['bgImg'] = $bgImg;
    $information['wishlists'] = $wishlists;
    return view('frontend.user.wishlist', $information);
  }
  //add_to_wishlist
  public function add_to_wishlist($id)
  {
    if (Auth::guard('web')->check()) {
      $user_id = Auth::guard('web')->user()->id;
      $check = Wishlist::where('listing_id', $id)->where('user_id', $user_id)->first();

      if (!empty($check)) {
        return back()->with('error', 'Added to your wishlist successfully.');
      } else {
        $add = new Wishlist;
        $add->listing_id = $id;
        $add->user_id = $user_id;
        $add->save();
        return back()->with('success', 'Added to your wishlist successfully.');
      }
    } else {
      return redirect()->route('user.login', ['redirectPath' => 'wishlist']);
    }
  }
  //remove_wishlist
  public function remove_wishlist($id)
  {
    if (Auth::guard('web')->check()) {
      $remove = Wishlist::where('listing_id', $id)->first();
      if ($remove) {
        $remove->delete();
        return back()->with('success', 'Removed From wishlist successfully..!');
      } else {
        return back()->with('warning', 'Something went wrong.');
      }
    } else {
      return redirect()->route('user.login', ['redirectPath' => 'wishlist']);
    }
  }

  public function logoutSubmit(Request $request)
  {
    Auth::guard('web')->logout();
    Session::forget('secret_login');

    if ($request->session()->has('redirectTo')) {
      $request->session()->forget('redirectTo');
    }

    return redirect()->route('user.login');
  }
 public function editHotelBooking(Request $request, $id)
{
    $booking = RoomBooking::where('id', $id)->where('user_id', auth()->id())->firstOrFail();

    $request->validate([
        'room_id' => 'required|exists:listing_hotel_rooms,id',
        'check_in' => 'required|date|after_or_equal:today',
        'check_out' => 'required|date|after:check_in',
        'guests' => 'required|integer|min:1',
        'special_requests' => 'nullable|string|max:1000',
    ]);

    $booking->room_id = $request->room_id; 
    $booking->check_in = $request->check_in;
    $booking->check_out = $request->check_out;
    $booking->guests = $request->guests;
    $booking->special_requests = $request->special_requests;
    $booking->save();

    return redirect()->route('user.bookings')->with('success', 'Room booking updated successfully!');
}

public function cancelHotelBooking(Request $request, $id)
{
    $booking = RoomBooking::where('id', $id)->where('user_id', auth()->id())->firstOrFail();

    $booking->status = 'cancelled';
    $booking->save();

    return back()->with('success', 'Room booking cancelled successfully.');
}
public function showEditRoomBookingForm($id)
{
    $booking = RoomBooking::where('id', $id)
                ->where('user_id', auth()->id())
                ->firstOrFail();

    $rooms = HotelRoom::where('listing_id', $booking->listing_id)->get();

    return view('frontend.user.edit-room-booking', compact('booking', 'rooms'));
}

public function editEventBooking(Request $request, $id)
{
    $booking = EventBooking::where('id', $id)
                ->where('user_id', auth()->id())
                ->firstOrFail();

    $request->validate([
        'event_id' => 'required|exists:listing_events,id',
        'tickets' => 'required|integer',
        'special_requests' => 'nullable|string|max:1000',
    ]);

    $booking->event_id = $request->event_id;
    $booking->tickets = $request->tickets;
    $booking->special_requests = $request->special_requests;
    $booking->save();

    return redirect()->route('user.bookings')->with('success', 'Event booking updated successfully!');
}


public function cancelEventBooking(Request $request, $id)
{
    $booking = EventBooking::where('id', $id)->where('user_id', auth()->id())->firstOrFail();

    $booking->status = 'cancelled';
    $booking->save();

    return back()->with('success', 'Room booking cancelled successfully.');
}
public function showEditEventBookingForm($id)
{
    $booking = EventBooking::where('id', $id)
                ->where('user_id', auth()->id())
                ->firstOrFail();

    $events = ListingEvent::where('listing_id', $booking->listing_id)->get();

    return view('frontend.user.edit-event-booking', compact('booking', 'events'));
}
public function showEditPropertyInquiryForm($id)
{
    $inquiry = PropertyInquiry::where('user_id', Auth::id())->findOrFail($id);
    $properties = \App\Models\Listing\ListingProperty::where('listing_id', $inquiry->listing_id)->get();

    return view('frontend.user.edit-property-inquiry', compact('inquiry', 'properties'));
}
public function editPropertyInquiry(Request $request, $id)
{
    $inquiry = PropertyInquiry::where('user_id', Auth::id())->findOrFail($id);

    $request->validate([
        'property_id' => 'required|exists:listing_properties,id',
        'message' => 'nullable|string|max:1000',
    ]);

    $inquiry->property_id = $request->property_id;
    $inquiry->message = $request->message;
    $inquiry->save();

    return redirect()->route('user.dashboard')->with('success', 'Your property inquiry has been updated successfully!');
}
public function cancelPropertyInquiry(Request $request, $id)
{
    $inquiry = PropertyInquiry::where('user_id', Auth::id())->findOrFail($id);

    $inquiry->status = 'cancelled';
    $inquiry->save();

    return redirect()->back()->with('success', 'Your property inquiry has been cancelled successfully!');
}
public function report()
    {
        $reports = Report::where('user_id', Auth::id())
            ->latest()
            ->paginate(10);

        return view('frontend.user.report', compact('reports'));
    }

}
