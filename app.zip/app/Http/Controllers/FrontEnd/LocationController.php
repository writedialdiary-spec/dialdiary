<?php

namespace App\Http\Controllers\FrontEnd;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Location\State;

class LocationController extends Controller
{
    public function show(){
        $states = State::orderBy('name')->get();

        return view('frontend.location', compact('states'));

    }
}
