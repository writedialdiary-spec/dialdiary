<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\SeoMetaData;
use App\Models\Listing\ListingSubCategory;
use App\Models\Location\City;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Yajra\DataTables\Facades\DataTables;


class SeoMetaController extends Controller
{
    public function categories(){
        $subcategories = ListingSubCategory::all();
        
        return view('admin.seo_meta.category', compact('subcategories'));
    }
    public function index($id) {
        $seoEntries = SeoMetaData::with(['subcategory', 'city'])
            ->where('subcategory_id', $id)
            ->get();
        $subcategories = ListingSubCategory::findOrFail($id);
        $cities = City::all();
        return view('admin.seo_meta.index', compact('seoEntries', 'subcategories', 'cities'));
    }


    public function create() {
        $subcategories = ListingSubCategory::all();
        $cities = City::all();
        return view('admin.seo_meta.create', compact('subcategories', 'cities'));
    }
    // public function getSeoData(Request $request, $id)
    // {
    //     $query = SeoMetaData::with(['subcategory', 'city'])->where('subcategory_id', $id)->get();
    
    //     return DataTables::of($query)
    //         ->addColumn('checkbox', function ($row) {
    //             return '<input type="checkbox" class="bulk-check" data-val="' . $row->id . '">';
    //         })
    //         ->addColumn('subcategory', function ($row) {
    //             return $row->subcategory->name ?? '-';
    //         })
    //         ->addColumn('city', function ($row) {
    //             return $row->city->name ?? '-';
    //         })
    //         ->addColumn('actions', function ($row) {
    //             $editBtn = '<a href="#" class="btn btn-sm btn-secondary editBtn" data-toggle="modal"
    //                         data-target="#editModal"
    //                         data-id="'.$row->id.'"
    //                         data-subcategory_id="'.$row->subcategory_id.'"
    //                         data-city_id="'.$row->city_id.'"
    //                         data-meta_title="'.$row->meta_title.'"
    //                         data-meta_description="'.$row->meta_description.'"
    //                         data-custom_content="'.$row->custom_content.'">
    //                         <i class="fas fa-edit"></i></a>';
    
    //             $deleteBtn = '<form action="'.route('admin.seo_meta.delete', $row->id).'" method="POST" class="d-inline-block deleteForm">'.
    //                 csrf_field().
    //                 '<button type="submit" class="btn btn-sm btn-danger deleteBtn">
    //                     <i class="fas fa-trash"></i>
    //                 </button>
    //             </form>';
    
    //             return $editBtn . ' ' . $deleteBtn;
    //         })
    //         ->rawColumns(['checkbox', 'actions']) 
    //         ->make(true);
    // }
    public function getSeoData(Request $request, $id)
{
    $query = SeoMetaData::with(['subcategory', 'city'])
        ->where('subcategory_id', $id);

    return DataTables::eloquent($query)
        ->addColumn('checkbox', function ($row) {
            return '<input type="checkbox" class="bulk-check" data-val="' . $row->id . '">';
        })
        ->addColumn('subcategory', function ($row) {
            return $row->subcategory->name ?? '-';
        })
        ->addColumn('city', function ($row) {
            return $row->city->name ?? '-';
        })
        ->addColumn('actions', function ($row) {
            $editBtn = '<a href="#" class="btn btn-sm btn-secondary editBtn" data-toggle="modal"
                        data-target="#editModal"
                        data-id="'.$row->id.'"
                        data-subcategory_id="'.$row->subcategory_id.'"
                        data-city_id="'.$row->city_id.'"
                        data-meta_title="'.$row->meta_title.'"
                        data-meta_description="'.$row->meta_description.'"
                        data-custom_content="'.$row->custom_content.'">
                        <i class="fas fa-edit"></i></a>';

            $deleteBtn = '<form action="'.route('admin.seo_meta.delete', $row->id).'" method="POST" class="d-inline-block deleteForm">'.
                csrf_field().
                '<button type="submit" class="btn btn-sm btn-danger deleteBtn">
                    <i class="fas fa-trash"></i>
                </button>
            </form>';

            return $editBtn . ' ' . $deleteBtn;
        })
        ->rawColumns(['checkbox', 'actions'])
        ->make(true);
}

    public function update(Request $request, $id)
{
    
    $rules = [
        'subcategory_id' => 'required',
        'city_id' => 'required',
        'meta_title' => 'required|string|max:255',
        'meta_description' => 'required|string',
        'custom_content' => '',
    ];
    
    $validator = Validator::make($request->all(), $rules);
    if ($validator->fails()) {
        Log::info('Validation failed', $validator->errors()->toArray());
        return Response::json([
            'errors' => $validator->getMessageBag()
        ], 400);
    }

    $seoMeta = SeoMetaData::find($id);
    if (!$seoMeta) {
        return Response::json(['error' => 'SEO Meta not found.'], 404);
    }

    // Fetch related city and subcategory
    $city = City::find($request->city_id);
    $subcategory = ListingSubCategory::find($request->subcategory_id);

    if (!$city || !$subcategory) {
        return Response::json(['error' => 'City or Subcategory not found.'], 404);
    }

    // Generate slug
    $slug = strtolower($city->slug . '/' . $subcategory->slug);

    // Update the SEO meta
    $seoMeta->update([
        'subcategory_id' => $request->subcategory_id,
        'city_id' => $request->city_id,
        'meta_title' => $request->meta_title,
        'meta_description' => $request->meta_description,
        'custom_content' => $request->custom_content,
        'slug' => $slug,
    ]);

    Session::flash('success', 'SEO Meta updated successfully.');
    return Response::json(['status' => 'success'], 200);
}

    public function edit($id)
    {
        $seoMeta = SeoMeta::with(['category', 'city'])->findOrFail($id);
        $categories = Category::all();
        $cities = City::all();
    
        return view('admin.seo_meta.edit', compact('seoMeta', 'categories', 'cities'));
    }

    public function store(Request $request) {
        $validated = $request->validate([
            'subcategory_id' => 'required|exists:listing_sub_categories,id',
            'city_id' => 'required|exists:cities,id',
            'meta_title' => 'required|string|max:255',
            'meta_description' => 'required|string',
        ]);

        $city = City::find($validated['city_id']);
        $subcategory = ListingSubCategory::find($validated['subcategory_id']);

        $slug = strtolower($city->slug . '/' . $subcategory->slug);

        SeoMetaData::create(array_merge($validated, ['slug' => $slug]));

        return redirect()->route('admin.seo_meta.index')->with('success', 'SEO Metadata created successfully.');
    }
    public function destroy($id)
    {

        
        $seoMeta = SeoMetaData::find($id);
    
        
        if (!$seoMeta) {
            return redirect()->back()->with('error', 'SEO Meta not found.');
        }
    
        
        $seoMeta->delete();
    
        
        return redirect()->back()->with('success', 'SEO Meta deleted successfully.');
    }
    // public function autoGenerate() {
    //     $cities = City::all();
    //     $subcategories = ListingSubCategory::all();

    //     foreach ($cities as $city) {
    //         foreach ($subcategories as $subcategory) {
    //             $exists = SeoMetaData::where('city_id', $city->id)
    //                                   ->where('subcategory_id', $subcategory->id)
    //                                   ->exists();
    //             if (!$exists) {
    //                 $metaTitle = "Find Top {$subcategory->name} in {$city->name} – Dial Diary";
    //                 $metaDescription = "Discover trusted {$subcategory->name} services in {$city->name}. Browse verified listings, ratings, and reviews on Dial Diary.";
    //                 $slug = Str::slug("{$city->name}-{$subcategory->name}");

    //                 SeoMetaData::create([
    //                     'subcategory_id' => $subcategory->id,
    //                     'city_id' => $city->id,
    //                     'meta_title' => $metaTitle,
    //                     'meta_description' => $metaDescription,
    //                     'slug' => $slug,
    //                 ]);
    //             }
    //         }
    //     }

    //     return redirect()->back()->with('success', 'Missing SEO metadata generated.');
    // }
   

public function autoGenerate($subcategory_id) 
{
    $cities = City::all();
    $subcategory = ListingSubCategory::findOrFail($subcategory_id);
    $createdCount = 0;

    foreach ($cities as $city) {
           $citySlug = $city->slug;
            $categorySlug = Str::slug($subcategory->name);
        
            $slug = $citySlug . '/' . $categorySlug;

        // Skip if slug already exists
        $exists = SeoMetaData::where('slug', $slug)->exists();
        if ($exists) {
            continue;
        }

        $metaTitle = "Find Top {$subcategory->name} in {$city->name} – Dial Diary";
        $metaDescription = "Discover trusted {$subcategory->name} services in {$city->name}. Browse verified listings, ratings, and reviews on Dial Diary.";

        SeoMetaData::create([
            'subcategory_id' => $subcategory->id,
            'city_id' => $city->id,
            'meta_title' => $metaTitle,
            'meta_description' => $metaDescription,
            'slug' => $slug,
        ]);

        $createdCount++;
    }

    return redirect()->back()->with('success', "{$createdCount} SEO metadata records generated for {$subcategory->name}.");
}

    public function exportCsv() {
        $entries = SeoMetaData::with(['subcategory', 'city'])->get();

        $csv = "subcategory,city,meta_title,meta_description,slug\n";

        foreach ($entries as $entry) {
            $csv .= "{$entry->subcategory->name},{$entry->city->name},\"{$entry->meta_title}\",\"{$entry->meta_description}\",{$entry->slug}\n";
        }

        return response($csv)
            ->header('Content-Type', 'text/csv')
            ->header('Content-Disposition', 'attachment; filename="seo_metadata.csv"');
    }

   
    public function import(Request $request) {
        $request->validate([
            'csv_file' => 'required|file|mimes:csv,txt',
        ]);

        $file = fopen($request->file('csv_file')->getRealPath(), 'r');
        fgetcsv($file); // skip header

        while ($row = fgetcsv($file)) {
            [$subcategoryName, $cityName, $metaTitle, $metaDescription, $slug] = $row;

            $subcategory = Subcategory::where('name', $subcategoryName)->first();
            $city = City::where('name', $cityName)->first();

            if ($subcategory && $city) {
                SeoMetaData::updateOrCreate(
                    ['subcategory_id' => $subcategory->id, 'city_id' => $city->id],
                    ['meta_title' => $metaTitle, 'meta_description' => $metaDescription, 'slug' => $slug]
                );
            }
        }

        fclose($file);

        return redirect()->back()->with('success', 'CSV imported successfully.');
    }

    public function bulkDestroy(Request $request)
    {
        $ids = $request->ids;
        
        if (empty($ids)) {
            return redirect()->back()->with('error', 'No items selected for deletion.');
        }
    
        SeoMetaData::whereIn('id', $ids)->delete();
        return response()->json(['status' => 'success', 'message' => 'Selected city pages deleted successfully!']);
    }

}
