<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class HasPermission
{
  /**
   * Handle an incoming request.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  \Closure  $next
   * @return mixed
   */
//   public function handle(Request $request, Closure $next, $menuName)
//   {
//     $authAdmin = Auth::guard('admin')->user();
//     // dd($authAdmin);
//     $role = null;

//     if (!is_null($authAdmin->role_id)) {
//       $role = $authAdmin->role()->first();
//     }

//     if (!is_null($role)) {
//       $rolePermissions = json_decode($role->permissions);
//     }

//     if (is_null($role) || (!empty($rolePermissions) && in_array($menuName, $rolePermissions))) {
//       return $next($request);
//     }

//     return redirect()->back();
//   }
public function handle(Request $request, Closure $next, $menuName)
{
    
    $authUser = Auth::guard('admin')->user(); // default to admin
   
    // If admin is not logged in, try vendor
    if (!$authUser) {
        
        $authUser = Auth::guard('vendor')->user(); // adjust 'vendor' if needed
         
    }

    if (!$authUser) {
        return redirect()->route('login'); // Or handle unauthorized
    }

    $role = null;

    if (!is_null($authUser->role_id)) {
        $role = $authUser->role()->first();
    }

    $rolePermissions = [];

    if (!is_null($role)) {
        $rolePermissions = json_decode($role->permissions, true);
    }

    if (!empty($rolePermissions) && in_array($menuName, $rolePermissions)) {
        return $next($request);
    }
    
    return redirect()->back()->with('error', 'You do not have permission to access this page.');
}

}
