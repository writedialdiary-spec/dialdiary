<?php

namespace App\Console\Commands;
use Spatie\Sitemap\Sitemap;
use Spatie\Sitemap\Tags\Url;
use Illuminate\Console\Command;
use App\Models\Shop\Product;
use Illuminate\Support\Facades\File;
use App\Models\Sitemap as SitemapModel;
use Illuminate\Support\Facades\DB;


class GenerateProductFeeds extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'feeds:generate';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Generate XML product feeds for Google Merchant Center';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
{
    $perPage = 5000;
    $productsQuery = Product::where('status', 'show');
    $total = $productsQuery->count();
    $pages = ceil($total / $perPage);

    $outputPath = public_path('feeds');
    if (!File::exists($outputPath)) {
        File::makeDirectory($outputPath, 0755, true);
    }

    for ($page = 1; $page <= $pages; $page++) {
        $products = $productsQuery
            ->offset(($page - 1) * $perPage)
            ->limit($perPage)
            ->with(['content'])
            ->get();

        $xml = new \SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><rss version="2.0" xmlns:g="http://base.google.com/ns/1.0"></rss>');
        $channel = $xml->addChild('channel');
        $channel->addChild('title', "Dial Diary Product Feed Page $page");
        $channel->addChild('link', url('/'));
        $channel->addChild('description', "Product feed for Google Shopping (Page $page)");

        foreach ($products as $product) {
            $content = $product->content->where('language_id', 1)->first();

            $item = $channel->addChild('item');
            $item->addChild('g:id', $product->id, 'g');
            $item->addChild('g:title', htmlspecialchars($content?->title ?? 'Untitled'), 'g');
            $item->addChild('g:description', htmlspecialchars(strip_tags($content?->description ?? 'No description')), 'g');
            $item->addChild('g:link', url('/products/' . ($content?->slug ?? 'no-slug')), 'g');
            $item->addChild('g:image_link', asset($product->featured_image ?? 'default.jpg'), 'g');
            $item->addChild('g:availability', 'in stock', 'g');
            $item->addChild('g:price', number_format($product->current_price ?? 0, 2) . ' INR', 'g');
            $item->addChild('g:brand', htmlspecialchars($product->brand ?? 'Generic'), 'g');
            $item->addChild('g:google_product_category', htmlspecialchars($content?->google_category ?? 'Apparel & Accessories'), 'g');

            if (!empty($product->gtin)) {
                $item->addChild('g:gtin', $product->gtin, 'g');
            }

            if (!empty($product->sku)) {
                $item->addChild('g:mpn', $product->sku, 'g');
            }

            $item->addChild('g:condition', 'new', 'g');
        }

        File::put($outputPath . "/product-feed-{$page}.xml", $xml->asXML());
    }

    // Create feed index
    $index = new \SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><feeds></feeds>');
    for ($i = 1; $i <= $pages; $i++) {
        $feed = $index->addChild('feed');
        $feed->addChild('url', url("feeds/product-feed-$i.xml"));
    }
    File::put($outputPath . "/product-feed-index.xml", $index->asXML());

    // Update DB
    SitemapModel::updateOrCreate(
        ['filename' => 'product-feed-index.xml'],
        [
            'sitemap_url' => url('feeds/product-feed-index.xml'),
            'updated_at' => now(),
        ]
    );

    // Update sitemap.xml
    $sitemapPath = public_path('sitemap.xml');
    if (file_exists($sitemapPath)) {
        libxml_use_internal_errors(true);
        $sitemap = simplexml_load_file($sitemapPath);
        if ($sitemap === false) {
            $this->error('Malformed sitemap.xml');
            foreach (libxml_get_errors() as $error) {
                $this->error($error->message);
            }
            return 1;
        }
    } else {
        $sitemap = new \SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"></sitemapindex>');
    }

    // Remove old product-feed entries
    if (isset($sitemap->sitemap)) {
        $entries = iterator_to_array($sitemap->sitemap);
        foreach ($entries as $key => $entry) {
            if (str_contains((string)$entry->loc, 'product-feed')) {
                unset($sitemap->sitemap[$key]);
            }
        }
    }

    // Append all feed URLs
    for ($i = 1; $i <= $pages; $i++) {
        $entry = $sitemap->addChild('sitemap');
        $entry->addChild('loc', url("feeds/product-feed-$i.xml"));
        $entry->addChild('lastmod', now()->toAtomString());
    }

    // Save
    File::put($sitemapPath, $sitemap->asXML());

    $this->info("$pages product feed(s) generated and sitemap.xml updated.");
    return 0;
}


    }
    

