<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Listing\ListingContent;
use App\Models\Shop\ProductContent;
use App\Models\CityPage; 
use App\Models\Sitemap as SitemapModel;
use App\Models\Journal\BlogInformation;
use App\Models\Location\State;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use App\Http\Helpers\SitemapWriter;

class GenerateSitemap extends Command
{
    protected $signature = 'sitemap:generate';
    protected $description = 'Generate the sitemap for the website';

    public function handle()
    {
        /**
         * ---- Pages Sitemap ----
         */
        $pages = [
            url('/'),
            url('/about-us'),
            url('/terms-&-condition'),
            url('/privacy-policy'),
            url('/contact'),
            url('/faq'),
        ];

        $pagesFile = 'sitemap-pages.xml';
        SitemapWriter::writeUrls($pages, $pagesFile);
        $this->saveToDb($pagesFile);

        /**
         * ---- Listings Sitemap (chunked) ----
         */
        $listingChunkLimit = 1000;
        $listingFileIndex = 1;
        $listingUrls = [];

        ListingContent::chunk($listingChunkLimit, function ($listings) use (&$listingUrls, &$listingFileIndex, $listingChunkLimit) {
            foreach ($listings as $page) {
                $listingUrls[] = url("/listings/{$page->slug}/{$page->listing_id}");

                if (count($listingUrls) >= $listingChunkLimit) {
                    $filename = "sitemap-listings-{$listingFileIndex}.xml";
                    SitemapWriter::writeUrls($listingUrls, $filename);
                    $this->saveToDb($filename);

                    $listingFileIndex++;
                    $listingUrls = [];
                }
            }
        });

        if (count($listingUrls) > 0) {
            $filename = "sitemap-listings-{$listingFileIndex}.xml";
            SitemapWriter::writeUrls($listingUrls, $filename);
            $this->saveToDb($filename);
        }

        /**
         * ---- Products Sitemap (chunked) ----
         */
        $productChunkLimit = 1000;
        $productFileIndex = 1;
        $productUrls = [];

        ProductContent::chunk($productChunkLimit, function ($products) use (&$productUrls, &$productFileIndex, $productChunkLimit) {
            foreach ($products as $page) {
                $productUrls[] = url("/product/{$page->slug}");

                if (count($productUrls) >= $productChunkLimit) {
                    $filename = "sitemap-products-{$productFileIndex}.xml";
                    SitemapWriter::writeUrls($productUrls, $filename);
                    $this->saveToDb($filename);

                    $productFileIndex++;
                    $productUrls = [];
                }
            }
        });

        if (count($productUrls) > 0) {
            $filename = "sitemap-products-{$productFileIndex}.xml";
            SitemapWriter::writeUrls($productUrls, $filename);
            $this->saveToDb($filename);
        }

        /**
         * ---- States Sitemap ----
         */
        $states = State::all()->map(fn($s) => url("/location/" . Str::slug($s->name)))->toArray();
        $statesFile = 'sitemap-states.xml';
        SitemapWriter::writeUrls($states, $statesFile);
        $this->saveToDb($statesFile);

        /**
         * ---- Blogs Sitemap ----
         */
        $blogs = BlogInformation::all()->map(fn($b) => url("/blog/{$b->slug}"))->toArray();
        $blogs[] = url('/blog');

        $blogsFile = 'sitemap-blogs.xml';
        SitemapWriter::writeUrls($blogs, $blogsFile);
        $this->saveToDb($blogsFile);

        /**
         * ---- Locations Sitemap ----
         */
        $locations = CityPage::all()->map(fn($c) => url("/location/{$c->slug}"))->toArray();
        $locationsFile = 'sitemap-locations.xml';
        SitemapWriter::writeUrls($locations, $locationsFile);
        $this->saveToDb($locationsFile);

        /**
         * ---- City + Category Sitemap (chunked) ----
         */
        Cache::forget('sitemap_subcategories');
        $subcategories = Cache::remember('sitemap_subcategories', 3600, fn() => \App\Models\Listing\ListingSubCategory::all());

        $batchSize = 40000;
        $currentBatch = 1;
        $urls = [];

        \App\Models\Location\City::chunk(100, function ($cities) use ($subcategories, &$urls, &$currentBatch, $batchSize) {
            foreach ($cities as $city) {
                foreach ($subcategories as $subcategory) {
                    $urls[] = url("{$city->slug}/" . ($subcategory->slug ?? Str::slug($subcategory->name)));

                    if (count($urls) >= $batchSize) {
                        $filename = "sitemap-city-category-{$currentBatch}.xml";
                        SitemapWriter::writeUrls($urls, $filename);
                        $this->saveToDb($filename);

                        $currentBatch++;
                        $urls = [];
                    }
                }
            }
        });

        if (count($urls) > 0) {
            $filename = "sitemap-city-category-{$currentBatch}.xml";
            SitemapWriter::writeUrls($urls, $filename);
            $this->saveToDb($filename);
        }

        /**
         * ---- Master Sitemap Index ----
         */
        $sitemapFiles = SitemapModel::pluck('sitemap_url')->toArray();
        SitemapWriter::writeIndex($sitemapFiles, 'sitemap.xml');

        /**
         * ---- Ping Google ----
         */
        try {
            Http::get('https://www.google.com/ping', ['sitemap' => url('sitemap.xml')]);
            $this->info('Successfully pinged Google with sitemap.xml');
        } catch (\Exception $e) {
            Log::error('Failed to ping Google Sitemap: ' . $e->getMessage());
        }

        $this->info('✅ Master sitemap.xml generated successfully with all chunk files!');
    }

    private function saveToDb($filename)
    {
        SitemapModel::updateOrCreate(
            ['filename' => $filename],
            [
                'sitemap_url' => url($filename),
                'updated_at' => now(),
            ]
        );
    }
}
