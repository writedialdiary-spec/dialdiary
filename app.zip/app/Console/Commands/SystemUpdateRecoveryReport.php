<?php

namespace App\Console\Commands;

use App\Services\SystemUpdate\UpdateRecoveryJournal;
use Illuminate\Console\Command;
use Throwable;

class SystemUpdateRecoveryReport extends Command
{
    protected $signature = 'system-update:recovery-report';

    protected $description = 'Report system update recovery journal states without changing them';

    public function handle(UpdateRecoveryJournal $journal): int
    {
        try {
            $journals = $journal->listJournals();
        } catch (Throwable $exception) {
            $this->error('Cannot safely inspect recovery journals: ' . $exception->getMessage());
            return self::FAILURE;
        }

        if ($journals === []) {
            $this->info('No recovery journals found.');
            return self::SUCCESS;
        }

        $this->table(
            ['ID', 'Status', 'Files', 'Created', 'Completed'],
            array_map(
                static fn (array $item): array => [
                    $item['id'],
                    $item['status'],
                    $item['file_count'],
                    $item['created_at'] ?? '-',
                    $item['completed_at'] ?? '-',
                ],
                $journals
            )
        );

        $this->line('Read-only report: no files or journals were changed.');
        return self::SUCCESS;
    }
}
