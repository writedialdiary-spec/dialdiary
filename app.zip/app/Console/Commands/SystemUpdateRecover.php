<?php

namespace App\Console\Commands;

use App\Services\SystemUpdate\UpdateRecoveryJournal;
use App\Services\SystemUpdate\UpdateMaintenanceMode;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Throwable;

class SystemUpdateRecover extends Command
{
    protected $signature = 'system-update:recover {id} {--confirm}';

    protected $description = 'Explicitly restore files from a validated interrupted system update';

    public function handle(
        UpdateRecoveryJournal $journal,
        UpdateMaintenanceMode $maintenance
    ): int
    {
        $maintenanceEnabled = false;
        $id = (string) $this->argument('id');

        if (!preg_match('/^[a-f0-9]{32}$/', $id)) {
            $this->error('Invalid journal ID.');
            return self::FAILURE;
        }

        if (!$this->option('confirm')) {
            $this->error('No changes made. Rerun with --confirm to authorize rollback.');
            return self::FAILURE;
        }

        try {
            $metadata = $journal->metadata($id);
            $status = $metadata['status'] ?? null;

            if (!in_array($status, ['installing', 'rolling_back', 'rollback_failed'], true)) {
                $this->error('Refusing recovery: journal status is not eligible for rollback.');
                return self::FAILURE;
            }

            $validation = $journal->validateJournal($id);

            if (!($validation['valid'] ?? false)) {
                $this->error('Refusing recovery: journal validation failed.');
                foreach ($validation['errors'] ?? [] as $error) {
                    $this->line('- ' . $error);
                }
                return self::FAILURE;
            }

            if ($maintenance->down() !== 0) {
                $this->error('Could not enable maintenance mode. No recovery attempted.');
                return self::FAILURE;
            }
            $maintenanceEnabled = true;

            $result = $journal->restore($id);

            if (!($result['success'] ?? false)) {
                Log::critical('Manual system update recovery failed.', [
                    'journal_id' => $id,
                    'errors' => $result['errors'] ?? [],
                ]);

                $this->error('Recovery was incomplete. Maintenance mode has been left enabled.');
                foreach ($result['errors'] ?? [] as $error) {
                    $this->line('- ' . $error);
                }

                return self::FAILURE;
            }

            if ($maintenance->up() !== 0) {
                Log::critical('Recovery succeeded but maintenance mode could not be cleared.', [
                    'journal_id' => $id,
                ]);

                $this->error('Files were restored, but maintenance mode could not be cleared.');
                return self::FAILURE;
            }

            $maintenanceEnabled = false;

            Log::warning('Manual system update rollback completed.', [
                'journal_id' => $id,
            ]);

            $this->info('Recovery completed successfully. Original files were restored.');
            return self::SUCCESS;
        } catch (Throwable $exception) {
            Log::critical('Manual system update recovery command failed.', [
                'journal_id' => $id,
                'error' => $exception->getMessage(),
            ]);

            $this->error('Recovery stopped: ' . $exception->getMessage());
            if ($maintenanceEnabled) {
                $this->line('Maintenance mode may still be enabled. Do not bring the site up until recovery is verified.');
            } else {
                $this->line('Check the site maintenance state before taking further action.');
            }
            return self::FAILURE;
        }
    }
}
